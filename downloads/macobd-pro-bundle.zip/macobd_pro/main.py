#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Einstiegspunkt (roher USB-Modus)
=============================================
HTTP-Server (Standardbibliothek + pyusb) auf 127.0.0.1:8765.
USB-Logik in usbcore.py, Oberflaeche in ui.py.

    python3 main.py --web        # Server + Browser-UI (Standard)
    python3 main.py --list       # USB-Geraete im Terminal auflisten
"""

import json
import argparse
import os
import sys

# Mitgelieferte Bibliotheken (pyserial, pyusb) - KEIN pip/Internet noetig
_VENDOR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor")
if os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from usbcore import usbdev, list_usb, descriptor, sys_usb
from ui import INDEX_HTML
import dyno
import binedit
import decode
from cantransport import canmgr
import vehicles
import nostart
import online
import flashcode
import checklist


def _hexid(v, default):
    try:
        return int(str(v).replace("0x", "").replace("0X", ""), 16)
    except (ValueError, TypeError):
        return default

HOST = "127.0.0.1"
PORT = 8765


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}
        except Exception:
            return {}

    def do_GET(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)
        if p == "/health":
            return self._send(200, {"status": "ok"})
        if p in ("/", "/index.html"):
            return self._send(200, INDEX_HTML, "text/html")
        if p == "/api/list":
            return self._send(200, list_usb())
        if p == "/api/descriptor":
            try:
                vid = int(q.get("vid", ["0"])[0], 16)
                pid = int(q.get("pid", ["0"])[0], 16)
            except ValueError:
                return self._send(400, {"ok": False, "error": "vid/pid ungueltig"})
            return self._send(200, descriptor(vid, pid))
        if p == "/api/sysusb":
            return self._send(200, sys_usb())
        if p == "/api/status":
            return self._send(200, usbdev.snapshot())
        if p == "/api/can/status":
            return self._send(200, canmgr.state)
        if p == "/api/vehicles":
            return self._send(200, vehicles.list_all())
        if p == "/api/vehicle":
            return self._send(200, vehicles.profile(q.get("key", ["generic"])[0]))
        if p == "/api/nostart":
            return self._send(200, nostart.tree(q.get("fuel", ["benzin"])[0]))
        if p == "/api/online/status":
            return self._send(200, online.online_status())
        if p == "/api/vin":
            return self._send(200, online.vin_decode(q.get("vin", [""])[0]))
        if p == "/api/flashcode":
            return self._send(200, flashcode.guide())
        if p == "/api/checklist":
            return self._send(200, checklist.checklist(q.get("fuel", ["benzin"])[0]))
        if p == "/api/checklist/load":
            return self._send(200, checklist.load_results())
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        p = urlparse(self.path).path
        b = self._body()
        if p == "/api/open":
            usbdev.open(int(str(b.get("vid")), 16), int(str(b.get("pid")), 16),
                        interface=b.get("interface"),
                        ep_in=b.get("ep_in"), ep_out=b.get("ep_out"))
            return self._send(200, {"ok": True})
        if p == "/api/close":
            usbdev.close()
            return self._send(200, {"ok": True})
        if p == "/api/write":
            usbdev.write(b.get("hex", ""))
            return self._send(200, {"ok": True})
        if p == "/api/clear":
            usbdev.clear_buffer()
            return self._send(200, {"ok": True})
        if p == "/api/dyno":
            samples = dyno.parse_csv(b.get("csv", ""))
            return self._send(200, dyno.compute(samples, b.get("params")))
        if p == "/api/bin/load":
            return self._send(200, binedit.load(b.get("path", "")))
        if p == "/api/bin/backup":
            return self._send(200, binedit.backup(b.get("path", "")))
        if p == "/api/bin/hexdump":
            return self._send(200, binedit.hexdump(
                b.get("path", ""), b.get("offset", 0), b.get("length", 256)))
        if p == "/api/bin/readmap":
            return self._send(200, binedit.read_map(
                b.get("path", ""), b.get("offset", 0), b.get("rows", 1),
                b.get("cols", 1), b.get("dtype", "uint16"), b.get("big", False),
                float(b.get("factor", 1.0)), float(b.get("add", 0.0))))
        if p == "/api/bin/writemap":
            return self._send(200, binedit.write_map(
                b.get("path", ""), b.get("offset", 0), b.get("rows", 1),
                b.get("cols", 1), b.get("values", []), b.get("dtype", "uint16"),
                b.get("big", False), float(b.get("factor", 1.0)),
                float(b.get("add", 0.0))))
        if p == "/api/bin/checksum":
            return self._send(200, binedit.checksum(
                b.get("path", ""), b.get("algo", "sum16"),
                b.get("start", 0), b.get("end")))
        if p == "/api/bin/diff":
            return self._send(200, binedit.diff(
                b.get("path_a", ""), b.get("path_b", "")))
        if p == "/api/decode":
            return self._send(200, decode.decode_capture(b.get("text", "")))
        if p == "/api/can/open":
            return self._send(200, canmgr.open(
                b.get("port", ""), b.get("bitrate", "500k"),
                _hexid(b.get("tx_id"), 0x7E0), _hexid(b.get("rx_id"), 0x7E8)))
        if p == "/api/can/close":
            return self._send(200, canmgr.close())
        if p == "/api/can/dtcs":
            return self._send(200, canmgr.read_dtcs())
        if p == "/api/can/cleardtcs":
            return self._send(200, canmgr.clear_dtcs())
        if p == "/api/can/did":
            return self._send(200, canmgr.read_did(b.get("did", "F190")))
        if p == "/api/can/reset":
            return self._send(200, canmgr.ecu_reset(b.get("sub", 1)))
        if p == "/api/can/raw":
            return self._send(200, canmgr.raw(b.get("hex", "")))
        if p == "/api/can/scanmodules":
            return self._send(200, canmgr.scan_modules(
                _hexid(b.get("tx_start"), 0x7E0), _hexid(b.get("tx_end"), 0x7E7)))
        if p == "/api/can/alldtcs":
            return self._send(200, canmgr.read_all_dtcs(b.get("modules", [])))
        if p == "/api/can/session":
            return self._send(200, canmgr.session(b.get("sub", 3)))
        if p == "/api/can/routine":
            return self._send(200, canmgr.routine_ctl(
                b.get("control", 1), b.get("rid", "FF00"), b.get("params", "")))
        if p == "/api/can/iocontrol":
            return self._send(200, canmgr.io_ctl(
                b.get("did", "0"), b.get("control", 0), b.get("params", "")))
        if p == "/api/can/write":
            return self._send(200, canmgr.write_did(
                b.get("did", "0"), b.get("data", "")))
        if p == "/api/can/secseed":
            return self._send(200, canmgr.sec_seed(b.get("level", 1)))
        if p == "/api/can/seckey":
            return self._send(200, canmgr.sec_key(b.get("level", 1), b.get("key", "")))
        if p == "/api/can/readmem":
            return self._send(200, canmgr.read_mem(b.get("addr", "0"), b.get("size", 8)))
        if p == "/api/can/vin":
            return self._send(200, canmgr.read_vin())
        if p == "/api/checklist/save":
            return self._send(200, checklist.save_results(b.get("results", {})))
        return self._send(404, {"error": "not found"})


def run_web():
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"MacOBD-Pro (USB) laeuft auf http://{HOST}:{PORT}  (Strg+C beendet)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nBeendet.")
        srv.shutdown()


def cli_list():
    r = list_usb()
    if not r.get("ok"):
        print("Fehler:", r.get("error"))
        return
    for d in r["devices"]:
        print(f"{d.get('vid')}:{d.get('pid')}  "
              f"{d.get('manufacturer','')} {d.get('product','')}  "
              f"{d.get('hint','')}")


def main():
    ap = argparse.ArgumentParser(description="MacOBD-Pro (USB)")
    ap.add_argument("--web", action="store_true")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()
    if args.list:
        return cli_list()
    run_web()


if __name__ == "__main__":
    main()
