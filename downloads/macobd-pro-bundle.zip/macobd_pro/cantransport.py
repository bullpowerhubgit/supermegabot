#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - CAN-Transport (SLCAN) fuer UDS-Voll-Diagnose
=========================================================
Bindet die UDS-Engine an einen echten CAN-Bus ueber einen SLCAN-Adapter
(CANable/CANtact/USBtin u.ae., ~30 Euro). Damit laeuft die Voll-Diagnose
HEUTE - ohne auf den dekodierten ThinkDiag2-Kanal zu warten.

SLCAN-Protokoll (ASCII, je Befehl mit \\r):
  S6=500k S5=250k S4=125k S8=1M | O=oeffnen C=schliessen
  t<id3><dlc><data> = Standard-Frame senden/empfangen
"""

import time
import threading

import uds
from uds import UDSClient, UDSError

BITRATE = {"1M": "S8", "800k": "S7", "500k": "S6", "250k": "S5",
           "125k": "S4", "100k": "S3", "50k": "S2", "20k": "S1", "10k": "S0"}


class SLCANTransport(uds.Transport):
    """uds.Transport ueber ein serielles SLCAN-Geraet (oder Fake zum Test)."""
    def __init__(self, ser):
        self.ser = ser
        self._rx = bytearray()

    def send_frame(self, arb_id, data):
        data = bytes(data)
        cmd = f"t{arb_id:03X}{len(data):X}" + "".join(f"{b:02X}" for b in data) + "\r"
        self.ser.write(cmd.encode("ascii"))

    def recv_frame(self, timeout=1.0):
        end = time.time() + timeout
        while time.time() < end:
            n = self.ser.in_waiting
            if n:
                self._rx += self.ser.read(n)
            while b"\r" in self._rx:
                line, _, self._rx = self._rx.partition(b"\r")
                f = self._parse(line.decode("ascii", "ignore"))
                if f:
                    return f
            time.sleep(0.002)
        return None

    @staticmethod
    def _parse(s):
        if not s:
            return None
        if s[0] == "t" and len(s) >= 5:
            arb = int(s[1:4], 16)
            dlc = int(s[4], 16)
            data = bytes.fromhex(s[5:5 + dlc * 2]) if dlc else b""
            return (arb, data)
        if s[0] == "T" and len(s) >= 10:
            arb = int(s[1:9], 16)
            dlc = int(s[9], 16)
            data = bytes.fromhex(s[10:10 + dlc * 2]) if dlc else b""
            return (arb, data)
        return None


def open_serial_slcan(port, bitrate="500k", baud=115200):
    """Oeffnet einen echten SLCAN-Adapter am seriellen Port."""
    import serial  # pyserial
    ser = serial.Serial(port, baud, timeout=0.05)
    for cmd in (b"C\r", BITRATE.get(bitrate, "S6").encode() + b"\r", b"O\r"):
        ser.write(cmd)
        time.sleep(0.05)
    ser.reset_input_buffer()
    return SLCANTransport(ser), ser


# ---------------------------------------------------------------------------
# Manager: haelt Verbindung + UDS-Client, thread-safe, synchron
# ---------------------------------------------------------------------------
class CanManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._ser = None
        self._client = None
        self.state = {"connected": False, "port": None, "bitrate": None,
                      "tx_id": None, "rx_id": None, "last_error": None}

    def open(self, port, bitrate="500k", tx_id=0x7E0, rx_id=0x7E8):
        with self._lock:
            self.close_locked()
            try:
                tp, ser = open_serial_slcan(port, bitrate)
                self._ser = ser
                self._client = UDSClient(tp, int(tx_id), int(rx_id))
                self.state.update(connected=True, port=port, bitrate=bitrate,
                                  tx_id=f"0x{int(tx_id):X}", rx_id=f"0x{int(rx_id):X}",
                                  last_error=None)
                return {"ok": True}
            except Exception as e:
                self.state.update(connected=False, last_error=str(e))
                return {"ok": False, "error": str(e)}

    def close_locked(self):
        if self._ser is not None:
            try:
                self._ser.write(b"C\r")
                self._ser.close()
            except Exception:
                pass
        self._ser = None
        self._client = None
        self.state.update(connected=False)

    def close(self):
        with self._lock:
            self.close_locked()
            return {"ok": True}

    def _run(self, fn):
        with self._lock:
            if not self._client:
                return {"ok": False, "error": "Kein CAN-Kanal offen."}
            try:
                return {"ok": True, "result": fn(self._client)}
            except UDSError as e:
                return {"ok": False, "error": str(e)}
            except Exception as e:
                return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # ---- Diagnosefunktionen ----
    def read_dtcs(self):
        return self._run(lambda c: c.read_dtcs())

    def clear_dtcs(self):
        return self._run(lambda c: c.clear_dtcs().hex())

    def read_did(self, did):
        return self._run(lambda c: c.read_data_by_id(int(did, 16)
                         if isinstance(did, str) else int(did)).hex())

    def ecu_reset(self, sub=0x01):
        return self._run(lambda c: c.ecu_reset(int(sub)).hex())

    def io_control(self, did, control, params=b""):
        return self._run(lambda c: c.io_control(int(did), int(control),
                         bytes.fromhex(params) if params else b"").hex())

    def routine(self, control, rid, params=b""):
        return self._run(lambda c: c.routine(int(control), int(rid),
                         bytes.fromhex(params) if params else b"").hex())

    def raw(self, hexstr):
        payload = bytes.fromhex(hexstr.replace(" ", ""))
        return self._run(lambda c: c.request(payload).hex())

    def session(self, sub=0x03):
        return self._run(lambda c: c.session(int(sub)).hex())

    def routine_ctl(self, control, rid, params=""):
        return self._run(lambda c: c.routine(
            int(control), int(str(rid).replace("0x", ""), 16),
            bytes.fromhex(params.replace(" ", "")) if params else b"").hex())

    def io_ctl(self, did, control, params=""):
        return self._run(lambda c: c.io_control(
            int(str(did).replace("0x", ""), 16), int(control),
            bytes.fromhex(params.replace(" ", "")) if params else b"").hex())

    def write_did(self, did, data):
        return self._run(lambda c: c.write_data_by_id(
            int(str(did).replace("0x", ""), 16),
            bytes.fromhex(data.replace(" ", ""))).hex())

    def sec_seed(self, level=0x01):
        return self._run(lambda c: c.security_seed(int(level)).hex())

    def sec_key(self, level, key):
        return self._run(lambda c: c.security_key(
            int(level), bytes.fromhex(key.replace(" ", ""))).hex())

    def read_mem(self, addr, size):
        a = int(str(addr).replace("0x", ""), 16)
        s = int(str(size).replace("0x", ""), 16) if isinstance(size, str) and "x" in str(size) else int(size)
        return self._run(lambda c: c.read_memory_by_address(a, s).hex())

    def read_vin(self):
        """VIN aus dem Fahrzeug lesen: erst OBD Mode 09 PID 02,
        dann UDS DID F190 als Fallback."""
        with self._lock:
            if not self._client:
                return {"ok": False, "error": "Kein CAN-Kanal offen."}
            # 1) OBD Mode 09 PID 02
            try:
                r = self._client.request(bytes([0x09, 0x02]), timeout=2.0)
                vin = _extract_vin(r)
                if vin:
                    return {"ok": True, "vin": vin, "via": "OBD Mode 09"}
            except Exception:
                pass
            # 2) UDS ReadDataByIdentifier F190
            try:
                r = self._client.read_data_by_id(0xF190)
                vin = _extract_vin(r)
                if vin:
                    return {"ok": True, "vin": vin, "via": "UDS F190"}
            except Exception as e:
                return {"ok": False, "error": f"VIN nicht lesbar: {e}"}
            return {"ok": False, "error": "Keine VIN erhalten (Modul/Zuendung?)."}

    def _parse_id(self, v, default):
        try:
            return int(str(v).replace("0x", "").replace("0X", ""), 16)
        except (ValueError, TypeError):
            return default

    def read_all_dtcs(self, modules):
        """Fehlerspeicher aus MEHREREN Modulen lesen - Kern-Vorteil gegenueber
        generischen Tools, die nur den Motor-Speicher (Mode 03) lesen."""
        with self._lock:
            if not self._client:
                return {"ok": False, "error": "Kein CAN-Kanal offen."}
            out = []
            for m in modules:
                tx = self._parse_id(m.get("tx"), None)
                rx = self._parse_id(m.get("rx"), None)
                if tx is None or rx is None:
                    continue
                self._client.tx_id = tx
                self._client.rx_id = rx
                entry = {"name": m.get("name", f"0x{tx:03X}"),
                         "tx": f"0x{tx:03X}", "rx": f"0x{rx:03X}"}
                try:
                    dtcs = self._client.read_dtcs()
                    entry["dtcs"] = dtcs
                    entry["count"] = len(dtcs)
                except Exception as e:
                    entry["error"] = str(e)
                    entry["dtcs"] = []
                out.append(entry)
            return {"ok": True, "modules": out}

    def scan_modules(self, tx_start=0x7E0, tx_end=0x7E7):
        """Sucht antwortende Steuergeraete: TesterPresent an jede ID,
        Antwort auf tx+8 (ISO 15765-4). Findet die echten Module am Bus."""
        with self._lock:
            if not self._client:
                return {"ok": False, "error": "Kein CAN-Kanal offen."}
            tp = self._client.tp
            found = []
            for tx in range(int(tx_start), int(tx_end) + 1):
                rx = tx + 8
                try:
                    uds.isotp_send(tp, tx, rx, bytes([0x3E, 0x00]), timeout=0.4)
                    r = tp.recv_frame(timeout=0.3)
                    end = time.time() + 0.4
                    while r is None and time.time() < end:
                        r = tp.recv_frame(timeout=0.2)
                    if r and r[0] == rx:
                        resp = r[1][1:1 + (r[1][0] & 0x0F)] if r[1] else b""
                        found.append({"tx": f"0x{tx:03X}", "rx": f"0x{rx:03X}",
                                      "resp": resp.hex().upper() or "-"})
                except Exception:
                    continue
            return {"ok": True, "found": found,
                    "range": f"0x{int(tx_start):03X}-0x{int(tx_end):03X}"}


_VIN_CHARS = set("ABCDEFGHJKLMNPRSTUVWXYZ0123456789")


def _extract_vin(resp):
    """Robuste VIN-Extraktion aus einer OBD/UDS-Antwort (ASCII, 17 Zeichen)."""
    if not resp:
        return None
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in resp)
    cleaned = "".join(c for c in text.upper() if c in _VIN_CHARS)
    # 17-stellige Sequenz suchen
    if len(cleaned) >= 17:
        # bevorzugt die letzten 17 gueltigen Zeichen (Header/NODI davor)
        return cleaned[-17:]
    return None


canmgr = CanManager()
