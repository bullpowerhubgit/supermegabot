#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Virtueller Dyno (Leistungspruefstand per Physik)
=============================================================
Echte inertiale/Road-Load-Berechnung: aus einem WOT-Zug (Zeit, Drehzahl,
Geschwindigkeit) wird die Rad- und Motorleistung + Drehmomentkurve geschaetzt.
Kein Pruefstand, kein externer Speicher - reine Physik nativ auf dem Mac.

Physik:
  a      = dv/dt
  F_rad  = m*a + F_luft + F_roll
  F_luft = 0.5 * rho * Cd * A * v^2
  F_roll = Crr * m * g
  P_rad  = F_rad * v
  P_motor= P_rad / eta_antrieb          (Antriebsstrangverluste)
  T_motor= 9549 * P_motor[kW] / RPM     (Nm)
"""

import math

G = 9.81


def _movavg(xs, k=5):
    if k < 2 or len(xs) < k:
        return xs[:]
    out = []
    half = k // 2
    for i in range(len(xs)):
        lo = max(0, i - half)
        hi = min(len(xs), i + half + 1)
        out.append(sum(xs[lo:hi]) / (hi - lo))
    return out


def compute(samples, params=None):
    """
    samples: Liste von dicts {t (s), speed (km/h), rpm}  (maf optional)
    params : {mass_kg, cd, area_m2, crr, drivetrain_eff, air_density}
    Rueckgabe: dict mit Kurve (rpm/power_kw/power_ps/torque_nm) + Peaks.
    """
    p = {
        "mass_kg": 1400.0, "cd": 0.30, "area_m2": 2.2, "crr": 0.012,
        "drivetrain_eff": 0.85, "air_density": 1.225,
    }
    if params:
        p.update({k: float(v) for k, v in params.items() if v is not None})

    pts = [s for s in samples if s.get("t") is not None
           and s.get("speed") is not None and s.get("rpm")]
    pts.sort(key=lambda s: s["t"])
    if len(pts) < 4:
        return {"ok": False, "error": "Zu wenige Datenpunkte (min. 4)."}

    t = [float(s["t"]) for s in pts]
    v = [float(s["speed"]) / 3.6 for s in pts]      # m/s
    rpm = [float(s["rpm"]) for s in pts]
    v_s = _movavg(v, 5)

    curve = []
    for i in range(1, len(pts)):
        dt = t[i] - t[i - 1]
        if dt <= 0:
            continue
        a = (v_s[i] - v_s[i - 1]) / dt
        vi = v_s[i]
        if a <= 0 or vi <= 0.5:
            continue  # nur Beschleunigungsphase
        f_air = 0.5 * p["air_density"] * p["cd"] * p["area_m2"] * vi * vi
        f_roll = p["crr"] * p["mass_kg"] * G
        f = p["mass_kg"] * a + f_air + f_roll
        p_wheel = f * vi                       # W
        p_eng = p_wheel / p["drivetrain_eff"]  # W
        r = rpm[i]
        if r < 1000:
            continue
        p_kw = p_eng / 1000.0
        torque = 9549.0 * p_kw / r
        curve.append({"rpm": round(r), "power_kw": round(p_kw, 1),
                      "power_ps": round(p_kw * 1.35962, 1),
                      "torque_nm": round(torque, 1)})

    if not curve:
        return {"ok": False,
                "error": "Kein gueltiger Beschleunigungszug erkannt "
                         "(Vollgas-Zug im hoechsten sinnvollen Gang loggen)."}

    # Nach RPM in 250er-Buckets mitteln -> glatte Kurve
    buckets = {}
    for c in curve:
        b = int(round(c["rpm"] / 250.0) * 250)
        buckets.setdefault(b, []).append(c)
    smooth = []
    for b in sorted(buckets):
        g = buckets[b]
        smooth.append({
            "rpm": b,
            "power_kw": round(sum(x["power_kw"] for x in g) / len(g), 1),
            "power_ps": round(sum(x["power_ps"] for x in g) / len(g), 1),
            "torque_nm": round(sum(x["torque_nm"] for x in g) / len(g), 1),
        })

    peak_p = max(smooth, key=lambda x: x["power_ps"])
    peak_t = max(smooth, key=lambda x: x["torque_nm"])
    return {
        "ok": True,
        "curve": smooth,
        "peak_power": {"ps": peak_p["power_ps"], "kw": peak_p["power_kw"],
                       "rpm": peak_p["rpm"]},
        "peak_torque": {"nm": peak_t["torque_nm"], "rpm": peak_t["rpm"]},
        "params": p,
        "samples_used": len(curve),
    }


def parse_csv(text):
    """CSV/TSV mit Spalten t,speed,rpm (Header optional) -> samples."""
    out = []
    for line in text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [x.strip() for x in line.replace(";", ",")
                 .replace("\t", ",").split(",")]
        if len(parts) < 3:
            continue
        try:
            out.append({"t": float(parts[0]), "speed": float(parts[1]),
                        "rpm": float(parts[2])})
        except ValueError:
            continue  # Header-Zeile ueberspringen
    return out
