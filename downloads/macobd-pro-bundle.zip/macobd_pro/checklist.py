#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Komplett-Pruefliste (Crank-No-Start, jede Kleinigkeit)
===================================================================
Vollstaendige, systematische Pruefliste fuer "orgelt, startet nicht".
Nach System geordnet, kraftstoff-abhaengig (Benzin/Diesel). Jeder Punkt
mit Messmethode, Sollwert und Fehlerbedeutung. Ergebnisse lokal speicherbar.
"""

import os
import json

RESULTS_FILE = os.path.join(os.getcwd(), "checklist_results.json")

# fuel: None=beide, "benzin", "diesel" | tool: True=Tool kann messen/lesen
CHECKS = [
    # ---- Stromversorgung / Masse ----
    ("pwr1", "Strom & Masse", "Batteriespannung unter Last (beim Orgeln)",
     "Multimeter an Batterie beim Orgeln", "> 9,6 V beim Orgeln",
     "Faellt sie tief ab -> Batterie schwach; stoert WCM/PCM -> No-Start", None, False),
    ("pwr2", "Strom & Masse", "Ruhespannung Batterie",
     "Multimeter, Zuendung aus", "12,4-12,7 V",
     "Unter 12,2 V -> laden/pruefen; schwache Batterie = sporadischer No-Start", None, False),
    ("pwr3", "Strom & Masse", "Massebaender Motor<->Karosserie",
     "Sichtpruefung + Durchgang; abklemmen/reinigen", "fest, sauber, < 0,2 Ohm",
     "Schlechte Masse -> falsche Sensorsignale, kein/schlechter Start", None, False),
    ("pwr4", "Strom & Masse", "Hauptsicherungen + Relaissockel",
     "Sicherungen und TIPM-Sockel pruefen", "alle intakt, kein Schmoren",
     "Angeschmorte Kontakte im TIPM -> intermittierende Ausfaelle", None, False),
    ("pwr5", "Strom & Masse", "Zuendschloss / Anlasssignal",
     "Kommt beim Orgeln 12V an ASD/Anlasserkreis an?", "Signal vorhanden",
     "Kein Anlasssignal -> ECU startet Zuend-/Einspritzfreigabe nicht", None, False),

    # ---- Signale (Kurbel/Nocken) ----
    ("sig1", "Signale", "Drehzahl (RPM) beim Orgeln",
     "Tool/OBD live beim Orgeln beobachten", "RPM steigt > 0",
     "Bleibt 0 -> PCM bekommt KEIN Kurbelsignal (Kabel/Stecker/Geberrad!)", None, True),
    ("sig2", "Signale", "Kurbelwellensensor-Signal (CKP)",
     "Oszi/Multimeter (AC) am Sensor beim Orgeln", "sauberes Wechselsignal",
     "Kein Signal trotz neuem Sensor -> Verkabelung/Reluctorrad", None, False),
    ("sig3", "Signale", "Nockenwellensensor (CMP)",
     "Signal/Widerstand pruefen", "Signal vorhanden",
     "Ohne CMP evtl. Notlauf/kein Start; Korrelation CKP/CMP", None, False),
    ("sig4", "Signale", "CKP/CMP-Stecker & Kabelbaum",
     "Stecker abziehen, auf Korrosion/Wackler pruefen", "sauber, fest",
     "Wackelkontakt = intermittierendes Signal = 'startet selten'", None, False),

    # ---- Kraftstoff (allgemein) ----
    ("fu1", "Kraftstoff", "Pumpen-Prime bei Zuendung EIN",
     "Am Tank horchen (~2 s Summen)", "Pumpe summt kurz",
     "Kein Summen -> Relais(TIPM)/Pumpe/Sicherung", None, False),
    ("fu2", "Kraftstoff", "Kraftstofffilter",
     "Alter/Zustand; bei Diesel Wasser ablassen", "frei, nicht zu",
     "Zugesetzter Filter -> Druck bricht ein", None, False),
    ("fu3", "Kraftstoff", "Kraftstoffqualitaet / Tank",
     "Fuellstand, Verunreinigung, Diesel/Benzin korrekt", "sauber, ausreichend",
     "Falscher/alter Sprit, Wasser -> kein/schlechter Start", None, False),

    # ---- Zuendung (nur Benzin) ----
    ("ig1", "Zuendung (Benzin)", "Zuendfunke an der Kerze",
     "Kerze raus, an Masse, orgeln", "kraeftiger blauer Funke",
     "Kein Funke -> Spulen/ASD/Kurbelreferenz", "benzin", False),
    ("ig2", "Zuendung (Benzin)", "Zuendspulen / Kerzen",
     "Zustand, Widerstand, Ansteuerung", "in Ordnung",
     "Defekte Spule/nasse Kerzen -> Aussetzer/No-Start", "benzin", False),
    ("ig3", "Zuendung (Benzin)", "ASD-Relais schaltet (nach Prime hinaus)",
     "Spannung an Spulen/Injektoren beim Orgeln", "12V dauerhaft beim Orgeln",
     "ASD schaltet nicht -> meist fehlendes Kurbelsignal am PCM", "benzin", False),

    # ---- Einspritzung ----
    ("inj1", "Einspritzung", "Injektor-Impuls (Noid-Test)",
     "Noid-Light am Injektorstecker beim Orgeln", "blinkt im Takt",
     "Kein Impuls + kein Funke -> ASD/Kurbelsignal; kein Impuls allein -> Treiber", None, False),

    # ---- Diesel Common-Rail ----
    ("d1", "Diesel Common-Rail", "Raildruck beim Orgeln",
     "Live-PID Rail-Druck / Manometer", "grob 250+ bar zum Zuenden",
     "Zu niedrig -> Foerderung/MPROP/HD-Pumpe/undichter Injektor", "diesel", True),
    ("d2", "Diesel Common-Rail", "Vorfoerderung / Luft im System",
     "Handpumpe fest? blasenfreier Zulauf? entlueften", "Druck da, keine Luft",
     "Luft/schwache Foerderpumpe -> HD-Pumpe baut keinen Druck auf", "diesel", False),
    ("d3", "Diesel Common-Rail", "Injektor-Ruecklaufmenge (leak-off)",
     "Messbecher an Injektor-Ruecklauf beim Orgeln", "gleichmaessig, gering",
     "Ein Injektor mit viel Ruecklauf -> Rail-Druck bricht zusammen", "diesel", False),
    ("d4", "Diesel Common-Rail", "Druckregelventil (MPROP/DRV)",
     "Ansteuerung/Funktion pruefen", "regelt korrekt",
     "Haengendes Ventil -> kein/instabiler Raildruck", "diesel", False),
    ("d5", "Diesel Glueh", "Gluehkerzen / Gluehzeitsteuergeraet",
     "Widerstand Kerzen, Ansteuerung", "alle heizen",
     "Bei Kaelte kein Start; warm evtl. schon", "diesel", False),

    # ---- Luft / Ladung ----
    ("air1", "Luft", "Ansaugung / Luftfilter frei",
     "Sichtpruefung, keine Blockade", "frei",
     "Massive Blockade -> schwerer Start", None, False),
    ("air2", "Luft", "Abgasweg frei (Kat/DPF nicht verstopft)",
     "Gegendruck/Sicht; DPF-Beladung", "frei",
     "Verstopfter Kat/DPF -> Motor 'erstickt'", None, False),

    # ---- Wegfahrsperre ----
    ("im1", "Wegfahrsperre", "Security-/Schluessel-Leuchte bei Zuendung EIN",
     "Tacho beobachten", "geht nach ~3 s aus",
     "Bleibt an/blinkt -> WCM autorisiert nicht -> Einspritzung gesperrt", None, False),
    ("im2", "Wegfahrsperre", "Zweiter/Ersatzschluessel",
     "Mit anderem Schluessel starten", "startet damit zuverlaessig",
     "Startet nur mit 2. Schluessel -> 1. Transponder defekt/nicht angelernt", None, False),
    ("im3", "Wegfahrsperre", "WCM-Fehlerspeicher (UDS, nicht Mode 03!)",
     "CAN: Module scannen -> WCM auslesen", "keine Immo-Codes",
     "Immo-Code im WCM = die Ursache, die generische Tools nie sehen", None, True),

    # ---- Steuergeraet / Kommunikation ----
    ("ecu1", "Steuergeraet & Bus", "Alle Module: erweiterter Fehlerspeicher",
     "CAN: 'Alle Module auslesen' (UDS 0x19)", "keine versteckten Codes",
     "Codes in PCM/WCM/TIPM, die Mode 03 nicht zeigt", None, True),
    ("ecu2", "Steuergeraet & Bus", "U-Codes / Kommunikationsverlust",
     "U0100/U0140/U0155 etc. pruefen", "keine U-Codes",
     "Bus-/Kommunikationsproblem stoert Freigabe -> No-Start", None, True),
    ("ecu3", "Steuergeraet & Bus", "TIPM-Zustand",
     "Relais/Treiber im TIPM; Luefter-/Pumpenfunktion", "schaltet zuverlaessig",
     "Sterbendes TIPM -> Pumpe/ASD schalten nicht (oft ohne Code)", None, False),

    # ---- Mechanik ----
    ("me1", "Mechanik", "Kompression",
     "Kompressionstester je Zylinder", "gleichmaessig, im Sollbereich",
     "Zu niedrig -> Ventile/Kolben/Steuerzeiten", None, False),
    ("me2", "Mechanik", "Steuerzeiten (Kette/Riemen)",
     "Markierungen Nocken/Kurbel; Kettenspanner", "synchron",
     "Uebersprungen -> Nocken/Kurbel-Korrelation (P0016/P0017), kein Start", None, False),
    ("me3", "Mechanik", "Geberrad / Reluctor am Schwungrad",
     "Sichtpruefung auf beschaedigte Zaehne", "unbeschaedigt",
     "Beschaedigtes Geberrad -> falsches/fehlendes Kurbelsignal", None, False),
]


def checklist(fuel="benzin"):
    fuel = str(fuel).lower()
    items = []
    for cid, system, check, how, good, bad, f, tool in CHECKS:
        if f is not None and f != fuel:
            continue
        items.append({"id": cid, "system": system, "check": check, "how": how,
                      "good": good, "bad": bad, "tool": tool})
    # nach System gruppieren (Reihenfolge erhalten)
    groups = []
    seen = {}
    for it in items:
        if it["system"] not in seen:
            seen[it["system"]] = []
            groups.append({"system": it["system"], "items": seen[it["system"]]})
        seen[it["system"]].append(it)
    return {"ok": True, "fuel": fuel, "groups": groups, "count": len(items)}


def save_results(results):
    try:
        with open(RESULTS_FILE, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        return {"ok": True, "file": RESULTS_FILE}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def load_results():
    try:
        with open(RESULTS_FILE, encoding="utf-8") as f:
            return {"ok": True, "results": json.load(f)}
    except Exception:
        return {"ok": True, "results": {}}
