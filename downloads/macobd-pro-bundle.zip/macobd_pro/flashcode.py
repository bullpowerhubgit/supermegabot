#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Blink-Code & Wegfahrsperre (Chrysler/Dodge)
========================================================
Hilfe fuer den Fall: Motorkontrollleuchte blinkt nach Schluessel-ON eine
Anzahl mal und geht dann auf Dauerlicht - typisch fuer einen gespeicherten
Code bzw. Wegfahrsperren-Signal, der NICHT im Abgasspeicher (Mode 03) steht,
den die generischen OBD-Tools lesen.
"""

GUIDE = {
    "ok": True,
    "title": "Blink-Code auslesen (Schluessel-Tanz) + Wegfahrsperre",
    "keydance": {
        "title": "Codes ohne Adapter auslesen - Schluessel-Tanz",
        "steps": [
            "Motor aus. Zuendung 3x schnell ON-OFF-ON-OFF-ON (innerhalb ~5 s), "
            "am Ende in Stellung ON lassen (NICHT starten).",
            "Bei vielen Chrysler/Dodge/Jeep (ca. 1998-2010) erscheinen dann die "
            "gespeicherten DTCs im Kilometerzaehler-Display (z.B. P0601 ... 'done'/"
            "'End').",
            "Falls kein Odometer-Display: die Motorkontrollleuchte blinkt die "
            "zweistelligen Codes: Gruppe von X Blinks, Pause, Gruppe von Y Blinks "
            "= Code XY. Alle Gruppen notieren.",
            "P1693 heisst nur 'im anderen Modul liegt ein Code' - dann das andere "
            "Steuergeraet (PCM/WCM) gezielt auslesen.",
        ],
    },
    "count_hint": {
        "title": "Deine '10x blinkt dann Dauerlicht'",
        "text": "Zaehle genau: ist es EINE Gruppe von 10, oder zwei Gruppen "
                "(z.B. 1 Blink - Pause - 0 ...)? Zweistellige Codes werden als "
                "zwei Gruppen geblinkt. Notiere die Gruppen - daraus wird der "
                "eigentliche Code. Danach im erweiterten Speicher (UDS 0x19), "
                "nicht nur Mode 03, nachsehen.",
    },
    "immobilizer": {
        "title": "Verdacht Wegfahrsperre (WCM/SKIM/Sentry Key)",
        "why": "Orgelt, springt selten an, Leuchte bleibt - und generische Tools "
               "finden nichts: klassisch fuer die Wegfahrsperre. Der Fehler liegt "
               "im WCM, nicht im Abgasspeicher des PCM.",
        "checks": [
            "Security-/Wegfahrsperren-Symbol im Tacho beim Einschalten beobachten "
            "(blinkt es dauerhaft?).",
            "Zweiten/Ersatzschluessel testen - startet er damit, ist der erste "
            "Transponder defekt/nicht angelernt.",
            "Mit CAN-Adapter: 'Module scannen' -> antwortet das WCM? Dann dessen "
            "Fehlerspeicher per UDS lesen (0x19) - NICHT Mode 03.",
            "Batteriespannung: schwache Batterie kann WCM<->PCM-Kommunikation "
            "stoeren und sporadischen No-Start ausloesen.",
            "PCM<->WCM-Kommunikation / U-Codes (U0100/U0155/U1120) pruefen.",
        ],
    },
    "next": "Mit dem CAN-Adapter im Panel 'CAN-Diagnose': 'Module scannen', dann "
            "'Alle Module auslesen' - liest den erweiterten Fehlerspeicher JEDES "
            "Moduls (WCM, PCM, TIPM). Genau das, was die 5 Tools nicht getan haben.",
}


def guide():
    return GUIDE
