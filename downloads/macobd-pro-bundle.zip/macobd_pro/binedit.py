#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Bin/Map-Werkbank (ECU-Binary-Editor)
==================================================
Arbeitet auf einem BEREITS AUSGELESENEN ECU-Binary (.bin) - nativ, lokal.
KEIN Flashen, KEIN Auslesen der ECU (das kann der ThinkDiag2 nicht).

Kann:
  - Binary laden, Metadaten (Groesse, MD5), automatisches Backup
  - Hex-Dump (offset/laenge)
  - Map als 2D-Tabelle definieren, skaliert lesen und schreiben
    (uint8/int8/uint16/int16, LE/BE, Faktor + Offset)
  - Checksummen-Framework (sum8/16/32, xor, CRC16-CCITT, CRC32)
  - Before/After-Diff zweier Binaries

Kein Abgas-Defeat, kein DTC-Maskieren zum Verstecken entfernter Technik.
"""

import os
import time
import shutil
import hashlib
import struct
import binascii

_STORE = {}   # path -> bytearray (Arbeitskopie im Speicher)


# ---------------------------------------------------------------------------
def load(path):
    if not os.path.isfile(path):
        return {"ok": False, "error": f"Datei nicht gefunden: {path}"}
    with open(path, "rb") as f:
        data = bytearray(f.read())
    _STORE[path] = data
    return {"ok": True, "path": path, "size": len(data),
            "md5": hashlib.md5(data).hexdigest()}


def _get(path):
    if path not in _STORE:
        r = load(path)
        if not r["ok"]:
            return None
    return _STORE[path]


def backup(path):
    if not os.path.isfile(path):
        return {"ok": False, "error": "Datei nicht gefunden."}
    dst = f"{path}.{time.strftime('%Y%m%d-%H%M%S')}.bak"
    shutil.copy2(path, dst)
    return {"ok": True, "backup": dst}


def hexdump(path, offset=0, length=256):
    data = _get(path)
    if data is None:
        return {"ok": False, "error": "Nicht geladen."}
    offset = max(0, int(offset))
    chunk = data[offset:offset + int(length)]
    rows = []
    for i in range(0, len(chunk), 16):
        seg = chunk[i:i + 16]
        hexs = " ".join(f"{b:02X}" for b in seg)
        asci = "".join(chr(b) if 32 <= b < 127 else "." for b in seg)
        rows.append({"addr": f"0x{offset+i:06X}", "hex": hexs, "ascii": asci})
    return {"ok": True, "rows": rows, "offset": offset, "length": len(chunk)}


# ---- Datentypen fuer Map-Zellen ----
_FMT = {
    "uint8":  ("B", 1), "int8":  ("b", 1),
    "uint16": ("H", 2), "int16": ("h", 2),
    "uint32": ("I", 4), "int32": ("i", 4),
}


def _unpack(data, off, dtype, big):
    code, size = _FMT[dtype]
    e = ">" if big else "<"
    return struct.unpack_from(e + code, data, off)[0], size


def _pack(dtype, big, value):
    code, size = _FMT[dtype]
    e = ">" if big else "<"
    return struct.pack(e + code, int(round(value)))


def read_map(path, offset, rows, cols, dtype="uint16", big=False,
             factor=1.0, add=0.0):
    """Map als 2D-Tabelle skaliert lesen: real = roh*factor + add."""
    data = _get(path)
    if data is None:
        return {"ok": False, "error": "Nicht geladen."}
    if dtype not in _FMT:
        return {"ok": False, "error": f"Unbekannter Typ {dtype}"}
    _, size = _FMT[dtype]
    off = int(offset)
    table, raw = [], []
    for r in range(int(rows)):
        row_s, row_r = [], []
        for c in range(int(cols)):
            v, _ = _unpack(data, off, dtype, big)
            row_r.append(v)
            row_s.append(round(v * factor + add, 3))
            off += size
        table.append(row_s)
        raw.append(row_r)
    flat = [x for row in table for x in row]
    return {"ok": True, "table": table, "raw": raw,
            "min": min(flat), "max": max(flat),
            "offset": int(offset), "rows": int(rows), "cols": int(cols),
            "dtype": dtype, "big": big, "factor": factor, "add": add}


def write_map(path, offset, rows, cols, values, dtype="uint16", big=False,
              factor=1.0, add=0.0, do_backup=True):
    """
    2D-Tabelle (skalierte Werte) zurueckschreiben. roh = (real-add)/factor.
    Schreibt in die Arbeitskopie UND auf Platte (nach Backup).
    """
    data = _get(path)
    if data is None:
        return {"ok": False, "error": "Nicht geladen."}
    if do_backup and os.path.isfile(path):
        backup(path)
    _, size = _FMT[dtype]
    off = int(offset)
    changed = 0
    for r in range(int(rows)):
        for c in range(int(cols)):
            real = float(values[r][c])
            raw = (real - add) / factor if factor else 0
            packed = _pack(dtype, big, raw)
            if data[off:off + size] != packed:
                changed += 1
            data[off:off + size] = packed
            off += size
    with open(path, "wb") as f:
        f.write(data)
    return {"ok": True, "changed_cells": changed,
            "md5": hashlib.md5(data).hexdigest()}


# ---- Checksummen-Framework ----
def checksum(path, algo="sum16", start=0, end=None):
    data = _get(path)
    if data is None:
        return {"ok": False, "error": "Nicht geladen."}
    end = len(data) if end is None else int(end)
    seg = bytes(data[int(start):end])
    algo = algo.lower()
    if algo == "sum8":
        val = sum(seg) & 0xFF
    elif algo == "sum16":
        val = sum(seg) & 0xFFFF
    elif algo == "sum32":
        val = sum(seg) & 0xFFFFFFFF
    elif algo == "xor":
        val = 0
        for b in seg:
            val ^= b
    elif algo == "crc16":       # CRC16-CCITT (0x1021, init 0xFFFF)
        val = 0xFFFF
        for b in seg:
            val ^= b << 8
            for _ in range(8):
                val = ((val << 1) ^ 0x1021) & 0xFFFF if val & 0x8000 else (val << 1) & 0xFFFF
    elif algo == "crc32":
        val = binascii.crc32(seg) & 0xFFFFFFFF
    else:
        return {"ok": False, "error": f"Unbekannter Algorithmus {algo}"}
    return {"ok": True, "algo": algo, "start": int(start), "end": end,
            "value": val, "hex": f"0x{val:0{ 8 if 'sum32' in algo or algo=='crc32' else 4}X}"}


def diff(path_a, path_b, max_hits=500):
    a = _get(path_a)
    b = _get(path_b)
    if a is None or b is None:
        return {"ok": False, "error": "Beide Binaries laden."}
    hits = []
    n = min(len(a), len(b))
    i = 0
    while i < n and len(hits) < max_hits:
        if a[i] != b[i]:
            j = i
            while j < n and a[j] != b[j] and (j - i) < 64:
                j += 1
            hits.append({"addr": f"0x{i:06X}",
                         "old": " ".join(f"{x:02X}" for x in a[i:j]),
                         "new": " ".join(f"{x:02X}" for x in b[i:j])})
            i = j
        else:
            i += 1
    return {"ok": True, "changes": hits, "size_a": len(a), "size_b": len(b),
            "truncated": len(hits) >= max_hits}
