#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro — Fahrzeugprofile (55+ Marken, 200+ Modelle)
========================================================
CAN-Bitrate, Modul-IDs, Live-PIDs, häufige DTCs je Fahrzeug.
"""

FUNCTIONAL = 0x7DF

STD_MODULES = [
    {"name": "PCM/ECU (Motor)",    "tx": 0x7E0, "rx": 0x7E8},
    {"name": "TCM (Getriebe)",     "tx": 0x7E1, "rx": 0x7E9},
    {"name": "Modul @7E2",         "tx": 0x7E2, "rx": 0x7EA},
    {"name": "Modul @7E3",         "tx": 0x7E3, "rx": 0x7EB},
]

BASE_PIDS = [
    (0x0C, "Drehzahl",              "rpm"),
    (0x0D, "Geschwindigkeit",       "km/h"),
    (0x05, "Kühlmitteltemp.",       "°C"),
    (0x04, "Motorlast",             "%"),
    (0x11, "Drosselklappe",         "%"),
    (0x0F, "Ansaugluft",            "°C"),
    (0x0B, "Saugrohrdruck",         "kPa"),
    (0x10, "Luftmasse (MAF)",       "g/s"),
    (0x0E, "Zündzeitpunkt",         "°"),
    (0x06, "Kurzzeit-Gemisch B1",   "%"),
    (0x07, "Langzeit-Gemisch B1",   "%"),
    (0x2F, "Tankfüllstand",         "%"),
    (0x42, "Steuerspannung",        "V"),
    (0x5C, "Öltemperatur",          "°C"),
    (0x46, "Umgebungslufttemp.",    "°C"),
    (0x1F, "Laufzeit seit Start",   "s"),
]

DIESEL_PIDS = [
    (0x0C, "Drehzahl",              "rpm"),
    (0x0D, "Geschwindigkeit",       "km/h"),
    (0x05, "Kühlmitteltemp.",       "°C"),
    (0x04, "Motorlast",             "%"),
    (0x0B, "Ladedruck (MAP)",       "kPa"),
    (0x0F, "Ansaugluft",            "°C"),
    (0x10, "Luftmasse (MAF)",       "g/s"),
    (0x23, "Kraftstoff-Rail-Druck", "kPa"),
    (0x22, "Kraftstoffdruck rel.",  "kPa"),
    (0x70, "Ladedruck-Soll",        "kPa"),
    (0x42, "Steuerspannung",        "V"),
    (0x5C, "Öltemperatur",          "°C"),
    (0x2F, "Tankfüllstand",         "%"),
]

HYBRID_PIDS = BASE_PIDS + [
    (0x5B, "HV-Batterie SOC",       "%"),
    (0x5E, "Kraftstoffverbrauch",   "L/h"),
]

BMW_MODULES = STD_MODULES + [
    {"name": "DME/DDE (Motor)",    "tx": 0x7E0, "rx": 0x7E8},
    {"name": "EGS (Getriebe)",     "tx": 0x7E1, "rx": 0x7E9},
    {"name": "DSC (ABS/ESP)",      "tx": 0x7E4, "rx": 0x7EC},
    {"name": "ICM/FRM",            "tx": 0x60C, "rx": 0x62C},
]

MERCEDES_MODULES = STD_MODULES + [
    {"name": "ME/CDI (Motor)",     "tx": 0x7E0, "rx": 0x7E8},
    {"name": "EGS/9G (Getriebe)", "tx": 0x7E1, "rx": 0x7E9},
    {"name": "ESP (ABS)",          "tx": 0x7E4, "rx": 0x7EC},
    {"name": "SAM vorne",          "tx": 0x7E5, "rx": 0x7ED},
]

VW_MODULES = [
    {"name": "Motorsteuergerät",   "tx": 0x7E0, "rx": 0x7E8},
    {"name": "Getriebesteuerung",  "tx": 0x7E1, "rx": 0x7E9},
    {"name": "ABS/ESP",            "tx": 0x7E3, "rx": 0x7EB},
    {"name": "Kombiinstrument",    "tx": 0x7E2, "rx": 0x7EA},
    {"name": "Gateway (GW)",       "tx": 0x7FF, "rx": 0x7FF},
]

TOYOTA_MODULES = STD_MODULES + [
    {"name": "ECM (Motor)",        "tx": 0x7E0, "rx": 0x7E8},
    {"name": "ECT (Getriebe)",     "tx": 0x7E1, "rx": 0x7E9},
    {"name": "ABS",                "tx": 0x7E4, "rx": 0x7EC},
]

# ═══════════════════════════════════════════════════════════════════════
# FAHRZEUGPROFILE — 55+ MARKEN / 200+ MODELLE
# ═══════════════════════════════════════════════════════════════════════

VEHICLES = {

    # ──────────────────────────── BMW ────────────────────────────────
    "bmw_e46_320i": {
        "name": "BMW E46 320i/325i",
        "brand": "BMW", "brand_code": "bmw",
        "engine": "M54/M52 2.0–2.5L Reihen-6", "years": "1998–2005",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / K-Line",
        "modules": BMW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "M54: Vanos-Doppel (Einlass+Auslass). Vanos-Rütteln P0011/P0014 → Ölpumpen-Sieb prüfen.",
            "Saugrohrklappen-Stellmotor (Swirl Flap) bricht oft → P2015.",
            "DISA-Ventil (M52TU/M54): P1525 bei Bruch der Kunststoffklappe.",
            "Thermostat elektronisch gesteuert: P0597/P0598 häufig.",
        ],
        "common_dtcs": ["P0011", "P0014", "P2015", "P1525", "P0597",
                        "P0171", "P0174", "P0300", "P0420", "U0073"],
    },
    "bmw_e90_330i": {
        "name": "BMW E90/E91/E92 330i/335i",
        "brand": "BMW", "brand_code": "bmw",
        "engine": "N52 3.0L / N54 3.0L TwinTurbo", "years": "2005–2013",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / MOST",
        "modules": BMW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "N54 TwinTurbo: Wastegate-Rattle (Ausblasventile) → N20/Boost-Fehler P0234/P0299.",
            "HPFP (Hochdruckpumpe N54): P0087 Niederdruck → Pumpe, Stößel.",
            "Valvetronic (N52/N54): P1017/P1025 → Motor, Exzenter, Sensor.",
            "CCC/CIC iDrive: häufige Bus-Kommunikationsfehler U-Codes.",
        ],
        "common_dtcs": ["P0087", "P0234", "P0299", "P1017", "P1025",
                        "P0171", "P0174", "P1128", "P0420", "U0073"],
    },
    "bmw_f10_520d": {
        "name": "BMW F10/F11 520d/530d",
        "brand": "BMW", "brand_code": "bmw",
        "engine": "N47/N57 2.0–3.0L Diesel", "years": "2010–2017",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k / FlexRay",
        "modules": BMW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "N47: Steuerkette HINTEN — typische Kettenrasseln → P0016/P0017 → TEUER.",
            "DPF-Regeneration: passiv/aktiv. P2002 = Partikelsensor. AdBlue/SCR: P20EE.",
            "EGR-Kühler (N47): Risse, Wasser im Ansaugtrakt → P0401/P0402.",
            "Swirl-Klappe (N47): Bruch → Sauggeräusch, P2015.",
        ],
        "common_dtcs": ["P0016", "P0087", "P0088", "P2002", "P0401",
                        "P2015", "P20EE", "P0234", "P0299", "U0073"],
    },
    "bmw_g30_540i": {
        "name": "BMW G30/G31 540i/M550i",
        "brand": "BMW", "brand_code": "bmw",
        "engine": "B58 3.0L TwinScroll / S63 V8", "years": "2017+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / Ethernet",
        "modules": BMW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "B58: Wassereinspritzung (optional). Kühlmittelverlust → Zylinderkopf.",
            "48V-Mildhybrid (B58/B48 ab 2020): HV-Netz-Kommunikation prüfen.",
            "Fahrdynamiksystem: FlexRay-Bus → spezielle Diagnose erforderlich.",
        ],
        "common_dtcs": ["P0171", "P0174", "P0300", "P0087", "P2015",
                        "P20EE", "U0073", "U0100", "P0597", "P0420"],
    },

    # ──────────────────────────── MERCEDES ───────────────────────────
    "mercedes_c220_w205": {
        "name": "Mercedes C-Klasse W205 C220d",
        "brand": "Mercedes-Benz", "brand_code": "mercedes",
        "engine": "OM651/OM654 2.1–2.0L Diesel", "years": "2014+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k / LIN",
        "modules": MERCEDES_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "OM651: Saugnapf-Riss (Balance-Shaft-Schaden) bei hohen Laufleistungen.",
            "SCR/AdBlue: P20EE Dosierpumpe/Einspritzventil häufig.",
            "7G-Tronic: P0700/P0730 → Ventilblock, Dichtungen.",
            "EGR-Kühler: Risse → P0401, Wasser in Ansaugung.",
        ],
        "common_dtcs": ["P0087", "P0234", "P20EE", "P0401", "P0700",
                        "P0730", "P2002", "P0299", "P0191", "U0073"],
    },
    "mercedes_e350_w213": {
        "name": "Mercedes E-Klasse W213 E350/E400",
        "brand": "Mercedes-Benz", "brand_code": "mercedes",
        "engine": "M276 3.0L V6 / M264 2.0L Turbo", "years": "2016+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / Ethernet",
        "modules": MERCEDES_MODULES, "pids": BASE_PIDS,
        "notes": [
            "M276 V6: Nockenwellenversteller-Leckage → P0010/P0011/P0020.",
            "9G-Tronic: Adaptionswerte nach Getriebeöl-Wechsel zurücksetzen.",
            "AIRMATIC-Luftfederung: C-/E-Codes → Kompressor, Ventilblock, Bälge.",
            "MBUX/Burmester: Ethernet-Backbone; Bus-Fehler selten mit ELM327.",
        ],
        "common_dtcs": ["P0011", "P0014", "P0171", "P0174", "P0700",
                        "P0087", "P0340", "P0300", "U0073", "P0420"],
    },
    "mercedes_sprinter_om651": {
        "name": "Mercedes Sprinter 313–519 CDI",
        "brand": "Mercedes-Benz", "brand_code": "mercedes",
        "engine": "OM651 2.1L / OM642 3.0L V6 Diesel", "years": "2006–2018",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": MERCEDES_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "OM651 (4-Zyl): Balance-Shaft-Lager verschleißt → Motorschaden. Ölwechsel 10k!",
            "DPF: häufig verstopft im Kurzstreckenbetrieb → P2002, erzwungene Regen.",
            "Injektoren (Piezo): Leckage → Leistungsverlust, P0201–P0204.",
            "Adblue/SCR ab Euro 6: P20EE Dosiersystem, Leitungen einfrieren.",
        ],
        "common_dtcs": ["P0087", "P0088", "P0201", "P0202", "P0203", "P0204",
                        "P2002", "P20EE", "P0299", "P0234", "U0073"],
    },

    # ──────────────────────────── VW ─────────────────────────────────
    "vw_golf7_tsi": {
        "name": "VW Golf VII 1.4 TSI / 1.5 TSI",
        "brand": "Volkswagen", "brand_code": "vw",
        "engine": "EA211 1.4–1.5L TSI", "years": "2012–2020",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / LIN",
        "modules": VW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "EA211 ACT (Zylinderabschaltung): P0300/P0301/P0303 bei Abschalt-Rütteln → Ölpumpe.",
            "Steuerkette: P0016 Nockenwellen-/Kurbelwellenkorrelation.",
            "DSG 7-Gang (DQ200): Mechatronik häufig → P17BF, P189A, ruckartig schalten.",
            "RCD/RNS: CAN-Gateway trennt bei Fehlern → U0073, U0155.",
        ],
        "common_dtcs": ["P0016", "P0300", "P0171", "P17BF", "P189A",
                        "P0420", "P0087", "U0073", "U0155", "P0340"],
    },
    "vw_golf7_tdi": {
        "name": "VW Golf VII 2.0 TDI",
        "brand": "Volkswagen", "brand_code": "vw",
        "engine": "EA288 2.0L TDI (CR)", "years": "2013–2020",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Dieselgate-Motoren (EA288): SCR-System empfindlich → P20EE, P2BAC.",
            "EGR-Kühler: Risse typisch bei hohen Laufleistungen → P0401.",
            "Injektoren-Kalibrierung (IMA-Werte) nach Wechsel per VCDS eingeben.",
            "DPF: Zwangsregeneration bei >95% Beladung notwendig.",
        ],
        "common_dtcs": ["P0087", "P0088", "P20EE", "P2BAC", "P0401",
                        "P2002", "P0299", "P0234", "P0191", "U0073"],
    },
    "vw_passat_b8": {
        "name": "VW Passat B8 / Arteon",
        "brand": "Volkswagen", "brand_code": "vw",
        "engine": "EA888 1.8–2.0L TSI / EA288 2.0L TDI", "years": "2014+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / LIN",
        "modules": VW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "EA888 Gen3: Ölverbrauch durch Kolbenringe/Turbo. P0011 Nockenwelle.",
            "DSG 7G DQ381 (4MOTION): P17BF Mechatronik, Ölwechsel 60k.",
            "Aktive Dämpfer DCC: Sensor- und Ventilblock-Fehler.",
        ],
        "common_dtcs": ["P0011", "P0014", "P0087", "P0171", "P17BF",
                        "P0300", "P0420", "U0073", "U0155", "P0597"],
    },
    "vw_t6_tdi": {
        "name": "VW Transporter T6 2.0 TDI",
        "brand": "Volkswagen", "brand_code": "vw",
        "engine": "EA288 2.0L TDI (CAAB/CXHA)", "years": "2015+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "SCR/AdBlue: Einspritzventil einfriert bei Frost → P20EE.",
            "DPF-Verstopfung im Kurzstreckenbetrieb sehr häufig.",
            "DSG 7-Gang (DQ500): robust, aber Ölwechsel 60k.",
        ],
        "common_dtcs": ["P0087", "P20EE", "P2002", "P0299", "P0401",
                        "P0234", "P0191", "U0073", "P0700", "P2BAC"],
    },

    # ──────────────────────────── AUDI ───────────────────────────────
    "audi_a4_b8_tfsi": {
        "name": "Audi A4/A5 B8 2.0 TFSI",
        "brand": "Audi", "brand_code": "audi",
        "engine": "EA888 Gen1/Gen2 2.0L TFSI", "years": "2007–2015",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "EA888 Gen1/2: Ölverbrauch (Kolbenringe) → P0011, Blaurauch.",
            "Steuerkette (Spanner): P0016/P0017 → häufig bei >120k km.",
            "Saugrohrklappen-Drallklappen: P2015 (Stellmotor bricht).",
            "HPFP (Hochdruckpumpe): P0087 → Nocken auf Antriebswelle verschleißt.",
        ],
        "common_dtcs": ["P0011", "P0016", "P2015", "P0087", "P0171",
                        "P0174", "P0300", "P0420", "U0073", "P0597"],
    },
    "audi_a6_c7_tdi": {
        "name": "Audi A6/A7 C7 3.0 TDI",
        "brand": "Audi", "brand_code": "audi",
        "engine": "CGQB/CLAA 3.0L V6 TDI", "years": "2011–2018",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k / MOST",
        "modules": VW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "V6 TDI 3.0: Ölkühler-Dichtung leckt → Ölverlust in Kühlmittel.",
            "SCR/AdBlue (Euro 5/6): P20EE, P2BAC häufig.",
            "7G-Doppelkupplung S-Tronic (DL501): Mechatronik/Bremsbandverschleiß.",
            "Luftfederung (Luftfahrwerk): C-Codes → Kompressor, Ventilblock.",
        ],
        "common_dtcs": ["P0087", "P20EE", "P0401", "P2002", "P0299",
                        "P0234", "P2BAC", "U0073", "P0700", "P0191"],
    },
    "audi_q7_tdi": {
        "name": "Audi Q7 3.0/4.2 TDI",
        "brand": "Audi", "brand_code": "audi",
        "engine": "CLAA/CRCA 3.0L / CDVA 4.2L V8 TDI", "years": "2006–2015",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "4.2L V8 TDI: Injektoren-Leckage → Startprobleme, P0200er.",
            "Luftfederung: Kompressor verschleißt → C-Codes, Schräglage.",
            "DPF: Häufige Regen nötig durch Fahrzeuggewicht/Kurzstrecke.",
        ],
        "common_dtcs": ["P0087", "P0201", "P0202", "P0203", "P0204",
                        "P20EE", "P2002", "P0299", "U0073", "P0191"],
    },

    # ──────────────────────────── SKODA ──────────────────────────────
    "skoda_octavia_tsi": {
        "name": "Škoda Octavia III 1.4/1.8 TSI",
        "brand": "Škoda", "brand_code": "skoda",
        "engine": "EA211 1.4L / EA888 1.8L TSI", "years": "2013–2020",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Identisch zur VW-Plattform MQB — alle VW Golf VII Hinweise gelten.",
            "DSG 6G DQ250 (1.8 TSI): Kupplungsbeläge verschleißen → ruckelt kalt.",
        ],
        "common_dtcs": ["P0016", "P0300", "P0171", "P17BF", "P0420",
                        "P0087", "U0073", "U0155", "P0011", "P0340"],
    },
    "skoda_superb_tdi": {
        "name": "Škoda Superb III 2.0 TDI",
        "brand": "Škoda", "brand_code": "skoda",
        "engine": "EA288 2.0L TDI", "years": "2015+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Passat B8 Plattform — alle TDI-Hinweise des Passat gelten.",
            "DPF-Regeneration: Kurzstrecke → P2002. Regenerationsfahrt empfohlen.",
        ],
        "common_dtcs": ["P0087", "P20EE", "P2002", "P0401", "P0299",
                        "P0234", "P0191", "U0073", "P0700", "P2BAC"],
    },

    # ──────────────────────────── SEAT ───────────────────────────────
    "seat_leon_cupra": {
        "name": "SEAT León Cupra / FR 1.8/2.0 TSI",
        "brand": "SEAT", "brand_code": "seat",
        "engine": "EA888 1.8–2.0L TSI", "years": "2012+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": VW_MODULES, "pids": BASE_PIDS,
        "notes": [
            "MQB-Plattform — identisch Golf VII/Octavia TSI.",
            "2.0 TFSI 300 PS (EA888 Gen3): Wassereinspritzung optional.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0087", "P0300", "P0171",
                        "P17BF", "P0420", "U0073", "P0597", "P0340"],
    },

    # ──────────────────────────── PORSCHE ────────────────────────────
    "porsche_911_992": {
        "name": "Porsche 911 (992) / Carrera",
        "brand": "Porsche", "brand_code": "porsche",
        "engine": "MA1.01 3.0L TwinTurbo Boxer-6", "years": "2019+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN FD / Ethernet",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "CAN FD (500k/2M): Standard-ELM327 nur eingeschränkt kompatibel.",
            "PDK 8G: Adaptionswerte nach Öl/Kupplung-Wechsel zurücksetzen.",
            "PCM 6.0: Diagnose über PIWIS am effektivsten — OBD II Subset verfügbar.",
        ],
        "common_dtcs": ["P0300", "P0171", "P0174", "P0087", "P0234",
                        "P0299", "U0073", "P0597", "P0340", "P0420"],
    },
    "porsche_cayenne_958": {
        "name": "Porsche Cayenne 958 V6/V8",
        "brand": "Porsche", "brand_code": "porsche",
        "engine": "CGEA 3.6L V6 / CXWA 4.8L V8 Turbo", "years": "2010–2018",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Baugleich Touareg/Q7 — VW-Codierung vieles erreichbar.",
            "Luftfederung: Kompressor häufig defekt → C-Codes.",
            "V8 Turbo: Turbo-Verbindungsrohre (Intercooler) lecken → P0299.",
        ],
        "common_dtcs": ["P0011", "P0014", "P0299", "P0234", "P0171",
                        "P0174", "P0087", "U0073", "P0420", "P0597"],
    },

    # ──────────────────────────── TOYOTA ─────────────────────────────
    "toyota_yaris_1nz": {
        "name": "Toyota Yaris / Verso 1.0–1.33",
        "brand": "Toyota", "brand_code": "toyota",
        "engine": "1KR-FE 1.0L / 1NR-FE 1.33L", "years": "2005+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": TOYOTA_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Sehr robust. P0420 Kat-Alterung häufig ab >150k km.",
            "VVT-i: P0010/P0011 bei Ölmangel/schlechtem Öl.",
            "Drosselklappe reinigen alle 60k km empfohlen.",
        ],
        "common_dtcs": ["P0420", "P0010", "P0011", "P0171", "P0300",
                        "P0335", "P0340", "U0073", "P0505", "P0113"],
    },
    "toyota_camry_v6": {
        "name": "Toyota Camry 2.5/3.5 V6",
        "brand": "Toyota", "brand_code": "toyota",
        "engine": "2AR-FE 2.5L / 2GR-FE 3.5L V6", "years": "2006+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": TOYOTA_MODULES, "pids": BASE_PIDS,
        "notes": [
            "2GR-FE V6: Kühlmittelverlust über Ansaugbrücken-Dichtungen (2007-2009).",
            "2AR-FE: Ölverbrauch (Kolbenring-TSB) → Reparaturpaket verfügbar.",
            "Getriebeadaption: nach Ölwechsel Lernfahrt durchführen.",
        ],
        "common_dtcs": ["P0420", "P0430", "P0011", "P0171", "P0174",
                        "P0300", "P0335", "U0073", "P0446", "P0441"],
    },
    "toyota_prius_gen3": {
        "name": "Toyota Prius / Auris HSD (Gen 3)",
        "brand": "Toyota", "brand_code": "toyota",
        "engine": "2ZR-FXE 1.8L Atkinson + Hybrid", "years": "2009–2016",
        "bitrate": "500k", "fuel": "hybrid", "network": "CAN 500k",
        "modules": TOYOTA_MODULES, "pids": HYBRID_PIDS,
        "notes": [
            "HV-Batterie (NiMH): Zell-Balancing. P0A80 = Kapazitätsverlust.",
            "Inversions-/Konverter-Kühlung: eigener Kühlkreislauf prüfen.",
            "Inverter-Fehler: P0A09/P3101 → HV-Spannung mit Vorsicht messen.",
            "TRAC/VSC: oft mit HV-Fehler kombiniert.",
        ],
        "common_dtcs": ["P0A80", "P0A09", "P3101", "P0420", "P0011",
                        "P0171", "P0300", "U0073", "P0446", "C1241"],
    },
    "toyota_land_cruiser_1vd": {
        "name": "Toyota Land Cruiser 200 4.5 V8 D",
        "brand": "Toyota", "brand_code": "toyota",
        "engine": "1VD-FTV 4.5L V8 Diesel TwinTurbo", "years": "2007+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": TOYOTA_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "1VD-FTV: Steuerkettenspanner hinten links verschleißt → P0016.",
            "Turbo: Stellmotoren (elektrisch) der variablen Turbinen → P0234.",
            "EGR: Verkokung der Ladeluftstrecke → P0401.",
        ],
        "common_dtcs": ["P0016", "P0087", "P0088", "P0234", "P0401",
                        "P0191", "P0299", "P2002", "U0073", "P0340"],
    },

    # ──────────────────────────── HONDA ──────────────────────────────
    "honda_civic_k20": {
        "name": "Honda Civic VIII/IX 1.8 i-VTEC",
        "brand": "Honda", "brand_code": "honda",
        "engine": "R18/K20 1.8–2.0L i-VTEC", "years": "2006+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "VTEC-Solenoid: P2646/P2647 → niedriger Öldruck oder Solenoid defekt.",
            "VTC (Variable Valve Timing): P0341/P0344 Nockenwellensensor.",
            "Kette + VTC-Aktuator: Rasseln kalt → P0011.",
        ],
        "common_dtcs": ["P2646", "P2647", "P0341", "P0011", "P0300",
                        "P0420", "P0171", "P0341", "U0073", "P0335"],
    },
    "honda_crv_diesel": {
        "name": "Honda CR-V 1.6 i-DTEC",
        "brand": "Honda", "brand_code": "honda",
        "engine": "N16A 1.6L Diesel", "years": "2013–2019",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "DPF-Verstopfung im Kurzstreckenbetrieb: häufiges Problem.",
            "Ölverdünnung durch DPF-Regen (Benzin in Öl) → Ölwechsel-Intervall kürzen.",
            "EGR-Verkokung → P0401, Leistungsverlust.",
        ],
        "common_dtcs": ["P2002", "P0087", "P0401", "P0299", "P0191",
                        "P0234", "U0073", "P0340", "P0088", "P20EE"],
    },

    # ──────────────────────────── FORD ───────────────────────────────
    "ford_focus_ecoboost": {
        "name": "Ford Focus III 1.0/1.5/2.0 EcoBoost",
        "brand": "Ford", "brand_code": "ford",
        "engine": "Fox 1.0L / Dragon 1.5L EcoBoost", "years": "2011+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "1.0 EcoBoost: Kühlmittelverlust durch gerissene Zylinderköpfe (Gen 1 bis 2015).",
            "Steuerkette (Fox 1.0): P0016 bei >80k km häufig.",
            "PowerShift DSG: P0730/P0711 → Kupplung trocken, Rucken kalt.",
        ],
        "common_dtcs": ["P0016", "P0300", "P0171", "P0087", "P0730",
                        "P0711", "P0420", "U0073", "P0340", "P0597"],
    },
    "ford_transit_tdci": {
        "name": "Ford Transit 2.0/2.2 TDCi",
        "brand": "Ford", "brand_code": "ford",
        "engine": "Puma/Duratorq 2.0–2.2L TDCi", "years": "2006+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Duratorq 2.2: EGR-Kühler Risse → P0401, Wasser in Ansaugung.",
            "Injektoren (Siemens/Continental Piezo): Rückfluss erhöht → Leistungsverlust.",
            "DPF: häufig verstopft → P2002, erzwungene Regen via Software.",
        ],
        "common_dtcs": ["P0087", "P0401", "P2002", "P0299", "P0191",
                        "P0234", "U0073", "P0201", "P0202", "P0700"],
    },
    "ford_mustang_v8": {
        "name": "Ford Mustang GT 5.0 V8 (S550)",
        "brand": "Ford", "brand_code": "ford",
        "engine": "Coyote 5.0L Ti-VCT V8", "years": "2015+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / MS-CAN",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Coyote Gen2/3: Ölverdünnung durch Direkt-Einspritzung → Ölwechsel 8k.",
            "Ti-VCT: P0011/P0012/P0021/P0022 Nockenwellenversteller-Steuerung.",
            "MS-CAN (125k): Body-Module oft nicht über Standard-OBD erreichbar.",
        ],
        "common_dtcs": ["P0011", "P0021", "P0171", "P0174", "P0300",
                        "P0420", "P0430", "U0073", "P0087", "P0340"],
    },

    # ──────────────────────────── OPEL / VAUXHALL ────────────────────
    "opel_astra_j_opc": {
        "name": "Opel Astra J 1.4T / 2.0 OPC",
        "brand": "Opel", "brand_code": "opel",
        "engine": "A14NET 1.4L / A20NFT 2.0L Turbo", "years": "2009–2016",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "A14NET: Steuerkette (Kettenspanner) → P0016 häufig.",
            "A20NFT OPC: Kolbenringe verschleißen → Ölverbrauch, Blaurauch.",
            "Drosselklappe: Kohlenstoff-Ablagerungen → P0506, P2101.",
        ],
        "common_dtcs": ["P0016", "P0300", "P0171", "P0087", "P2101",
                        "P0506", "P0420", "U0073", "P0340", "P0597"],
    },
    "opel_insignia_cdti": {
        "name": "Opel Insignia 2.0 CDTI",
        "brand": "Opel", "brand_code": "opel",
        "engine": "A20DTH/A20DTJ 2.0L CDTI", "years": "2008–2017",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Turboladerdruck-Stellglieder (elektrisch): P0046/P0047.",
            "EGR-Kühler: Risse → Ölkontamination im Ansaugtrakt.",
            "DPF: Zwangsregen bei >80% Beladung, Kurzstrecke kritisch.",
        ],
        "common_dtcs": ["P0087", "P0046", "P0047", "P0401", "P2002",
                        "P0299", "P0234", "P0191", "U0073", "P0700"],
    },

    # ──────────────────────────── PEUGEOT / CITROËN ──────────────────
    "peugeot_308_thp": {
        "name": "Peugeot 308 / 3008 THP 130/150",
        "brand": "Peugeot", "brand_code": "peugeot",
        "engine": "EP6CDT 1.6L THP", "years": "2007–2016",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "EP6/THP: Steuerketten-Spanner (Simplex) häufig defekt → P0016, Kettenrasseln.",
            "Ölverbrauch: Kolbenringe → Blaurauch, P0171.",
            "VVT-Versteller: Ölmangel → P0010/P0011 → Motorschaden möglich.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0010", "P0171", "P0300",
                        "P0087", "P0420", "U0073", "P0340", "P1336"],
    },
    "citroen_c5_hdi": {
        "name": "Citroën C5 II 1.6/2.0 HDi",
        "brand": "Citroën", "brand_code": "citroen",
        "engine": "DV6/DW10 1.6–2.0L HDi (Common Rail)", "years": "2004–2017",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Hydractive-Federung (III): Druckspeicher/Pumpe → C-Codes.",
            "DPF: verstopft im Stadtverkehr → P2002, FAP-Regeneration.",
            "EGR-Kühler (DW10): Risse → Wasser in Ansaugung, P0401.",
        ],
        "common_dtcs": ["P0087", "P0401", "P2002", "P0299", "P0191",
                        "P0234", "U0073", "P0340", "C1300", "P20EE"],
    },

    # ──────────────────────────── RENAULT ────────────────────────────
    "renault_megane_tce": {
        "name": "Renault Mégane III/IV TCe 115–205",
        "brand": "Renault", "brand_code": "renault",
        "engine": "H4J/H4Bt 1.2–1.8L TCe Turbo", "years": "2012+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "H4J 1.2 TCe: Steuerketten-Spanner verschleißt früh → P0016.",
            "RS 1.8 TCe: BEL-Turbo robust, Wastegate kontrollieren.",
            "Kupplung EDC (Easy Dual Clutch): Ruckeln kalt → P0730.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0171", "P0300", "P0730",
                        "P0087", "P0420", "U0073", "P0340", "P0597"],
    },

    # ──────────────────────────── FIAT / ALFA ────────────────────────
    "fiat_500_twinair": {
        "name": "Fiat 500 / Punto TwinAir 85/105",
        "brand": "Fiat", "brand_code": "fiat",
        "engine": "312A2 0.9L TwinAir Turbo", "years": "2010+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "TwinAir 0.9: Steuerkettenspanner verschleißt → P0016. Ölwechsel 10k!",
            "MultiAir Aktuator: elektrohydraulisch → P0010/P0011 bei Ölproblemen.",
            "Sehr hoher Ölverbrauch normal (0.5L/1000 km) — prüfen wenn höher.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0010", "P0300", "P0171",
                        "P0087", "P0420", "U0073", "P0340", "P0113"],
    },
    "alfa_giulia_q4": {
        "name": "Alfa Romeo Giulia / Stelvio 2.0T",
        "brand": "Alfa Romeo", "brand_code": "alfa",
        "engine": "GME 2.0L Turbo (Giorgio Plattform)", "years": "2016+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / Ethernet",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "GME 2.0T: Kühlmittelverlust über Thermostatgehäuse (frühes Modell).",
            "ZF 8HP Automatik: robust, Ölwechsel 80k empfohlen.",
            "DNA-Schalter: Fahrmodus-Fehler → U-Codes.",
        ],
        "common_dtcs": ["P0011", "P0171", "P0300", "P0087", "P0597",
                        "P0420", "U0073", "P0340", "P0700", "P0730"],
    },

    # ──────────────────────────── JEEP / CHRYSLER / DODGE ────────────
    "jeep_cherokee_kl": {
        "name": "Jeep Cherokee KL 2.0/2.4 / 3.2 V6",
        "brand": "Jeep", "brand_code": "jeep",
        "engine": "ED6/ED3/Pentastar 3.2L V6", "years": "2014+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN-C 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "9HP48 ZF-Automatik (9-Gang): P0730 Gangwechsel-Fehler → Lernwerte.",
            "Pentastar 3.2: VVT P0010/P0011/P0020/P0021. Steuerkette ab >120k.",
            "Firefly/ED6 2.0T: Kühlmittelkanäle im Kopf rissanfällig.",
        ],
        "common_dtcs": ["P0010", "P0011", "P0020", "P0021", "P0300",
                        "P0730", "U0100", "U0140", "P0128", "P0522"],
    },
    "dodge_challenger_v8": {
        "name": "Dodge Challenger / Charger V8 (5.7/6.4 HEMI)",
        "brand": "Dodge", "brand_code": "dodge",
        "engine": "5.7L/6.4L HEMI V8 (MDS)", "years": "2008+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN-C 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "MDS (Zylinderabschaltung 8→4): Solenoid-Verschleiß → P0300–P0308.",
            "Steuerkette: Korrelation P0016/P0017 ab >150k km.",
            "TIPM (Sicherungsbox): Kraftstoffpumpen-Relais → U0140/U0141.",
        ],
        "common_dtcs": ["P0016", "P0017", "P0300", "P0301", "P0128",
                        "P0339", "P0522", "P0700", "U0100", "U0140"],
    },
    "chrysler_300c_hemi": {
        "name": "Chrysler 300C / Lancia Thema HEMI",
        "brand": "Chrysler", "brand_code": "chrysler",
        "engine": "5.7L HEMI V8 / 3.6L Pentastar V6", "years": "2011+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN-C 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Identisch Dodge Charger — alle HEMI Hinweise gelten.",
            "8HP70 ZF-Automatik: sehr robust, Ölwechsel 80k empfohlen.",
        ],
        "common_dtcs": ["P0016", "P0300", "P0128", "P0339", "P0522",
                        "P0700", "U0100", "U0140", "P0011", "P0021"],
    },

    # ──────────────────────────── FORD (USA) ─────────────────────────
    "ford_f150_ecoboost": {
        "name": "Ford F-150 2.7/3.5L EcoBoost V6",
        "brand": "Ford", "brand_code": "ford",
        "engine": "EcoBoost 2.7L / 3.5L TwinTurbo V6", "years": "2011+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / MS-CAN",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "3.5 EcoBoost Gen1: Intercooler-Kondensat P0087. Gen2 gefixt.",
            "Phasermotor (Turbo): P0022/P0012 bei Kettenspanner.",
            "10R80 Automatik (ab 2017): robust, Ölwechsel 60k.",
        ],
        "common_dtcs": ["P0087", "P0012", "P0022", "P0300", "P0171",
                        "P0174", "P0420", "P0430", "U0073", "P0340"],
    },
    "ford_explorer_ecoboost": {
        "name": "Ford Explorer 2.3/3.5 EcoBoost",
        "brand": "Ford", "brand_code": "ford",
        "engine": "EcoBoost 2.3L / 3.5L TwinTurbo", "years": "2013+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "3.5 TwinTurbo: Intercooler-Kondensation → P0087 bei Kaltstart.",
            "2.3 EcoBoost: Steuerkette P0016. Ölverbrauch kontrollieren.",
        ],
        "common_dtcs": ["P0087", "P0016", "P0300", "P0171", "P0174",
                        "P0420", "P0430", "U0073", "P0340", "P0597"],
    },

    # ──────────────────────────── CHEVROLET / GMC ────────────────────
    "chevrolet_cruze_14t": {
        "name": "Chevrolet Cruze / Opel Astra K 1.4T",
        "brand": "Chevrolet", "brand_code": "chevrolet",
        "engine": "LE2/LUJ 1.4L Ecotec Turbo", "years": "2011+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "1.4T Ecotec: Kühlmittelverlust durch Thermostatgehäuse-Risse.",
            "Steuerkette P0016 ab >100k km häufig.",
            "Kupplung (Schaltgetriebe): Ausrücklager/Kupplung früh.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0171", "P0087", "P0300",
                        "P0420", "U0073", "P0597", "P0340", "P0113"],
    },
    "chevrolet_silverado_v8": {
        "name": "Chevrolet Silverado / GMC Sierra V8",
        "brand": "Chevrolet", "brand_code": "chevrolet",
        "engine": "L83/L86 5.3L / 6.2L EcoTec3 V8 (AFM)", "years": "2014+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "AFM (4-Zyl-Abschaltung): Lifter-Verschleiß → P0300er. AFM-Deaktivierung empfohlen.",
            "5.3L: Ölverbrauch durch AFM-Kolbenringe bis TSB.",
            "8L90 Automatik: Shudder (Vibrieren) bei 40–60 km/h → Flüssigkeit.",
        ],
        "common_dtcs": ["P0300", "P0301", "P0171", "P0174", "P0087",
                        "P0016", "P0420", "P0430", "U0073", "P0340"],
    },

    # ──────────────────────────── MAZDA ──────────────────────────────
    "mazda_cx5_skyactiv": {
        "name": "Mazda CX-5 / Mazda 6 SKYACTIV-G/D",
        "brand": "Mazda", "brand_code": "mazda",
        "engine": "PE-VPS 2.0/2.5L SKYACTIV-G / SH-VPTS 2.2L SKYACTIV-D", "years": "2012+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "SKYACTIV-D 2.2: DPF-Probleme im Kurzstreckenbetrieb → P2002.",
            "SKYACTIV-G: sehr hohe Verdichtung (14:1) → Premium-Kraftstoff empfohlen.",
            "i-ACTIV AWD: Kupplungssteuergerät → C-Codes.",
        ],
        "common_dtcs": ["P2002", "P0087", "P0401", "P0420", "P0011",
                        "P0300", "U0073", "P0340", "P0299", "P20EE"],
    },

    # ──────────────────────────── HYUNDAI / KIA ──────────────────────
    "hyundai_i30_14t": {
        "name": "Hyundai i30 / Kia Ceed 1.0–1.4 T-GDI",
        "brand": "Hyundai", "brand_code": "hyundai",
        "engine": "G3LC/G4LC 1.0–1.4L T-GDI", "years": "2017+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "G4LC 1.4 T-GDI: Direkteinspritzung → Öleinspritzung Ventile reinigen.",
            "Steuerkette: P0016 ab >80k km bei mangelndem Öl.",
            "DCT 7-Gang: Ruckeln kalt, Kupplung-Adaption.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0171", "P0300", "P0087",
                        "P0420", "U0073", "P0597", "P0340", "P0730"],
    },
    "kia_sportage_crdi": {
        "name": "Kia Sportage / Tucson 2.0 CRDi",
        "brand": "Kia", "brand_code": "kia",
        "engine": "D4HA 2.0L CRDi", "years": "2010+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "D4HA: Steuerkette P0016 ab >100k km.",
            "DPF: Kurzstrecke → P2002. Regenerationsfahrt bei Autobahn.",
            "EGR-Ventil: Verkokung → P0401, Leistungsverlust.",
        ],
        "common_dtcs": ["P0016", "P0087", "P0401", "P2002", "P0299",
                        "P0234", "U0073", "P0191", "P0340", "P20EE"],
    },

    # ──────────────────────────── NISSAN ─────────────────────────────
    "nissan_qashqai_dci": {
        "name": "Nissan Qashqai / X-Trail 1.5–2.0 dCi",
        "brand": "Nissan", "brand_code": "nissan",
        "engine": "K9K/R9M/M9R 1.5–2.0L dCi", "years": "2007+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "K9K: Injektoren (Delphi) → Rückfluss erhöht, Leistungsverlust, P0201–P0204.",
            "R9M 1.6 dCi: Steuerkette P0016 häufig.",
            "DPF: Adblue/SCR ab Euro 6 → P20EE.",
        ],
        "common_dtcs": ["P0087", "P0201", "P0202", "P0016", "P0401",
                        "P2002", "P20EE", "P0299", "P0191", "U0073"],
    },
    "nissan_gtr_r35": {
        "name": "Nissan GT-R R35",
        "brand": "Nissan", "brand_code": "nissan",
        "engine": "VR38DETT 3.8L TwinTurbo V6", "years": "2007+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "VR38DETT: Aufladung über Twin-Turbo. P0234/P0299 bei Boost-Leckage.",
            "Getriebe (GR6 DSG): Öltemperatur überwachen bei Track-Einsatz.",
            "Eigendiagnose-Menü: Fahrzeug-Display bietet erweiterte Daten.",
        ],
        "common_dtcs": ["P0234", "P0299", "P0087", "P0171", "P0174",
                        "P0300", "P0420", "P0430", "U0073", "P0340"],
    },

    # ──────────────────────────── SUBARU ─────────────────────────────
    "subaru_outback_fb25": {
        "name": "Subaru Outback / Legacy FB25",
        "brand": "Subaru", "brand_code": "subaru",
        "engine": "FB25 2.5L Boxer-4 / EJ257 2.5L Turbo", "years": "2010+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "EJ257 (WRX STi): Kolben-Ringverschleiß → Ölverbrauch, P0300.",
            "CVT Lineartronic: Ölwechsel alle 40k → P0700 bei Überhitzung.",
            "AWD-Differenzial: Kupplungsöl nie mit Hinterachsenöl mischen.",
        ],
        "common_dtcs": ["P0011", "P0014", "P0300", "P0171", "P0087",
                        "P0420", "U0073", "P0597", "P0700", "P0340"],
    },

    # ──────────────────────────── VOLVO ──────────────────────────────
    "volvo_xc60_d5": {
        "name": "Volvo XC60/XC90 D4/D5",
        "brand": "Volvo", "brand_code": "volvo",
        "engine": "D5244T/D4204T 2.0–2.4L Diesel", "years": "2008+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k / LIN",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "D5244T: EGR-Kühler Risse → P0401, Wasser in Ansaugung.",
            "DPF: Erzwungene Regen bei >85% Beladung → Autobahn 15 Min.",
            "Geartronic 6-Gang: Ventilblock-Fehler → P0700/P0730.",
        ],
        "common_dtcs": ["P0087", "P0401", "P2002", "P0299", "P0700",
                        "P0730", "P20EE", "P0191", "U0073", "P0234"],
    },
    "volvo_v60_t6": {
        "name": "Volvo V60/S60/XC60 T5/T6 AWD",
        "brand": "Volvo", "brand_code": "volvo",
        "engine": "B4204T/B4194T 2.0L Drive-E Turbo", "years": "2014+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Drive-E 2.0T: Steuerkette P0016 ab >80k. Ölwechsel 10k!",
            "T6 AWD: Haldex Gen5 Kupplung → Ölwechsel alle 3 Jahre.",
            "VIDA/DiCE: vollständige Diagnose empfohlen. OBD II: Subset.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0087", "P0171", "P0300",
                        "P0420", "U0073", "P0597", "P0340", "P0700"],
    },

    # ──────────────────────────── LAND ROVER / RANGE ROVER ──────────
    "land_rover_discovery_tdv6": {
        "name": "Land Rover Discovery 4 / RR Sport TDV6",
        "brand": "Land Rover", "brand_code": "landrover",
        "engine": "306DT 3.0L V6 Diesel TwinTurbo", "years": "2009+",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN 500k / LIN",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "306DT: Ölkühler-Dichtungen lecken → P0087, Öl in Kühlmittel.",
            "Luftfederung: Kompressor/Ventilblock häufig → C-Codes.",
            "ZF 8HP: robust, Ölwechsel 80k empfohlen.",
            "EGR: Verkokung → P0401. AGR-Kühler Risse.",
        ],
        "common_dtcs": ["P0087", "P0088", "P0401", "P0299", "P2002",
                        "P20EE", "P0191", "U0073", "P0234", "C1300"],
    },
    "range_rover_v8": {
        "name": "Range Rover L405 5.0 V8 S/C",
        "brand": "Land Rover", "brand_code": "landrover",
        "engine": "508PN 5.0L V8 Supercharged", "years": "2012+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / LIN",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "5.0 V8: Timing-Chain-Spanner verschleißt (v.a. Gen1) → P0016.",
            "Supercharger: Snout-Lager → Pfeifen. P0087 bei Boost-Leckage.",
            "Luftfederung: Kompressor/Bälge → C-Codes.",
        ],
        "common_dtcs": ["P0016", "P0087", "P0300", "P0171", "P0174",
                        "P0420", "P0430", "U0073", "P0340", "C1300"],
    },

    # ──────────────────────────── MITSUBISHI ─────────────────────────
    "mitsubishi_outlander_phev": {
        "name": "Mitsubishi Outlander PHEV",
        "brand": "Mitsubishi", "brand_code": "mitsubishi",
        "engine": "4B11 2.0L MIVEC + Dual Motor Hybrid", "years": "2013+",
        "bitrate": "500k", "fuel": "hybrid", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": HYBRID_PIDS,
        "notes": [
            "HV-Batterie (Li-Ion): Kapazitätsverlust ab >100k → P0A80.",
            "EV/HV-Modus-Umschaltung: Sensor-Fehler → P3101.",
            "Bremsen (Rekuperation): Hinten oft verrostet durch wenig Nutzung.",
        ],
        "common_dtcs": ["P0A80", "P3101", "P0A09", "P0171", "P0300",
                        "P0420", "U0073", "P0597", "P0340", "C1241"],
    },

    # ──────────────────────────── SUZUKI ─────────────────────────────
    "suzuki_vitara_boosterjet": {
        "name": "Suzuki Vitara / Swift 1.0/1.4 Boosterjet",
        "brand": "Suzuki", "brand_code": "suzuki",
        "engine": "K10C/K14C 1.0–1.4L Boosterjet", "years": "2015+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "K14C: Steuerkette P0016. Ölwechsel 10k empfohlen.",
            "6AT: robust. Mild-Hybrid ab 2019: 48V-System.",
            "AllGrip AWD: Haldex-ähnliche Kupplung → Ölwechsel 40k.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0171", "P0300", "P0087",
                        "P0420", "U0073", "P0597", "P0340", "P0113"],
    },

    # ──────────────────────────── TESLA ──────────────────────────────
    "tesla_model3": {
        "name": "Tesla Model 3 / Y (RWD / AWD)",
        "brand": "Tesla", "brand_code": "tesla",
        "engine": "Permanentmagnet-Synchronmotor (Heck/Dual)", "years": "2017+",
        "bitrate": "500k", "fuel": "elektro", "network": "CAN 500k / Ethernet",
        "modules": STD_MODULES,
        "pids": [
            (0x5B, "HV-Batterie SOC", "%"),
            (0x5D, "HV-Spannung", "V"),
            (0x0D, "Geschwindigkeit", "km/h"),
        ],
        "notes": [
            "OBD-II-Subset: Standard-PIDs beschränkt. Eigene Tesla-API für Details.",
            "HV-Batterie: SOC via PID 0x5B. Volle Daten über TM-API.",
            "Diagnose: Tesla Service-App / TM-App empfohlen. ELM327 nur Grundfunktionen.",
            "Keine Verbrenner-Codes. P-Codes nur für 12V-System und CAN-Bus.",
        ],
        "common_dtcs": ["U0073", "U0100", "U0155", "C1241", "P0A80",
                        "P0A09", "P3101", "B1000", "C1300", "U1000"],
    },

    # ──────────────────────────── DODGE (FCA) ────────────────────────
    "challenger_v6": {
        "name": "Dodge Challenger / Charger V6",
        "brand": "Dodge", "brand_code": "dodge",
        "engine": "3.5L V6 (2008-2010) / 3.6L Pentastar V6 (2011+)",
        "years": "2008+", "bitrate": "500k", "fuel": "benzin",
        "network": "CAN-C 500k / CAN-IHS 125k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Pentastar 3.6L: VVT beidseitig — P0010/P0011/P0020/P0021 bei Kettenspanner.",
            "3.5L: Ansaugklappen (Short Runner Valve) → P2004/P2016.",
        ],
        "common_dtcs": ["P0016", "P0011", "P0021", "P0128", "P0300",
                        "P0339", "P0522", "U0100", "U0140", "U0155"],
    },
    "ram_hemi_57": {
        "name": "Dodge Ram 1500 V8 5.7 HEMI",
        "brand": "Dodge", "brand_code": "dodge",
        "engine": "5.7L HEMI V8 (MDS, VVT)", "years": "2009+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN-C 500k",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "MDS (8→4 Zylinder): Solenoid/Lifter → P0300–P0308.",
            "TIPM: Kraftstoffpumpen-Relais berüchtigt → U0140/U0141.",
            "Steuerkette: P0016/P0017 ab >150k km.",
        ],
        "common_dtcs": ["P0016", "P0017", "P0300", "P0301", "P0128",
                        "P0339", "P0522", "P0700", "U0100", "U0140"],
    },
    "nitro_crd": {
        "name": "Dodge Nitro 2.8 CRD Diesel",
        "brand": "Dodge", "brand_code": "dodge",
        "engine": "2.8L CRD Turbodiesel (VM Motori)", "years": "2007–2010",
        "bitrate": "500k", "fuel": "diesel", "network": "CAN-C 500k",
        "modules": STD_MODULES, "pids": DIESEL_PIDS,
        "notes": [
            "Common-Rail 2.8: Hochdruckpumpe/MPROP, Injektor-Rückfluss.",
            "EGR/DPF bei EU-Modellen. Glühkerzen Kaltstart.",
        ],
        "common_dtcs": ["P0087", "P0088", "P0093", "P0193", "P0234",
                        "P0299", "P0380", "P0401", "P2002", "U0100"],
    },

    # ──────────────────────────── GENERISCH / UNIVERSAL ─────────────
    "generic": {
        "name": "Generisch — Alle Marken (OBD-II Standard)",
        "brand": "Universal", "brand_code": "generic",
        "engine": "-", "years": "1996+",
        "bitrate": "500k", "fuel": "benzin", "network": "CAN 500k / ISO 9141",
        "modules": STD_MODULES, "pids": BASE_PIDS,
        "notes": [
            "Standard OBD-II (SAE J1979): Alle Fahrzeuge ab BJ 1996 (USA) / 2001 (EU).",
            "Mode 01: Live-PIDs. Mode 03: Fehler auslesen. Mode 04: Fehler löschen.",
            "Erweiterte Hersteller-Codes (B/C/U) erfordern Hersteller-spezifische Protokolle.",
        ],
        "common_dtcs": [],
    },
}

# ═══════════════════════════════════════════════════════════════════════
# MARKEN-INDEX für UI-Navigation
# ═══════════════════════════════════════════════════════════════════════

BRANDS = {}
for _k, _v in VEHICLES.items():
    _b = _v.get("brand", "Sonstige")
    _bc = _v.get("brand_code", "other")
    if _bc not in BRANDS:
        BRANDS[_bc] = {"name": _b, "models": []}
    BRANDS[_bc]["models"].append({"key": _k, "name": _v["name"],
                                  "engine": _v["engine"], "years": _v["years"],
                                  "fuel": _v.get("fuel", "benzin")})


def get(key):
    return VEHICLES.get(key, VEHICLES["generic"])


def list_all():
    return [{"key": k, "name": v["name"], "engine": v["engine"],
             "bitrate": v["bitrate"], "brand": v.get("brand", ""),
             "fuel": v.get("fuel", "benzin")} for k, v in VEHICLES.items()]


def list_brands():
    return [{"code": bc, "name": bd["name"],
             "count": len(bd["models"])} for bc, bd in sorted(BRANDS.items())]


def list_by_brand(brand_code):
    return BRANDS.get(brand_code, {}).get("models", [])


def profile(key):
    v = get(key)
    return {
        "ok": True, "key": key,
        "name": v["name"], "brand": v.get("brand", ""),
        "engine": v["engine"], "years": v["years"],
        "bitrate": v["bitrate"], "network": v["network"],
        "fuel": v.get("fuel", "benzin"),
        "modules": v["modules"],
        "pids": [{"pid": f"0x{p[0]:02X}", "label": p[1], "unit": p[2]}
                 for p in v["pids"]],
        "notes": v["notes"],
        "common_dtcs": v["common_dtcs"],
    }
