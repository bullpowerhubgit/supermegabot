# -*- coding: utf-8 -*-
"""HTML-Oberflaeche fuer MacOBD-Pro (roher USB-Modus)."""

INDEX_HTML = r"""<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MacOBD-Pro · USB</title>
<style>
:root{--bg:#0a0e14;--panel:#121822;--panel2:#0e141d;--line:#1e2733;
--txt:#e6edf3;--dim:#8b98a5;--accent:#ff8c1a;--in:#22d3ee;--out:#ff8c1a;
--ok:#3fb950;--warn:#d29922;--err:#f85149;--raw:#a371f7}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);
font:14px/1.5 -apple-system,BlinkMacSystemFont,system-ui,sans-serif}
header{display:flex;align-items:center;gap:14px;padding:14px 20px;
background:linear-gradient(90deg,#121822,#0a0e14);border-bottom:1px solid var(--line)}
header .logo{width:34px;height:34px;border-radius:9px;
background:linear-gradient(135deg,var(--accent),#ff5e3a);display:grid;
place-items:center;font-weight:800;color:#0a0e14;font-size:12px}
header h1{font-size:16px;margin:0}
header .sub{color:var(--dim);font-size:12px}
.dot{width:9px;height:9px;border-radius:50%;background:var(--err);
box-shadow:0 0 8px var(--err);margin-left:auto}
.dot.on{background:var(--ok);box-shadow:0 0 10px var(--ok)}
main{max-width:1180px;margin:0 auto;padding:20px;display:grid;gap:16px}
.grid{display:grid;gap:16px}.cols{grid-template-columns:1fr 1fr}
@media(max-width:860px){.cols{grid-template-columns:1fr}}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px 18px}
.card h2{margin:0 0 12px;font-size:13px;text-transform:uppercase;letter-spacing:1px;color:var(--dim)}
select,input,button{font:inherit;color:var(--txt);background:var(--panel2);
border:1px solid var(--line);border-radius:9px;padding:9px 12px}
button{cursor:pointer;transition:.15s;font-weight:600}
button:hover{border-color:var(--accent)}
button.primary{background:var(--accent);color:#0a0e14;border-color:var(--accent)}
button.danger{border-color:#3a2020;color:var(--err)}
button.danger:hover{background:#2a1414}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
select.dev{min-width:320px;flex:1 1 auto}
input.small{width:90px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px}
.pill{display:inline-block;padding:3px 9px;border-radius:20px;font-size:12px;
background:var(--panel2);border:1px solid var(--line);color:var(--dim)}
.spacer{flex:1 1 auto}small.muted{color:var(--dim)}
table{width:100%;border-collapse:collapse;font-size:12.5px}
td,th{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--dim);font-weight:600;font-size:11px;text-transform:uppercase}
.ep{font-family:ui-monospace,monospace}
.tin{color:var(--in)}.tout{color:var(--out)}
.hint{color:var(--warn);font-size:12px}.hint.bad{color:var(--err)}.hint.good{color:var(--ok)}
#sniff{background:#05080c;border:1px solid var(--line);border-radius:10px;
padding:10px;height:320px;overflow:auto;font-family:ui-monospace,monospace;font-size:12px}
.pkt{display:grid;grid-template-columns:92px 34px 1fr;gap:8px;padding:2px 0;
border-bottom:1px solid #0f151d}
.pkt .tt{color:#44515f}.pkt .d.IN{color:var(--in)}.pkt .d.OUT{color:var(--out)}
.pkt .hx{white-space:pre-wrap;word-break:break-all}
#log{background:#05080c;border:1px solid var(--line);border-radius:10px;padding:10px;
height:150px;overflow:auto;font-family:ui-monospace,monospace;font-size:12px;white-space:pre-wrap}
#log .info{color:var(--dim)}#log .ok{color:var(--ok)}#log .warn{color:var(--warn)}
#log .err{color:var(--err)}#log .raw{color:var(--raw)}#log .t{color:#44515f}
.err-banner{background:#2a1414;border:1px solid #4a2020;color:#ff9c8f;
padding:10px 14px;border-radius:10px;font-size:13px;display:none}
.err-banner.show{display:block}
pre.sys{background:#05080c;border:1px solid var(--line);border-radius:10px;padding:10px;
max-height:260px;overflow:auto;font-size:11.5px;white-space:pre;color:var(--dim)}
</style>
</head>
<body>
<header>
  <div class="logo">USB</div>
  <div><h1>MacOBD-Pro</h1>
    <div class="sub">Roher USB-Zugriff (libusb) &middot; Deskriptor &middot; Sniffer &middot; Reverse-Engineering</div></div>
  <div id="dot" class="dot" title="getrennt"></div>
  <span class="pill" id="netBadge" style="margin-left:8px">offline</span>
</header>
<main>
  <div id="errBanner" class="err-banner"></div>

  <div class="card">
    <h2>1 · USB-Geraet waehlen</h2>
    <div class="row">
      <select id="devSel" class="dev"><option value="">— Geraete laden —</option></select>
      <button id="btnList">Aktualisieren</button>
      <button id="btnDesc">Deskriptor anzeigen</button>
      <div class="spacer"></div>
      <span class="pill" id="pStatus">getrennt</span>
    </div>
  </div>

  <div class="card" id="descCard" style="display:none">
    <h2>2 · Deskriptor · Interfaces &amp; Endpoints</h2>
    <div id="descBox"></div>
    <div class="row" style="margin-top:12px">
      <label class="muted">Interface</label>
      <input id="ifIn" class="small mono" placeholder="auto">
      <label class="muted">EP IN</label>
      <input id="epIn" class="small mono" placeholder="auto">
      <label class="muted">EP OUT</label>
      <input id="epOut" class="small mono" placeholder="auto">
      <div class="spacer"></div>
      <button id="btnOpen" class="primary">Verbinden &amp; Sniffen</button>
      <button id="btnClose" class="danger">Trennen</button>
    </div>
    <small class="muted">Leer = automatisch (erstes Interface, erster IN/OUT-Endpoint).
      Endpoints als Hex, z.B. 0x81 / 0x01.</small>
  </div>

  <div class="grid cols">
    <div class="card">
      <h2>3 · Live-Sniffer</h2>
      <div class="row" style="margin-bottom:8px">
        <span class="pill" id="pRx">RX: 0</span>
        <span class="pill" id="pTx">TX: 0</span>
        <span class="pill" id="pEp">—</span>
        <div class="spacer"></div>
        <button id="btnClear">Leeren</button>
      </div>
      <div id="sniff"></div>
    </div>
    <div class="card">
      <h2>4 · Rohdaten senden</h2>
      <div class="row">
        <input id="txIn" class="mono" style="flex:1 1 auto"
          placeholder="Hex, z.B.  AA 55 01 00  oder  AA550100" autocomplete="off">
        <button id="btnSend" class="primary">Senden</button>
      </div>
      <small class="muted">Schreibt rohe Bytes an den OUT-Endpoint. Zum Proben
        des ThinkDiag2-Protokolls.</small>
      <h2 style="margin-top:16px">Log</h2>
      <div id="log"></div>
    </div>
  </div>

  <div class="card">
    <h2>5 · Virtueller Dyno · Leistungsmessung</h2>
    <div class="row" style="margin-bottom:8px">
      <label class="muted">Masse kg</label><input id="dMass" class="small mono" value="1400">
      <label class="muted">Cd</label><input id="dCd" class="small mono" value="0.30">
      <label class="muted">Stirnfl. m2</label><input id="dArea" class="small mono" value="2.2">
      <label class="muted">Crr</label><input id="dCrr" class="small mono" value="0.012">
      <label class="muted">Wirkungsgr.</label><input id="dEff" class="small mono" value="0.85">
      <div class="spacer"></div>
      <button id="btnDyno" class="primary">Kurve berechnen</button>
    </div>
    <textarea id="dCsv" class="mono" style="width:100%;height:90px;background:var(--panel2);
      color:var(--txt);border:1px solid var(--line);border-radius:9px;padding:10px"
      placeholder="Log als CSV:  Zeit,Geschwindigkeit(km/h),Drehzahl&#10;0.0,45,2500&#10;0.1,46,2560&#10;..."></textarea>
    <div class="row" style="margin:10px 0">
      <span class="pill" id="dPeakP">Peak: —</span>
      <span class="pill" id="dPeakT">Drehmoment: —</span>
      <span class="pill" id="dSamples">—</span>
    </div>
    <canvas id="dChart" width="1100" height="300"
      style="width:100%;height:300px;background:#05080c;border:1px solid var(--line);border-radius:10px"></canvas>
    <small class="muted">Vollgas-Zug im hoechsten sinnvollen Gang loggen (Zeit, km/h, Drehzahl).
      Rechnung: F=m·a + Luft + Rollwiderstand, P=F·v, Motorleistung ueber Antriebs-Wirkungsgrad.</small>
  </div>

  <div class="card">
    <h2>6 · Tuning-Werkbank · Bin/Map-Editor</h2>
    <div class="row">
      <input id="bPath" class="mono" style="flex:1 1 auto"
        placeholder="/Users/rudolfsarkany/ecu_original.bin" autocomplete="off">
      <button id="bLoad" class="primary">Laden</button>
      <button id="bBackup">Backup</button>
      <span class="pill" id="bInfo">—</span>
    </div>
    <div class="row" style="margin-top:10px">
      <label class="muted">Hex @</label><input id="bHexOff" class="small mono" value="0x0">
      <label class="muted">Laenge</label><input id="bHexLen" class="small mono" value="256">
      <button id="bHex">Hex-Dump</button>
      <div class="spacer"></div>
      <label class="muted">Checksum</label>
      <select id="bAlgo"><option>sum16</option><option>sum32</option>
        <option>crc16</option><option>crc32</option><option>xor</option></select>
      <button id="bSum">Rechnen</button>
      <span class="pill" id="bSumV">—</span>
    </div>
    <pre class="sys" id="bHexBox" style="display:none;max-height:180px"></pre>

    <h2 style="margin-top:16px">Map lesen &amp; bearbeiten</h2>
    <div class="row">
      <label class="muted">Offset</label><input id="mOff" class="small mono" value="0x400">
      <label class="muted">Zeilen</label><input id="mRows" class="small mono" value="8">
      <label class="muted">Spalten</label><input id="mCols" class="small mono" value="8">
      <label class="muted">Typ</label>
      <select id="mType"><option>uint16</option><option>uint8</option>
        <option>int16</option><option>int8</option><option>uint32</option></select>
      <label class="muted">BE</label><input id="mBig" type="checkbox">
      <label class="muted">Faktor</label><input id="mFac" class="small mono" value="0.01">
      <label class="muted">+Offset</label><input id="mAdd" class="small mono" value="0">
      <button id="mRead" class="primary">Map lesen</button>
    </div>
    <div class="row" style="margin:8px 0">
      <span class="pill" id="mRange">—</span>
      <label class="muted">Alle Zellen ×</label><input id="mScale" class="small mono" value="1.10">
      <button id="mApply">Faktor anwenden</button>
      <div class="spacer"></div>
      <button id="mWrite" class="danger">In .bin schreiben (mit Backup)</button>
    </div>
    <div id="mapBox" style="overflow:auto"></div>
    <small class="muted">Arbeitet auf einer bereits ausgelesenen ECU-.bin.
      Schreiben legt automatisch ein Backup an. Checksummen ggf. ECU-spezifisch
      nachrechnen. Kein Abgas-Defeat.</small>
  </div>

  <div class="card">
    <h2>7 · CAN-Diagnose (UDS) · echter Bus via SLCAN-Adapter</h2>
    <div class="row" style="margin-bottom:10px">
      <label class="muted">Fahrzeug</label>
      <select id="cVeh" class="dev"><option value="generic">— Fahrzeug —</option></select>
      <select id="cModule"><option value="">— Modul —</option></select>
      <button id="cScanMod">Module scannen</button>
      <span class="pill" id="cVehInfo">—</span>
    </div>
    <div class="row" style="margin-bottom:10px">
      <label class="muted">VIN</label>
      <input id="cVin" class="mono" style="width:200px" placeholder="17-stellige VIN" autocomplete="off">
      <button id="cVinScan" class="primary">VIN vom Fahrzeug lesen</button>
      <button id="cVinBtn">Online decodieren</button>
      <span class="pill" id="cVinInfo">—</span>
    </div>
    <div class="row">
      <select id="cPort" class="dev"><option value="">— SLCAN-Port —</option></select>
      <button id="cPortRefresh">Ports</button>
      <select id="cBaud"><option>500k</option><option>250k</option>
        <option>125k</option><option>1M</option></select>
      <label class="muted">TX</label><input id="cTx" class="small mono" value="0x7E0">
      <label class="muted">RX</label><input id="cRx" class="small mono" value="0x7E8">
      <button id="cOpen" class="primary">Verbinden</button>
      <button id="cClose" class="danger">Trennen</button>
      <span class="pill" id="cStat">getrennt</span>
    </div>
    <div class="row" style="margin-top:10px">
      <button id="cDtc" class="primary">Fehlerspeicher lesen</button>
      <button id="cAllDtc" class="primary">Alle Module auslesen</button>
      <button id="cClear" class="danger">Loeschen</button>
      <button id="cReset">ECU-Reset</button>
      <label class="muted">DID</label><input id="cDid" class="small mono" value="F190">
      <button id="cDidBtn">DID lesen</button>
      <label class="muted">Raw UDS</label>
      <input id="cRaw" class="mono" style="flex:1 1 auto" placeholder="z.B. 22 F1 90 oder 19 02 FF">
      <button id="cRawBtn">Senden</button>
    </div>
    <div id="cOut" class="mono" style="margin-top:10px"></div>
    <small class="muted">Fuer echte Voll-Diagnose einen SLCAN-Adapter (CANable/USBtin,
      ~30 Euro) an den OBD-CAN-Bus. Aktiviert Mehrfach-ECU, Stellgliedtests,
      Service-Routinen - unabhaengig vom ThinkDiag2.</small>
  </div>

  <div class="card">
    <h2>9 · No-Start-Assistent · orgelt, startet nicht, kein Code</h2>
    <div id="nsBox"></div>
    <div class="row" style="margin-top:10px">
      <button id="nsRestart">Von vorn</button>
    </div>
    <small class="muted">Gefuehrte Diagnose fuer Chrysler/Dodge Crank-No-Start:
      TIPM-Kraftstoffpumpenrelais, Wegfahrsperre (WCM), ASD-Relais,
      fehlendes Kurbelwellensignal.</small>
  </div>

  <div class="card">
    <h2>12 · Komplett-Prüfliste · jede Kleinigkeit abhaken</h2>
    <div class="row" style="margin-bottom:8px">
      <span class="pill" id="clProg">—</span>
      <div class="spacer"></div>
      <button id="clSave" class="primary">Speichern</button>
      <button id="clReset">Zurücksetzen</button>
    </div>
    <div id="clBox"></div>
    <small class="muted">Ergebnisse werden lokal gespeichert (checklist_results.json).
      Prüfliste passt sich Benzin/Diesel an (Fahrzeug oben wählen). Grün = OK,
      Rot = Fehler gefunden.</small>
  </div>

  <div class="card">
    <h2>11 · Blink-Code &amp; Wegfahrsperre · Leuchte blinkt, Tools finden nichts</h2>
    <div id="fcBox"></div>
  </div>

  <div class="card">
    <h2>8 · Capture-Decoder · Reverse-Engineering</h2>
    <div class="row">
      <button id="decBtn" class="primary">Dekodieren</button>
      <span class="pill" id="decInfo">—</span>
    </div>
    <textarea id="decIn" class="mono" style="width:100%;height:110px;background:var(--panel2);
      color:var(--txt);border:1px solid var(--line);border-radius:9px;padding:10px;margin-top:8px"
      placeholder="Gesniffte CAN-Frames, je Zeile:  7E0#02 01 0C   oder   7E8 41 0C 1A F8"></textarea>
    <div id="decOut" style="margin-top:10px;overflow:auto"></div>
    <small class="muted">Setzt ISO-TP zusammen und uebersetzt in OBD-/UDS-Bedeutung
      inkl. DTC-Klartext. Frames aus dem Sniffer oder einem candump hier einfuegen.</small>
  </div>

  <div class="card">
    <h2>10 · Service &amp; Anpassungen (UDS) · Anlernen · Codieren</h2>
    <div class="row">
      <button id="svSession" class="primary">Extended Session (10 03)</button>
      <button id="svSeed">Security Seed (27 01)</button>
      <label class="muted">Key</label><input id="svKey" class="small mono" placeholder="hex">
      <button id="svKeyBtn">Key senden (27 02)</button>
    </div>
    <div class="row" style="margin-top:10px">
      <label class="muted">Routine 0x</label><input id="svRid" class="small mono" value="FF00">
      <select id="svRctl"><option value="1">Start</option><option value="2">Stop</option>
        <option value="3">Ergebnis</option></select>
      <input id="svRparam" class="mono" style="width:150px" placeholder="Param hex (optional)">
      <button id="svRoutine" class="primary">RoutineControl (31)</button>
    </div>
    <div class="row" style="margin-top:10px">
      <label class="muted">Stellglied DID 0x</label><input id="svIoDid" class="small mono" value="0000">
      <label class="muted">Ctrl</label><input id="svIoCtl" class="small mono" value="3">
      <input id="svIoP" class="mono" style="width:130px" placeholder="Param hex">
      <button id="svIo" class="primary">IO-Control (2F)</button>
    </div>
    <div class="row" style="margin-top:10px">
      <label class="muted">Schreiben DID 0x</label><input id="svWdid" class="small mono" value="0000">
      <input id="svWdata" class="mono" style="width:180px" placeholder="Daten hex">
      <button id="svWrite" class="danger">WriteDataByIdentifier (2E)</button>
    </div>
    <div class="row" style="margin-top:10px">
      <label class="muted">Speicher lesen @0x</label><input id="svMaddr" class="small mono" value="0">
      <label class="muted">Bytes</label><input id="svMsize" class="small mono" value="8">
      <button id="svReadMem">ReadMemory (23)</button>
    </div>
    <div id="svOut" class="mono" style="margin-top:10px"></div>
    <small class="muted">Kurbel/Nocken-Anlernen, Drosselklappe, Adaptionen laufen ueber
      RoutineControl/IO-Control. Viele Schreibzugriffe brauchen erst Security Access -
      der Key-Algorithmus ist herstellerspezifisch (ggf. per Sniffer ermitteln).
      Routine-/DID-Nummern aus Werksdoku oder Sniffer-Capture.</small>
  </div>

  <div class="card">
    <h2>system_profiler (roher Dump, keine libusb noetig)</h2>
    <div class="row"><button id="btnSys">SPUSBDataType laden</button></div>
    <pre class="sys" id="sysBox" style="display:none"></pre>
  </div>
</main>

<script>
const $=s=>document.querySelector(s);
async function api(p,b){const o=b?{method:"POST",headers:{"Content-Type":"application/json"},
  body:JSON.stringify(b)}:{};return (await fetch(p,o)).json();}
function esc(s){return (s??"").toString().replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));}

async function loadDevs(){
  const r=await api("/api/list");const sel=$("#devSel");const cur=sel.value;
  const eb=$("#errBanner");
  if(!r.ok){eb.textContent="\u26a0 "+r.error;eb.classList.add("show");
    sel.innerHTML='<option value="">— libusb fehlt —</option>';return;}
  eb.classList.remove("show");
  sel.innerHTML='<option value="">— Geraet waehlen —</option>';
  r.devices.forEach(d=>{
    const o=document.createElement("option");
    o.value=d.vid+":"+d.pid;
    const nm=[d.manufacturer,d.product].filter(Boolean).join(" ")||"(unbenannt)";
    o.textContent=`${d.vid}:${d.pid}  ${nm}`+(d.hint?"  \u2022 "+d.hint:"");
    o.dataset.hint=d.hint||"";
    sel.appendChild(o);
  });
  if(cur)sel.value=cur;
}
function selVidPid(){const v=$("#devSel").value;if(!v)return null;
  const[vid,pid]=v.split(":");return{vid,pid};}

async function showDesc(){
  const vp=selVidPid();if(!vp){alert("Bitte Geraet waehlen.");return;}
  const d=await api(`/api/descriptor?vid=${vp.vid}&pid=${vp.pid}`);
  const box=$("#descBox");$("#descCard").style.display="block";
  if(!d.ok){box.innerHTML=`<span class="hint bad">${esc(d.error)}</span>`;return;}
  let h=`<div class="row" style="margin-bottom:8px">
    <span class="pill">${esc(d.vid)}:${esc(d.pid)}</span>
    <span class="pill">${esc([d.manufacturer,d.product].filter(Boolean).join(" ")||"?")}</span>
    <span class="pill">devClass ${d.device_class}</span></div>`;
  d.configs.forEach(c=>{
    c.interfaces.forEach(i=>{
      h+=`<table><thead><tr><th>Interface ${i.number}</th>
        <th>class ${i.class}/${i.subclass}/${i.protocol}</th><th>Endpoints</th></tr></thead><tbody>`;
      if(!i.endpoints.length)h+=`<tr><td colspan=3 class=muted>keine Endpoints</td></tr>`;
      i.endpoints.forEach(e=>{
        h+=`<tr><td class="ep ${e.dir==='IN'?'tin':'tout'}">${esc(e.address)}</td>
          <td>${esc(e.dir)} · ${esc(e.type)}</td>
          <td>max ${e.max_packet} Byte</td></tr>`;
      });
      h+=`</tbody></table>`;
    });
  });
  box.innerHTML=h;
  // Auto-Vorschlag ins Feld
  const first=d.configs[0]&&d.configs[0].interfaces[0];
  if(first){$("#ifIn").value=first.number;
    const ins=first.endpoints.filter(e=>e.dir==="IN");
    const outs=first.endpoints.filter(e=>e.dir==="OUT");
    if(ins[0])$("#epIn").value=ins[0].address;
    if(outs[0])$("#epOut").value=outs[0].address;}
}

async function openDev(){
  const vp=selVidPid();if(!vp){alert("Bitte Geraet waehlen.");return;}
  const body={vid:vp.vid,pid:vp.pid};
  const iface=$("#ifIn").value.trim();const ei=$("#epIn").value.trim();const eo=$("#epOut").value.trim();
  if(iface!=="")body.interface=parseInt(iface,10);
  if(ei!=="")body.ep_in=ei;if(eo!=="")body.ep_out=eo;
  await api("/api/open",body);
}

let lastLog=0,lastBuf=0;
function renderSniff(buf){
  const el=$("#sniff");const near=el.scrollHeight-el.scrollTop-el.clientHeight<40;
  el.innerHTML=buf.map(p=>`<div class="pkt"><span class="tt">${p.t}</span>`+
    `<span class="d ${p.dir}">${p.dir}</span>`+
    `<span class="hx">${esc(p.hex)}   ${esc(p.ascii)}</span></div>`).join("");
  if(near)el.scrollTop=el.scrollHeight;
}
function renderLog(log){$("#log").innerHTML=log.map(l=>
  `<span class="t">${l.t}</span> <span class="${l.kind}">${esc(l.msg)}</span>`).join("\n");
  const el=$("#log");el.scrollTop=el.scrollHeight;}

async function tick(){
  let st;try{st=await api("/api/status");}catch(e){return;}
  $("#dot").classList.toggle("on",st.connected);
  $("#pStatus").textContent=st.connected?
    `verbunden ${st.vid}:${st.pid}`:"getrennt";
  $("#pRx").textContent="RX: "+st.rx_count;
  $("#pTx").textContent="TX: "+st.tx_count;
  $("#pEp").textContent=st.connected?
    `IF${st.interface} IN ${st.ep_in||'—'} (${st.read_type||'?'}) OUT ${st.ep_out||'—'}`:"—";
  if((st.buffer||[]).length!==lastBuf){renderSniff(st.buffer||[]);lastBuf=st.buffer.length;}
  if((st.log||[]).length!==lastLog){renderLog(st.log||[]);lastLog=st.log.length;}
  const eb=$("#errBanner");
  if(st.last_error){eb.textContent="\u26a0 "+st.last_error;eb.classList.add("show");}
  else if(st.pyusb!==false){/* nur Geraete-Fehler ausblenden, list() setzt eigene */}
}

$("#btnList").onclick=loadDevs;
$("#btnDesc").onclick=showDesc;
$("#btnOpen").onclick=openDev;
$("#btnClose").onclick=()=>api("/api/close",{});
$("#btnClear").onclick=()=>api("/api/clear",{});
$("#btnSend").onclick=()=>{const v=$("#txIn").value.trim();if(v)api("/api/write",{hex:v});};
$("#txIn").addEventListener("keydown",e=>{if(e.key==="Enter")$("#btnSend").click();});
$("#btnSys").onclick=async()=>{const d=await api("/api/sysusb");
  const b=$("#sysBox");b.style.display="block";
  b.textContent=d.raw||d.note||d.error||"(leer)";};

// ---- Fahrzeugprofile ----
let vehProfile=null;
async function loadVehicles(){const list=await api("/api/vehicles");const sel=$("#cVeh");
  sel.innerHTML="";list.forEach(v=>{const o=document.createElement("option");
    o.value=v.key;o.textContent=v.name;sel.appendChild(o);});
  applyVehicle();}
async function applyVehicle(){const key=$("#cVeh").value;
  const p=await api("/api/vehicle?key="+encodeURIComponent(key));vehProfile=p;
  $("#cVehInfo").textContent=`${p.engine} · ${p.bitrate} · ${p.network}`;
  // Bitrate setzen
  [...$("#cBaud").options].forEach(o=>{if(o.value===p.bitrate)$("#cBaud").value=p.bitrate;});
  // Module
  const m=$("#cModule");m.innerHTML='<option value="">— Modul —</option>';
  p.modules.forEach(mod=>{const o=document.createElement("option");
    o.value=`${mod.tx}|${mod.rx}`;o.dataset.tx=mod.tx;o.dataset.rx=mod.rx;
    o.textContent=`${mod.name}  (${typeof mod.tx==='number'?'0x'+mod.tx.toString(16).toUpperCase():mod.tx})`;
    m.appendChild(o);});
  // Notizen + typische DTCs in Ausgabe
  let h=`<div class="hint good"><b>${p.name}</b> — ${p.engine}</div>`;
  p.notes.forEach(n=>h+=`<div class="hint">• ${esc(n)}</div>`);
  if(p.common_dtcs.length)h+=`<div class="hint">Typische Codes: ${p.common_dtcs.join(", ")}</div>`;
  $("#cOut").innerHTML=h;
  nsLoad(p.fuel||"benzin");clLoad(p.fuel||"benzin");}
$("#cVeh").onchange=applyVehicle;
$("#cModule").onchange=()=>{const o=$("#cModule").selectedOptions[0];if(!o||!o.dataset.tx)return;
  const tx=+o.dataset.tx, rx=+o.dataset.rx;
  $("#cTx").value="0x"+tx.toString(16).toUpperCase();
  $("#cRx").value="0x"+rx.toString(16).toUpperCase();};
$("#cVinBtn").onclick=async()=>{const vin=$("#cVin").value.trim();if(!vin)return;
  $("#cVinInfo").textContent="decodiere …";
  const r=await api("/api/vin?vin="+encodeURIComponent(vin));
  if(r.ok){$("#cVinInfo").textContent=`${r.make} ${r.model} ${r.year} · ${r.displacement}L ${r.cylinders}Zyl`;
    if(r.profile){$("#cVeh").value=r.profile;applyVehicle();}}
  else $("#cVinInfo").textContent="⚠ "+(r.error||"Fehler");};
$("#cVinScan").onclick=async()=>{
  $("#cVinInfo").textContent="lese VIN vom Fahrzeug …";
  const r=await api("/api/can/vin",{});
  if(r.ok){$("#cVin").value=r.vin;
    $("#cVinInfo").textContent=`VIN gelesen (${r.via}) — decodiere …`;
    $("#cVinBtn").click();}
  else $("#cVinInfo").textContent="⚠ "+(r.error||"VIN nicht lesbar");};
async function netTick(){const s=await api("/api/online/status");
  const b=$("#netBadge");b.textContent=s.online?"online":"offline";
  b.style.color=s.online?"var(--ok)":"var(--dim)";
  b.style.borderColor=s.online?"var(--ok)":"var(--line)";}
$("#cScanMod").onclick=async()=>{
  $("#cOut").innerHTML='<div class="hint">Scanne Module 0x7E0–0x7E7 …</div>'+$("#cOut").innerHTML;
  const r=await api("/api/can/scanmodules",{tx_start:"0x7E0",tx_end:"0x7E7"});
  if(r.ok){let h=`<div class="hint good"><b>Gefundene Module (${r.found.length}):</b></div>`;
    r.found.forEach(f=>h+=`<div class="mono">${f.tx} → ${f.rx}  resp ${f.resp}</div>`);
    if(!r.found.length)h+='<div class="hint bad">Keine Antwort — Zündung an? Bus/Bitrate korrekt?</div>';
    $("#cOut").innerHTML=h+$("#cOut").innerHTML;}
  else cShow("Modul-Scan",r);};

// ---- CAN-Diagnose (UDS) ----
async function cPorts(){const r=await api("/api/list");const sel=$("#cPort");
  sel.innerHTML='<option value="">— SLCAN-Port —</option>';
  // serielle Ports kommen ueber /api/sysusb nicht; wir bieten manuelle Eingabe + bekannte cu.*
  ["/dev/tty.usbmodem","/dev/tty.usbserial","/dev/cu.usbmodem","/dev/cu.usbserial"].forEach(p=>{
    const o=document.createElement("option");o.value=p;o.textContent=p+" (anpassen)";sel.appendChild(o);});
  const man=document.createElement("option");man.value="__manual";man.textContent="… manuell eingeben";sel.appendChild(man);}
$("#cPortRefresh").onclick=cPorts;
function cPortVal(){let v=$("#cPort").value;
  if(v==="__manual"||!v){v=prompt("SLCAN-Port (z.B. /dev/cu.usbmodem1411):","/dev/cu.usbmodem");}
  return v;}
function cShow(label,res){
  const ok=res.ok!==false;
  const val=res.result!==undefined?(typeof res.result==="object"?JSON.stringify(res.result):res.result):(res.error||JSON.stringify(res));
  $("#cOut").innerHTML=`<div class="${ok?'':'hint bad'}"><b>${label}:</b> ${esc(val)}</div>`+$("#cOut").innerHTML;
}
$("#cOpen").onclick=async()=>{const port=cPortVal();if(!port)return;
  const r=await api("/api/can/open",{port,bitrate:$("#cBaud").value,tx_id:$("#cTx").value,rx_id:$("#cRx").value});
  cShow("Verbinden "+port, r);};
$("#cClose").onclick=async()=>cShow("Trennen",await api("/api/can/close",{}));
$("#cDtc").onclick=async()=>{const r=await api("/api/can/dtcs",{});
  if(r.ok){$("#cOut").innerHTML=`<b>Fehlerspeicher:</b> `+
    (r.result.length?r.result.map(d=>`${d.code} (${d.status})`).join(", "):"keine")+`</div>`+$("#cOut").innerHTML;}
  else cShow("Fehlerspeicher",r);};
$("#cClear").onclick=async()=>cShow("Loeschen",await api("/api/can/cleardtcs",{}));
$("#cReset").onclick=async()=>cShow("ECU-Reset",await api("/api/can/reset",{sub:1}));
$("#cDidBtn").onclick=async()=>cShow("DID "+$("#cDid").value,await api("/api/can/did",{did:$("#cDid").value}));
$("#cRawBtn").onclick=async()=>cShow("Raw "+$("#cRaw").value,await api("/api/can/raw",{hex:$("#cRaw").value}));
$("#cAllDtc").onclick=async()=>{
  const mods=(vehProfile&&vehProfile.modules)?vehProfile.modules:[{name:"PCM",tx:2016,rx:2024}];
  $("#cOut").innerHTML='<div class="hint">Lese Fehlerspeicher aller Module …</div>'+$("#cOut").innerHTML;
  const r=await api("/api/can/alldtcs",{modules:mods});
  if(r.ok){let h="<div class='hint good'><b>Fehlerspeicher pro Modul:</b></div>";
    r.modules.forEach(m=>{
      if(m.error){h+=`<div class="mono">${esc(m.name)} (${m.tx}): <span class="hint">${esc(m.error)}</span></div>`;}
      else if(m.dtcs.length){h+=`<div class="mono"><b>${esc(m.name)}</b> (${m.tx}): `+
        m.dtcs.map(d=>`${d.code} (${d.status})`).join(", ")+`</div>`;}
      else{h+=`<div class="mono">${esc(m.name)} (${m.tx}): keine</div>`;}});
    $("#cOut").innerHTML=h+$("#cOut").innerHTML;}
  else cShow("Alle Module",r);};
async function cTick(){const s=await api("/api/can/status");
  $("#cStat").textContent=s.connected?`verbunden ${s.port} ${s.bitrate}`:"getrennt";}

// ---- Capture-Decoder ----
$("#decBtn").onclick=async()=>{const r=await api("/api/decode",{text:$("#decIn").value});
  $("#decInfo").textContent=`${r.frames} Frames · ${r.messages.length} Nachrichten`;
  let h="<table style='font-size:12px'><thead><tr><th>ID</th><th></th><th>Bedeutung</th></tr></thead><tbody>";
  r.messages.forEach(m=>{
    h+=`<tr><td class="mono">${esc(m.id)}</td><td class="mono">${esc(m.kind)}</td><td>${esc(m.meaning)}`;
    (m.dtc_details||[]).forEach(d=>{h+=`<br><span class="hint">${esc(d.code)}: ${esc(d.text)}</span>`;});
    h+=`</td></tr>`;});
  h+="</tbody></table>";$("#decOut").innerHTML=h;};

// ---- No-Start-Assistent ----
let nsTree=null,nsNode=null;
async function nsLoad(fuel){nsTree=await api("/api/nostart?fuel="+(fuel||"benzin"));nsNode=nsTree.start;nsRender();}
function nsRender(){
  const n=nsTree.nodes[nsNode];const box=$("#nsBox");if(!n){box.innerHTML="";return;}
  if(n.type==="q"){
    let live=(n.live&&nsTree.live_hints[n.live])?`<div class="hint">${esc(nsTree.live_hints[n.live])}</div>`:"";
    box.innerHTML=`<div style="font-size:15px;margin-bottom:10px">${esc(n.text)}</div>${live}
      <div class="row"><button class="primary" onclick="nsGo('yes')">Ja</button>
      <button onclick="nsGo('no')">Nein</button></div>`;
  }else{
    box.innerHTML=`<div class="hint good" style="font-size:15px"><b>${esc(n.title)}</b></div>
      <div style="margin-top:8px;line-height:1.6">${esc(n.text)}</div>`;
  }
}
window.nsGo=(br)=>{const n=nsTree.nodes[nsNode];if(n&&n[br]){nsNode=n[br];nsRender();}};
$("#nsRestart").onclick=()=>{if(nsTree){nsNode=nsTree.start;nsRender();}};

// ---- Service & Anpassungen ----
function svShow(label,r){const ok=r.ok!==false;
  const v=r.result!==undefined?r.result:(r.error||JSON.stringify(r));
  $("#svOut").innerHTML=`<div class="${ok?'':'hint bad'}"><b>${esc(label)}:</b> ${esc(v)}</div>`+$("#svOut").innerHTML;}
$("#svSession").onclick=async()=>svShow("Session",await api("/api/can/session",{sub:3}));
$("#svSeed").onclick=async()=>svShow("Seed",await api("/api/can/secseed",{level:1}));
$("#svKeyBtn").onclick=async()=>svShow("Key",await api("/api/can/seckey",{level:1,key:$("#svKey").value}));
$("#svRoutine").onclick=async()=>svShow("Routine",await api("/api/can/routine",
  {control:$("#svRctl").value,rid:$("#svRid").value,params:$("#svRparam").value}));
$("#svIo").onclick=async()=>svShow("IO-Control",await api("/api/can/iocontrol",
  {did:$("#svIoDid").value,control:$("#svIoCtl").value,params:$("#svIoP").value}));
$("#svWrite").onclick=async()=>{if(!confirm("Wert ins Steuergeraet schreiben?"))return;
  svShow("Write",await api("/api/can/write",{did:$("#svWdid").value,data:$("#svWdata").value}));};
$("#svReadMem").onclick=async()=>svShow("ReadMemory",await api("/api/can/readmem",
  {addr:$("#svMaddr").value,size:$("#svMsize").value}));

cPorts();loadVehicles();nsLoad();netTick();setInterval(netTick,15000);

// ---- Komplett-Pruefliste ----
let clResults={};
async function clLoad(fuel){
  const [data,saved]=await Promise.all([
    api("/api/checklist?fuel="+(fuel||"benzin")),
    api("/api/checklist/load")]);
  clResults=(saved&&saved.results)||{};
  clRender(data);
}
function clRender(data){
  const box=$("#clBox");let h="";
  data.groups.forEach(gr=>{
    h+=`<div style="margin:12px 0 4px;font-weight:700;color:var(--accent)">${esc(gr.system)}</div>`;
    gr.items.forEach(it=>{
      const st=clResults[it.id]||"offen";
      const col=st==="ok"?"var(--ok)":(st==="fehler"?"var(--err)":"var(--dim)");
      h+=`<div style="border:1px solid var(--line);border-radius:9px;padding:8px 10px;margin:6px 0">
        <div style="display:flex;gap:8px;align-items:center">
          <b style="flex:1">${esc(it.check)}${it.tool?' <span class="pill">Tool</span>':''}</b>
          <button class="clBtn" data-id="${it.id}" data-v="ok"
            style="border-color:${st==='ok'?'var(--ok)':'var(--line)'};color:${st==='ok'?'var(--ok)':'var(--txt)'}">OK</button>
          <button class="clBtn" data-id="${it.id}" data-v="fehler"
            style="border-color:${st==='fehler'?'var(--err)':'var(--line)'};color:${st==='fehler'?'var(--err)':'var(--txt)'}">Fehler</button>
        </div>
        <div class="hint" style="color:var(--dim)">Messen: ${esc(it.how)}</div>
        <div class="hint" style="color:${col}">Soll: ${esc(it.good)}</div>
        <div class="hint">Bei Fehler: ${esc(it.bad)}</div>
      </div>`;
    });
  });
  box.innerHTML=h;
  box.querySelectorAll(".clBtn").forEach(btn=>btn.onclick=()=>{
    const id=btn.dataset.id,v=btn.dataset.v;
    clResults[id]=(clResults[id]===v)?"offen":v;
    clRender(data);
  });
  const done=Object.values(clResults).filter(v=>v&&v!=="offen").length;
  const bad=Object.values(clResults).filter(v=>v==="fehler").length;
  $("#clProg").textContent=`${done}/${data.count} geprüft · ${bad} Fehler`;
}
$("#clSave").onclick=async()=>{const r=await api("/api/checklist/save",{results:clResults});
  $("#clProg").textContent=r.ok?"gespeichert ✓":"Speichern fehlgeschlagen";};
$("#clReset").onclick=()=>{if(confirm("Alle Häkchen zurücksetzen?")){clResults={};
  clLoad((vehProfile&&vehProfile.fuel)||"benzin");}};
clLoad("benzin");

(async()=>{const g=await api("/api/flashcode");if(!g.ok)return;
  let h=`<div class="hint good" style="font-size:14px"><b>${esc(g.count_hint.title)}</b></div>
    <div style="margin:6px 0 12px;line-height:1.6">${esc(g.count_hint.text)}</div>
    <div class="hint good"><b>${esc(g.keydance.title)}</b></div><ol style="line-height:1.6;margin:6px 0">`;
  g.keydance.steps.forEach(s=>h+=`<li>${esc(s)}</li>`);
  h+=`</ol><div class="hint good" style="margin-top:8px"><b>${esc(g.immobilizer.title)}</b></div>
    <div class="hint">${esc(g.immobilizer.why)}</div><ul style="line-height:1.6;margin:6px 0">`;
  g.immobilizer.checks.forEach(c=>h+=`<li>${esc(c)}</li>`);
  h+=`</ul><div style="margin-top:8px;padding:10px;background:var(--panel2);border-radius:9px">
    <b>Nächster Schritt:</b> ${esc(g.next)}</div>`;
  $("#fcBox").innerHTML=h;})();

function drawDyno(res){
  const cv=$("#dChart"),x=cv.getContext("2d");
  x.clearRect(0,0,cv.width,cv.height);
  if(!res.ok||!res.curve.length){$("#dPeakP").textContent="Peak: "+(res.error||"—");return;}
  const c=res.curve,W=cv.width,H=cv.height,pad=44;
  const rpms=c.map(p=>p.rpm),ps=c.map(p=>p.power_ps),tq=c.map(p=>p.torque_nm);
  const rMin=Math.min(...rpms),rMax=Math.max(...rpms);
  const pMax=Math.max(...ps)*1.1,tMax=Math.max(...tq)*1.1;
  const X=r=>pad+(r-rMin)/(rMax-rMin||1)*(W-2*pad);
  const YP=v=>H-pad-v/pMax*(H-2*pad);
  const YT=v=>H-pad-v/tMax*(H-2*pad);
  // Gitter
  x.strokeStyle="#16202b";x.lineWidth=1;x.fillStyle="#8b98a5";x.font="11px monospace";
  for(let i=0;i<=5;i++){const gx=pad+i/5*(W-2*pad);
    x.beginPath();x.moveTo(gx,pad);x.lineTo(gx,H-pad);x.stroke();
    x.fillText(Math.round(rMin+i/5*(rMax-rMin)),gx-14,H-pad+16);}
  // Drehmoment (orange)
  x.strokeStyle="#ff8c1a";x.lineWidth=2;x.beginPath();
  c.forEach((p,i)=>{const px=X(p.rpm),py=YT(p.torque_nm);i?x.lineTo(px,py):x.moveTo(px,py);});x.stroke();
  // Leistung (cyan)
  x.strokeStyle="#22d3ee";x.lineWidth=2.5;x.beginPath();
  c.forEach((p,i)=>{const px=X(p.rpm),py=YP(p.power_ps);i?x.lineTo(px,py):x.moveTo(px,py);});x.stroke();
  // Legende
  x.fillStyle="#22d3ee";x.fillText("Leistung (PS)",pad,20);
  x.fillStyle="#ff8c1a";x.fillText("Drehmoment (Nm)",pad+120,20);
}
$("#btnDyno").onclick=async()=>{
  const params={mass_kg:$("#dMass").value,cd:$("#dCd").value,area_m2:$("#dArea").value,
    crr:$("#dCrr").value,drivetrain_eff:$("#dEff").value};
  const res=await api("/api/dyno",{csv:$("#dCsv").value,params});
  if(res.ok){
    $("#dPeakP").textContent=`Peak: ${res.peak_power.ps} PS (${res.peak_power.kw} kW) @ ${res.peak_power.rpm}`;
    $("#dPeakT").textContent=`Drehmoment: ${res.peak_torque.nm} Nm @ ${res.peak_torque.rpm}`;
    $("#dSamples").textContent=res.samples_used+" Punkte";
  }else{$("#dPeakT").textContent="";$("#dSamples").textContent="";}
  drawDyno(res);
};

// ---- Tuning-Werkbank ----
let curMap=null;
function bPath(){return $("#bPath").value.trim();}
$("#bLoad").onclick=async()=>{const r=await api("/api/bin/load",{path:bPath()});
  $("#bInfo").textContent=r.ok?`${r.size} Byte · md5 ${r.md5.slice(0,10)}`:("\u26a0 "+r.error);};
$("#bBackup").onclick=async()=>{const r=await api("/api/bin/backup",{path:bPath()});
  $("#bInfo").textContent=r.ok?("Backup: "+r.backup.split("/").pop()):("\u26a0 "+r.error);};
$("#bHex").onclick=async()=>{const r=await api("/api/bin/hexdump",
  {path:bPath(),offset:parseInt($("#bHexOff").value,16)||0,length:parseInt($("#bHexLen").value,10)||256});
  const box=$("#bHexBox");box.style.display="block";
  box.textContent=r.ok?r.rows.map(x=>`${x.addr}  ${x.hex.padEnd(48)}  ${x.ascii}`).join("\n"):("\u26a0 "+r.error);};
$("#bSum").onclick=async()=>{const r=await api("/api/bin/checksum",{path:bPath(),algo:$("#bAlgo").value});
  $("#bSumV").textContent=r.ok?`${r.algo}=${r.hex}`:("\u26a0 "+r.error);};

function mapParams(){return{path:bPath(),offset:parseInt($("#mOff").value,16)||0,
  rows:parseInt($("#mRows").value,10),cols:parseInt($("#mCols").value,10),
  dtype:$("#mType").value,big:$("#mBig").checked,
  factor:parseFloat($("#mFac").value),add:parseFloat($("#mAdd").value)};}
function renderMap(table){
  let h="<table style='font-size:12px'>";
  table.forEach((row,r)=>{h+="<tr>";row.forEach((v,c)=>{
    h+=`<td style="padding:2px"><input data-r="${r}" data-c="${c}" value="${v}"
      class="mono" style="width:64px;padding:4px;text-align:right"></td>`;});h+="</tr>";});
  h+="</table>";$("#mapBox").innerHTML=h;}
function readTable(){const inp=$("#mapBox").querySelectorAll("input");
  const t=curMap.table.map(r=>r.slice());
  inp.forEach(i=>{t[+i.dataset.r][+i.dataset.c]=parseFloat(i.value)||0;});return t;}
$("#mRead").onclick=async()=>{const p=mapParams();const r=await api("/api/bin/readmap",p);
  if(!r.ok){$("#mRange").textContent="\u26a0 "+r.error;return;}
  curMap=Object.assign({},p,{table:r.table});
  $("#mRange").textContent=`min ${r.min} · max ${r.max}`;renderMap(r.table);};
$("#mApply").onclick=()=>{if(!curMap)return;const f=parseFloat($("#mScale").value)||1;
  const t=readTable().map(row=>row.map(v=>Math.round(v*f*1000)/1000));
  curMap.table=t;renderMap(t);
  const flat=t.flat();$("#mRange").textContent=`min ${Math.min(...flat)} · max ${Math.max(...flat)} (×${f})`;};
$("#mWrite").onclick=async()=>{if(!curMap){alert("Erst Map lesen.");return;}
  if(!confirm("In die .bin schreiben? (Backup wird angelegt)"))return;
  const t=readTable();
  const r=await api("/api/bin/writemap",Object.assign({},curMap,{values:t}));
  $("#mRange").textContent=r.ok?`geschrieben: ${r.changed_cells} Zellen · md5 ${r.md5.slice(0,10)}`:("\u26a0 "+r.error);};

loadDevs();tick();setInterval(tick,500);setInterval(cTick,1000);
</script>
</body>
</html>"""
