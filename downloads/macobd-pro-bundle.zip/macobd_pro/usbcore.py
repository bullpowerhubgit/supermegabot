#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Roher USB-Kern (libusb / pyusb)
============================================
KEIN Serial, KEIN ELM327. Dieser Kern spricht das USB-Geraet direkt an:
Enumeration, vollstaendiger Deskriptor-Dump (Interfaces + Endpoints mit
Transfer-Typ und Richtung), Interface claimen, IN-Endpoint live mitsniffen,
rohe Bytes an den OUT-Endpoint senden.

Gedacht fuer Geraete wie den ThinkDiag2, die sich NICHT als CDC-Serial
melden, sondern ein herstellereigenes USB-Interface mit eigenen Endpoints
exponieren (oder als DFU/Bootloader). Damit laesst sich das Protokoll
mitschneiden und reverse-engineeren.

Ein Hintergrund-Thread besitzt das Geraet exklusiv; der Webserver redet
nur ueber Command-Queue + Shared-State (thread-safe).
"""

import time
import json
import queue
import platform
import threading
import subprocess

try:
    import usb.core
    import usb.util
    PYUSB_OK = True
    PYUSB_ERR = None
except Exception as e:  # pragma: no cover
    PYUSB_OK = False
    PYUSB_ERR = str(e)


TRANSFER = {0: "control", 1: "iso", 2: "bulk", 3: "interrupt"}


def _backend_check():
    """Prueft, ob libusb als Backend erreichbar ist."""
    if not PYUSB_OK:
        return False, f"pyusb fehlt: {PYUSB_ERR}"
    try:
        list(usb.core.find(find_all=True))
        return True, None
    except Exception as e:
        # Typisch: NoBackendError -> libusb nicht installiert
        return False, (f"libusb-Backend fehlt ({e}). "
                       f"Auf dem Mac:  brew install libusb")


def _safe_str(dev, index):
    if not index:
        return ""
    try:
        return usb.util.get_string(dev, index) or ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Enumeration + Deskriptoren
# ---------------------------------------------------------------------------
def list_usb() -> dict:
    ok, err = _backend_check()
    if not ok:
        return {"ok": False, "error": err, "devices": []}
    out = []
    for d in usb.core.find(find_all=True):
        try:
            item = {
                "vid": f"{d.idVendor:04X}",
                "pid": f"{d.idProduct:04X}",
                "bus": getattr(d, "bus", None),
                "address": getattr(d, "address", None),
                "manufacturer": _safe_str(d, d.iManufacturer),
                "product": _safe_str(d, d.iProduct),
                "serial": _safe_str(d, d.iSerialNumber),
                "class": d.bDeviceClass,
                "hint": _hint(d),
            }
            out.append(item)
        except Exception as e:
            out.append({"vid": "?", "pid": "?", "error": str(e)})
    return {"ok": True, "devices": out}


def _hint(d) -> str:
    vid = d.idVendor
    prod = (_safe_str(d, d.iProduct) or "").lower()
    man = (_safe_str(d, d.iManufacturer) or "").lower()
    s = f"{man} {prod}"
    if vid == 0x0483:  # STMicroelectronics
        if "dfu" in s or "bootloader" in s:
            return "STM32 DFU/Bootloader-Modus"
        return "STMicroelectronics (STM32) - vermutlich der Adapter-Chip"
    if any(k in s for k in ("thinkdiag", "launch", "thinkcar")):
        return "ThinkDiag / Launch erkannt"
    if d.bDeviceClass == 2 or d.bDeviceClass == 0:
        return ""  # CDC oder per-Interface-Class
    return ""


def descriptor(vid: int, pid: int) -> dict:
    """Vollstaendiger Deskriptor-Baum eines Geraets."""
    ok, err = _backend_check()
    if not ok:
        return {"ok": False, "error": err}
    dev = usb.core.find(idVendor=vid, idProduct=pid)
    if dev is None:
        return {"ok": False, "error": "Geraet nicht gefunden (aus-/eingesteckt?)"}
    tree = {
        "ok": True,
        "vid": f"{vid:04X}", "pid": f"{pid:04X}",
        "manufacturer": _safe_str(dev, dev.iManufacturer),
        "product": _safe_str(dev, dev.iProduct),
        "serial": _safe_str(dev, dev.iSerialNumber),
        "device_class": dev.bDeviceClass,
        "configs": [],
    }
    try:
        for cfg in dev:
            c = {"value": cfg.bConfigurationValue, "interfaces": []}
            for intf in cfg:
                i = {
                    "number": intf.bInterfaceNumber,
                    "alt": intf.bAlternateSetting,
                    "class": intf.bInterfaceClass,
                    "subclass": intf.bInterfaceSubClass,
                    "protocol": intf.bInterfaceProtocol,
                    "endpoints": [],
                }
                for ep in intf:
                    addr = ep.bEndpointAddress
                    i["endpoints"].append({
                        "address": f"0x{addr:02X}",
                        "dir": "IN" if addr & 0x80 else "OUT",
                        "type": TRANSFER.get(ep.bmAttributes & 0x03, "?"),
                        "max_packet": ep.wMaxPacketSize,
                    })
                c["interfaces"].append(i)
            tree["configs"].append(c)
    except Exception as e:
        tree["walk_error"] = str(e)
    return tree


# ---------------------------------------------------------------------------
# system_profiler / ioreg - Deskriptor-Dump OHNE Abhaengigkeiten (nur macOS)
# ---------------------------------------------------------------------------
def sys_usb() -> dict:
    if platform.system() != "Darwin":
        return {"platform": platform.system(),
                "note": "system_profiler nur unter macOS.", "raw": ""}
    try:
        raw = subprocess.check_output(
            ["system_profiler", "SPUSBDataType"],
            text=True, timeout=15, stderr=subprocess.DEVNULL)
        return {"platform": "Darwin", "raw": raw}
    except Exception as e:
        return {"platform": "Darwin", "error": str(e), "raw": ""}


# ---------------------------------------------------------------------------
# Roh-Verbindung: Interface claimen, IN sniffen, OUT schreiben
# ---------------------------------------------------------------------------
class RawUSB:
    def __init__(self):
        self._q = queue.Queue()
        self._lock = threading.Lock()
        self._dev = None
        self._ep_in = None
        self._ep_out = None
        self._intf = None
        self._read_size = 64
        self._state = {
            "connected": False,
            "vid": None, "pid": None, "product": None,
            "interface": None, "ep_in": None, "ep_out": None,
            "read_type": None,
            "rx_count": 0, "tx_count": 0,
            "last_error": None,
        }
        self._buf = []   # {t, dir, hex, ascii}
        self._log = []
        self._running = True
        self._sniffing = True
        self._t = threading.Thread(target=self._loop, daemon=True)
        self._t.start()

    # ---- API (nur enqueue / read) ----
    def open(self, vid, pid, interface=None, ep_in=None, ep_out=None):
        self._q.put(("open", {"vid": vid, "pid": pid, "interface": interface,
                              "ep_in": ep_in, "ep_out": ep_out}))

    def close(self):
        self._q.put(("close", {}))

    def write(self, hexstr):
        self._q.put(("write", {"hex": hexstr}))

    def clear_buffer(self):
        with self._lock:
            self._buf.clear()

    def snapshot(self):
        with self._lock:
            st = json.loads(json.dumps(self._state))
            st["buffer"] = list(self._buf[-400:])
            st["log"] = list(self._log[-120:])
            st["pyusb"] = PYUSB_OK
            return st

    # ---- intern ----
    def _logline(self, msg, kind="info"):
        with self._lock:
            self._log.append({"t": time.strftime("%H:%M:%S"),
                              "kind": kind, "msg": msg})
            self._log[:] = self._log[-300:]

    def _set(self, **kw):
        with self._lock:
            self._state.update(kw)

    def _record(self, direction, data):
        h = " ".join(f"{b:02X}" for b in data)
        a = "".join(chr(b) if 32 <= b < 127 else "." for b in data)
        with self._lock:
            self._buf.append({"t": time.strftime("%H:%M:%S.")
                              + f"{int(time.time()*1000)%1000:03d}",
                              "dir": direction, "hex": h, "ascii": a})
            self._buf[:] = self._buf[-1000:]
            if direction == "IN":
                self._state["rx_count"] += 1
            else:
                self._state["tx_count"] += 1

    def _loop(self):
        while self._running:
            try:
                cmd, arg = self._q.get(timeout=0.02)
                self._handle(cmd, arg)
            except queue.Empty:
                pass
            if self._state.get("connected") and self._ep_in is not None:
                self._read_once()

    def _handle(self, cmd, arg):
        try:
            if cmd == "open":
                self._do_open(**arg)
            elif cmd == "close":
                self._do_close()
            elif cmd == "write":
                self._do_write(arg["hex"])
        except Exception as e:
            self._set(last_error=str(e))
            self._logline(f"Fehler bei '{cmd}': {e}", "err")

    def _do_open(self, vid, pid, interface, ep_in, ep_out):
        ok, err = _backend_check()
        if not ok:
            self._set(last_error=err)
            self._logline(err, "err")
            return
        self._do_close()
        vid = int(vid); pid = int(pid)
        self._logline(f"Oeffne USB {vid:04X}:{pid:04X} ...")
        dev = usb.core.find(idVendor=vid, idProduct=pid)
        if dev is None:
            self._set(last_error="Geraet nicht gefunden.")
            self._logline("Geraet nicht gefunden.", "err")
            return

        # macOS/Linux: evtl. aktiven Kernel-Treiber loesen (best effort)
        try:
            cfg = dev.get_active_configuration()
        except Exception:
            try:
                dev.set_configuration()
                cfg = dev.get_active_configuration()
            except Exception as e:
                self._set(last_error=f"set_configuration fehlgeschlagen: {e}")
                self._logline(f"set_configuration: {e}", "err")
                return

        # Interface waehlen (angegeben oder erstes)
        intf = None
        for i in cfg:
            if interface is None or i.bInterfaceNumber == int(interface):
                intf = i
                break
        if intf is None:
            self._set(last_error="Interface nicht gefunden.")
            return

        try:
            if dev.is_kernel_driver_active(intf.bInterfaceNumber):
                dev.detach_kernel_driver(intf.bInterfaceNumber)
                self._logline(f"Kernel-Treiber von Interface "
                              f"{intf.bInterfaceNumber} geloest.")
        except (NotImplementedError, Exception):
            pass  # macOS-Backend unterstuetzt das oft nicht - ok

        try:
            usb.util.claim_interface(dev, intf.bInterfaceNumber)
        except Exception as e:
            self._set(last_error=f"claim_interface fehlgeschlagen: {e} "
                                 f"(Geraet evtl. von macOS/App belegt)")
            self._logline(f"claim_interface: {e}", "err")
            return

        # Endpoints bestimmen
        ep_in_obj = ep_out_obj = None
        for ep in intf:
            addr = ep.bEndpointAddress
            is_in = bool(addr & 0x80)
            if ep_in is not None and is_in and addr == int(str(ep_in), 0):
                ep_in_obj = ep
            if ep_out is not None and not is_in and addr == int(str(ep_out), 0):
                ep_out_obj = ep
            if ep_in is None and is_in and ep_in_obj is None:
                ep_in_obj = ep
            if ep_out is None and not is_in and ep_out_obj is None:
                ep_out_obj = ep

        self._dev = dev
        self._intf = intf
        self._ep_in = ep_in_obj
        self._ep_out = ep_out_obj
        if ep_in_obj is not None:
            self._read_size = ep_in_obj.wMaxPacketSize or 64
        rtype = (TRANSFER.get(ep_in_obj.bmAttributes & 0x03)
                 if ep_in_obj is not None else None)
        self._set(connected=True, vid=f"{vid:04X}", pid=f"{pid:04X}",
                  product=_safe_str(dev, dev.iProduct),
                  interface=intf.bInterfaceNumber,
                  ep_in=(f"0x{ep_in_obj.bEndpointAddress:02X}"
                         if ep_in_obj is not None else None),
                  ep_out=(f"0x{ep_out_obj.bEndpointAddress:02X}"
                          if ep_out_obj is not None else None),
                  read_type=rtype, last_error=None)
        self._logline(f"Verbunden. Interface {intf.bInterfaceNumber}, "
                      f"IN {self._state['ep_in']} ({rtype}), "
                      f"OUT {self._state['ep_out']}. Sniffer laeuft.", "ok")
        if ep_in_obj is None:
            self._logline("Kein IN-Endpoint - nur Senden moeglich.", "warn")

    def _read_once(self):
        if self._ep_in is None:
            return
        try:
            data = self._dev.read(self._ep_in.bEndpointAddress,
                                  self._read_size, timeout=60)
            if data:
                self._record("IN", bytes(data))
        except usb.core.USBError as e:
            # Timeout (errno 110/60) ist normal beim Sniffen -> ignorieren
            if e.errno not in (110, 60, None):
                self._set(last_error=f"read: {e}")
        except Exception:
            pass

    def _do_write(self, hexstr):
        if not self._state.get("connected"):
            self._logline("Nicht verbunden.", "warn")
            return
        if self._ep_out is None:
            self._logline("Kein OUT-Endpoint vorhanden.", "err")
            return
        data = _parse_hex(hexstr)
        if data is None:
            self._logline(f"Ungueltige Hex-Eingabe: {hexstr}", "err")
            return
        try:
            self._dev.write(self._ep_out.bEndpointAddress, data, timeout=1000)
            self._record("OUT", data)
            self._logline(f"Gesendet: {len(data)} Byte", "raw")
        except Exception as e:
            self._set(last_error=f"write: {e}")
            self._logline(f"write: {e}", "err")

    def _do_close(self):
        if self._dev is not None:
            try:
                if self._intf is not None:
                    usb.util.release_interface(self._dev,
                                               self._intf.bInterfaceNumber)
            except Exception:
                pass
            try:
                usb.util.dispose_resources(self._dev)
            except Exception:
                pass
        self._dev = self._ep_in = self._ep_out = self._intf = None
        self._set(connected=False, ep_in=None, ep_out=None, read_type=None,
                  interface=None)
        self._logline("Getrennt.")


def _parse_hex(s):
    """'AA 55 01' oder 'AA5501' oder '0xAA,0x55' -> bytes."""
    s = s.replace("0x", "").replace(",", " ").strip()
    try:
        if " " in s:
            return bytes(int(x, 16) for x in s.split())
        if len(s) % 2 != 0:
            return None
        return bytes(int(s[i:i + 2], 16) for i in range(0, len(s), 2))
    except ValueError:
        return None


# Singleton
usbdev = RawUSB()
