#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - No-Start-Assistent (Crank-No-Start Entscheidungsbaum)
==================================================================
Gefuehrte Diagnose fuer "Motor orgelt, springt nicht an, KEIN Fehlercode" -
zugeschnitten auf Chrysler/Dodge (Challenger, Ram, Nitro). Genau die Faelle,
die generische OBD-Tools nicht finden: TIPM-Kraftstoffpumpenrelais,
Wegfahrsperre (WCM/SKREEM), ASD-Relais, fehlendes Kurbelwellensignal.

Der Baum wird als JSON an die Oberflaeche gegeben; die UI navigiert per
Ja/Nein. 'live' nennt eine Messung, die das Tool selbst uebernehmen kann.
"""

TREE = {
    "start": "q_crank",
    "nodes": {
        "q_crank": {
            "type": "q",
            "text": "Dreht der Anlasser den Motor durch (orgelt), aber er startet nicht?",
            "yes": "q_prime", "no": "r_starter",
        },
        "r_starter": {
            "type": "r",
            "title": "Kein Orgeln = anderes Problem",
            "text": "Wenn der Anlasser nicht sauber dreht: Batterie (unter Last!), "
                    "Masseband Motor/Karosserie, Anlasser/Magnetschalter, "
                    "Zuendschloss. Das ist kein Kraftstoff-/Zuendthema.",
        },
        "q_prime": {
            "type": "q",
            "text": "Zuendung EIN (ohne zu starten): hoerst du die Kraftstoffpumpe "
                    "ca. 2 Sekunden summen (am Tank)?",
            "live": "fuel_pressure",
            "yes": "q_rpm", "no": "r_tipm",
        },
        "r_tipm": {
            "type": "r",
            "title": "Kraftstoffpumpe primt nicht -> TIPM-Relais (Chrysler-Klassiker!)",
            "text": "Kein Vorfoerdern = kein Druck = kein Start, OFT OHNE CODE. "
                    "Haeufigste versteckte Ursache bei Dodge: das "
                    "Kraftstoffpumpen-Relais IM TIPM (Totally Integrated Power "
                    "Module) haengt/verschmort. Test: Spannung am Pumpenstecker "
                    "beim Einschalten (12V ~2s?). Alternativ TIPM-Relais bruecken/"
                    "ersetzen (bekannte Schwachstelle). Auch Pumpe, Sicherung, "
                    "Traegheitsschalter pruefen.",
        },
        "q_rpm": {
            "type": "q",
            "text": "Beim Orgeln: zeigt das Tool eine Drehzahl (RPM) groesser 0?",
            "live": "rpm_crank",
            "yes": "q_immo", "no": "r_ckp",
        },
        "r_ckp": {
            "type": "r",
            "title": "RPM bleibt 0 -> PCM bekommt KEIN Kurbelwellensignal",
            "text": "Das ist die klassische 'kein Code, kein Start'-Falle. Auch "
                    "wenn der Kurbelwellensensor (CKP) neu ist: Stecker/Kabel und "
                    "Schirmung pruefen, Geberrad/Reluctor am Schwungrad, und den "
                    "Nockenwellensensor (CMP). Ohne Kurbelsignal schaltet das "
                    "ASD-Relais nicht -> keine Zuendung UND keine Einspritzung. "
                    "Signal am CKP beim Orgeln mit Oszi/Multimeter (AC) pruefen.",
        },
        "q_immo": {
            "type": "q",
            "text": "Blinkt eine Security-/Wegfahrsperren-Leuchte, ODER antwortet "
                    "das WCM/SKREEM beim Modul-Scan nicht?",
            "live": "scan_wcm",
            "yes": "r_immo", "no": "q_spark",
        },
        "r_immo": {
            "type": "r",
            "title": "Wegfahrsperre autorisiert nicht (WCM/SKREEM)",
            "text": "Motor orgelt, aber Einspritzung/Zuendung bleiben gesperrt. "
                    "Ursache: Schluessel-Transponder defekt/nicht angelernt, WCM "
                    "(Wireless Control Module/SKREEM) defekt, oder PCM<->WCM-"
                    "Kommunikation gestoert. Mit dem Modul-Scan pruefen, ob das "
                    "WCM antwortet; Fehlerspeicher des WCM auslesen (nur UDS, "
                    "nicht generisch). Ersatzschluessel testen.",
        },
        "q_spark": {
            "type": "q",
            "text": "Hast du beim Orgeln Zuendfunken an einer Kerze?",
            "yes": "q_fuelp", "no": "q_inj",
        },
        "q_inj": {
            "type": "q",
            "text": "Und die Einspritzventile: pulsen/klicken sie beim Orgeln "
                    "(Noid-Light-Test)?",
            "yes": "r_ign", "no": "r_asd",
        },
        "r_asd": {
            "type": "r",
            "title": "Weder Funke noch Einspritzimpuls -> ASD-Relais schaltet nicht",
            "text": "Das ASD-Relais (Auto Shut Down) versorgt Zuendspulen, "
                    "Injektoren, Pumpe, Lambda-Heizung. Schaltet es nach dem "
                    "kurzen Prime nicht dauerhaft, fehlt meist das Kurbelsignal "
                    "am PCM (siehe RPM-Test) oder das PCM ist defekt. ASD-"
                    "Ansteuerung und Versorgung pruefen.",
        },
        "r_ign": {
            "type": "r",
            "title": "Kein Funke, aber Einspritzung vorhanden -> Zuendseite",
            "text": "Zuendspulen/Zuendmodul, Kurbel-Referenzsignal fuer die "
                    "Zuendung, oder Verkabelung der Spulen. Spulen einzeln und "
                    "deren Ansteuerung pruefen.",
        },
        "q_fuelp": {
            "type": "q",
            "text": "Kraftstoffdruck an der Rail beim Orgeln im Sollbereich?",
            "live": "fuel_pressure",
            "yes": "q_mech", "no": "r_fuel",
        },
        "r_fuel": {
            "type": "r",
            "title": "Funke ja, aber Druck fehlt -> Kraftstoffversorgung",
            "text": "Pumpe schwach, Kraftstofffilter zu, Druckregler, oder wieder "
                    "das TIPM-Relais. Bei spaeteren 3.6L mit Direkteinspritzung: "
                    "Hochdruckpumpe/Niederdruckseite. Solldruck mit Manometer an "
                    "der Rail messen.",
        },
        "q_mech": {
            "type": "q",
            "text": "Funke UND Druck sind da, er springt trotzdem nicht an?",
            "yes": "r_mech", "no": "r_recheck",
        },
        "r_mech": {
            "type": "r",
            "title": "Mechanik / Steuerzeiten",
            "text": "Uebersprungene Steuerkette (Nocken/Kurbel-Korrelation, oft "
                    "P0016/P0017), verstopfte/undichte Injektoren, oder Motor "
                    "abgesoffen. Kompression pruefen, Steuerzeiten (Nocken/Kurbel) "
                    "kontrollieren, Injektoren auf Dichtheit.",
        },
        "r_recheck": {
            "type": "r",
            "title": "Nochmal strukturiert messen",
            "text": "Wenn es sporadisch ist: beim Orgeln gleichzeitig RPM-Anzeige, "
                    "Kraftstoffdruck und Funke beobachten. Der Ausfall zeigt sich "
                    "am fehlenden von diesen dreien.",
        },
    },
    # Zusatz: was das Tool selbst messen/pruefen kann
    "live_hints": {
        "fuel_pressure": "Tool: Kraftstoffdruck-PID lesen (falls unterstuetzt) "
                         "oder Rail-Manometer.",
        "rpm_crank": "Tool: im Live-Sniffer/OBD RPM (PID 010C) beim Orgeln "
                     "beobachten - bleibt sie 0, fehlt das Kurbelsignal.",
        "scan_wcm": "Tool: 'Module scannen' im CAN-Panel - antwortet das WCM? "
                    "Danach dessen Fehlerspeicher per UDS lesen.",
    },
}


def tree(fuel="benzin"):
    return {"ok": True, **(TREE_DIESEL if str(fuel).lower() == "diesel" else TREE)}


TREE_DIESEL = {
    "start": "q_crank",
    "nodes": {
        "q_crank": {
            "type": "q",
            "text": "Dreht der Anlasser den Diesel durch (orgelt), startet aber nicht?",
            "yes": "q_rpm", "no": "r_starter",
        },
        "r_starter": {
            "type": "r",
            "title": "Kein sauberes Orgeln = anderes Problem",
            "text": "Batterie unter Last, Masseband, Anlasser/Magnetschalter, "
                    "Zuendschloss pruefen. Diesel braucht kraeftiges Durchdrehen.",
        },
        "q_rpm": {
            "type": "q",
            "text": "Zeigt das Tool beim Orgeln eine Drehzahl (RPM) groesser 0?",
            "live": "rpm_crank", "yes": "q_rail", "no": "r_ckp",
        },
        "r_ckp": {
            "type": "r",
            "title": "RPM bleibt 0 -> kein Kurbelwellensignal",
            "text": "Auch bei neuem Sensor: CKP-Stecker/Kabel und Geberrad "
                    "pruefen, dazu Nockenwellensensor. Ohne Kurbelsignal keine "
                    "Einspritzung -> orgelt, startet nie, oft ohne Code.",
        },
        "q_rail": {
            "type": "q",
            "text": "Beim Orgeln: Raildruck im Sollbereich? (Live-PID Rail-Druck "
                    "oder Manometer - ein Diesel braucht grob 250+ bar zum Zuenden)",
            "live": "rail_pressure", "yes": "q_immo", "no": "r_rail",
        },
        "r_rail": {
            "type": "r",
            "title": "Kein/zu wenig Raildruck -> haeufigste Diesel-No-Start-Ursache",
            "text": "Pruefen in dieser Reihenfolge: (1) Vorfoerderung/Foerderpumpe "
                    "und Kraftstofffilter (Luft im System? entlueften!), "
                    "(2) Druckregelventil (MPROP/DRV) am Rail/Pumpe, "
                    "(3) Hochdruckpumpe, (4) Injektor-Ruecklaufmengen (leak-off): "
                    "ein undichter Injektor laesst den Rail-Druck zusammenbrechen. "
                    "Ruecklaufmengen-Test mit Messbechern an den Injektoren.",
        },
        "q_immo": {
            "type": "q",
            "text": "Security-/Wegfahrsperren-Leuchte aktiv, oder WCM antwortet "
                    "beim Modul-Scan nicht?",
            "live": "scan_wcm", "yes": "r_immo", "no": "q_supply",
        },
        "r_immo": {
            "type": "r",
            "title": "Wegfahrsperre (WCM/SKREEM) autorisiert nicht",
            "text": "Orgelt, aber Einspritzung gesperrt. Schluessel-Transponder, "
                    "WCM, oder PCM<->WCM-Kommunikation. Fehlerspeicher des WCM per "
                    "UDS lesen (nicht generisch), Ersatzschluessel testen.",
        },
        "q_supply": {
            "type": "q",
            "text": "Kommt ueberhaupt Kraftstoff blasenfrei an der Pumpe an "
                    "(Vorfoerderdruck / Handpumpe fest)?",
            "yes": "q_glow", "no": "r_supply",
        },
        "r_supply": {
            "type": "r",
            "title": "Kraftstoffzufuhr / Luft im System",
            "text": "Vorfoerderpumpe schwach, Filter zu, Leitung zieht Luft, Tank "
                    "leer/verstopft. System entlueften. Ohne blasenfreien Zulauf "
                    "baut die Hochdruckpumpe keinen Raildruck auf.",
        },
        "q_glow": {
            "type": "q",
            "text": "Tritt der Nichtstart vor allem bei KALTEM Motor auf?",
            "yes": "r_glow", "no": "q_mech",
        },
        "r_glow": {
            "type": "r",
            "title": "Glueh-System (Kaltstart)",
            "text": "Gluehkerzen und Gluehzeitsteuergeraet pruefen. Bei defektem "
                    "Gluehsystem startet der kalte Diesel schwer/gar nicht, warm "
                    "aber schon. Kerzen einzeln auf Widerstand/Ansteuerung messen.",
        },
        "q_mech": {
            "type": "q",
            "text": "Raildruck UND Kraftstoff da, springt trotzdem nicht an?",
            "yes": "r_mech", "no": "r_recheck",
        },
        "r_mech": {
            "type": "r",
            "title": "Injektoren / Mechanik / Steuerzeiten",
            "text": "Injektoren (Ruecklaufmengen-Test - defekter Injektor), "
                    "Kompression (Verschleiss/Ventile), Steuerzeiten (Kette/Riemen "
                    "uebersprungen -> Nocken/Kurbel-Korrelation). Bei Kaelte "
                    "zusaetzlich Gluehsystem.",
        },
        "r_recheck": {
            "type": "r",
            "title": "Strukturiert messen",
            "text": "Beim Orgeln gleichzeitig RPM und Raildruck live beobachten - "
                    "der Ausfall zeigt sich an einem der beiden Werte.",
        },
    },
    "live_hints": {
        "rail_pressure": "Tool: Rail-Druck-PID (0x23) beim Orgeln lesen oder "
                         "Manometer - bleibt der Druck zu niedrig, zuendet der "
                         "Diesel nicht.",
        "rpm_crank": "Tool: RPM (PID 010C) beim Orgeln - bleibt sie 0, fehlt das "
                     "Kurbelsignal.",
        "scan_wcm": "Tool: 'Module scannen' - antwortet das WCM? Danach dessen "
                    "Fehlerspeicher per UDS lesen.",
    },
}


def validate():
    """Selbsttest beider Baeume: jeder ja/nein-Zweig zeigt auf existierenden Knoten."""
    errs = []
    for label, T in (("benzin", TREE), ("diesel", TREE_DIESEL)):
        nodes = T["nodes"]
        for nid, n in nodes.items():
            if n["type"] == "q":
                for br in ("yes", "no"):
                    if n[br] not in nodes:
                        errs.append(f"{label}:{nid}.{br} -> {n[br]} fehlt")
        if T["start"] not in nodes:
            errs.append(f"{label}: start fehlt")
    return errs
