# MacOBD-Pro v2.0 — Installation

## Systemvoraussetzungen
- macOS 12+ (Monterey oder neuer)
- Python 3.9+
- ELM327 OBD-II Adapter (Bluetooth oder USB)

## Installation
```bash
pip install pyserial pyusb
python3 main.py
```

## Unterstützte Fahrzeuge
59 Fahrzeuge, 31 Marken — VW, BMW, Mercedes, Audi, Toyota, Honda, Ford, und mehr.

## Funktionen
- Live-Fehlercodes lesen (P0000-P9999)
- Echtzeit-Daten: RPM, Drehmoment, Temperatur, O2-Sensoren
- Freeze Frame Daten
- Codiert/Decodiert: PID-Werte
- UDS-Protokoll (Unified Diagnostic Services)
- Dyno-Messung (Leistungsmessung)

## Support
bullpowersrtkennels@gmail.com
