#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Online-Zusatz (optional, faellt offline sauber zurueck)
====================================================================
Das gesamte Tool laeuft OFFLINE (lokaler Server, eingebettete DTC-DB).
Dieses Modul fuegt OPTIONALE Online-Funktionen hinzu:
  - VIN-Decoder ueber die offizielle NHTSA-vPIC-Datenbank (kostenlos, kein Key)
  - Online-Status-Pruefung
Bei fehlender Verbindung wird sauber ein Offline-Hinweis zurueckgegeben.
"""

import json
import urllib.request

NHTSA = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/{}?format=json"
PING = "https://vpic.nhtsa.dot.gov/api/"


def online_status():
    try:
        urllib.request.urlopen(PING, timeout=3)
        return {"online": True}
    except Exception:
        return {"online": False}


def vin_decode(vin):
    vin = (vin or "").strip().upper()
    if len(vin) < 11:
        return {"ok": False, "error": "VIN zu kurz (17 Zeichen erwartet)."}
    try:
        with urllib.request.urlopen(NHTSA.format(vin), timeout=8) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return {"ok": False, "offline": True,
                "error": f"Keine Online-Verbindung ({e}). Fahrzeug manuell waehlen."}
    res = (data.get("Results") or [{}])[0]
    out = {
        "ok": True, "vin": vin,
        "make": res.get("Make", ""), "model": res.get("Model", ""),
        "year": res.get("ModelYear", ""), "trim": res.get("Trim", ""),
        "cylinders": res.get("EngineCylinders", ""),
        "displacement": res.get("DisplacementL", ""),
        "fuel": res.get("FuelTypePrimary", ""),
        "body": res.get("BodyClass", ""),
        "plant": res.get("PlantCountry", ""),
    }
    out["profile"] = match_profile(out)
    return out


def match_profile(d):
    model = (d.get("model") or "").lower()
    if "challenger" in model:
        return "challenger_v6"
    if "ram" in model:
        return "ram_hemi_57"
    if "nitro" in model:
        return "nitro"
    return "generic"
