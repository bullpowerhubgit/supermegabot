#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - Capture-Decoder + DTC-Klartext-Datenbank
=====================================================
Gesnifften CAN-Verkehr entschluesseln: ISO-TP zusammensetzen und als
OBD-II- bzw. UDS-Bedeutung ausgeben. Kernwerkzeug fuers Reverse-Engineering
des ThinkDiag2-Protokolls.
"""

from uds import decode_dtc3

# ---- OBD-II Mode-01 PID Kurzbeschreibung (Auszug der gaengigen) ----
OBD_PIDS = {
    0x04: "Motorlast", 0x05: "Kuehlmitteltemp", 0x06: "Kurzzeit-Gemisch B1",
    0x07: "Langzeit-Gemisch B1", 0x0B: "Saugrohrdruck", 0x0C: "Drehzahl",
    0x0D: "Geschwindigkeit", 0x0E: "Zuendzeitpunkt", 0x0F: "Ansauglufttemp",
    0x10: "Luftmassenmesser", 0x11: "Drosselklappe", 0x1F: "Laufzeit seit Start",
    0x21: "Strecke mit MIL", 0x2F: "Tankfuellstand", 0x33: "Umgebungsdruck",
    0x42: "Steuergeraetespannung", 0x43: "Absolute Last", 0x46: "Umgebungstemp",
    0x5C: "Oeltemperatur", 0x5E: "Kraftstoffverbrauch",
}

UDS_SERVICES = {
    0x10: "DiagnosticSessionControl", 0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation", 0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier", 0x23: "ReadMemoryByAddress",
    0x27: "SecurityAccess", 0x28: "CommunicationControl",
    0x2E: "WriteDataByIdentifier", 0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl", 0x34: "RequestDownload",
    0x35: "RequestUpload", 0x36: "TransferData", 0x37: "RequestTransferExit",
    0x3E: "TesterPresent", 0x85: "ControlDTCSetting",
}

# ---- DTC-Klartext (generische OBD-II Codes, Auszug der haeufigsten) ----
DTC_DB = {
    "P0010": "Nockenwellenversteller B1 - elektrischer Fehler",
    "P0011": "Nockenwellenposition B1 - Verstellung zu weit vor",
    "P0016": "Kurbelwelle/Nockenwelle B1 - Korrelation fehlerhaft",
    "P0087": "Kraftstoffdruck zu niedrig",
    "P0089": "Kraftstoffdruckregler - Leistung",
    "P0100": "Luftmassenmesser - Fehlfunktion",
    "P0101": "Luftmassenmesser - Bereich/Leistung",
    "P0106": "Saugrohrdrucksensor - Bereich/Leistung",
    "P0113": "Ansauglufttemperatursensor - Signal hoch",
    "P0116": "Kuehlmitteltemperatursensor - Bereich/Leistung",
    "P0118": "Kuehlmitteltemperatursensor - Signal hoch",
    "P0120": "Drosselklappen-/Pedalsensor A - Fehlfunktion",
    "P0128": "Kuehlmitteltemperatur unter Thermostat-Solltemperatur",
    "P0130": "Lambdasonde B1S1 - Fehlfunktion",
    "P0131": "Lambdasonde B1S1 - Signal niedrig",
    "P0133": "Lambdasonde B1S1 - langsame Reaktion",
    "P0134": "Lambdasonde B1S1 - keine Aktivitaet",
    "P0135": "Lambdasonde B1S1 - Heizung",
    "P0171": "Gemisch zu mager (Bank 1)",
    "P0172": "Gemisch zu fett (Bank 1)",
    "P0174": "Gemisch zu mager (Bank 2)",
    "P0175": "Gemisch zu fett (Bank 2)",
    "P0201": "Injektor Zylinder 1 - Stromkreis",
    "P0217": "Motor ueberhitzt",
    "P0234": "Ladedruck zu hoch (Overboost)",
    "P0299": "Ladedruck zu niedrig (Underboost)",
    "P0300": "Zufaellige/mehrere Zylinder - Verbrennungsaussetzer",
    "P0301": "Zylinder 1 - Verbrennungsaussetzer",
    "P0302": "Zylinder 2 - Verbrennungsaussetzer",
    "P0303": "Zylinder 3 - Verbrennungsaussetzer",
    "P0304": "Zylinder 4 - Verbrennungsaussetzer",
    "P0305": "Zylinder 5 - Verbrennungsaussetzer",
    "P0306": "Zylinder 6 - Verbrennungsaussetzer",
    "P0327": "Klopfsensor 1 - Signal niedrig",
    "P0340": "Nockenwellensensor - Fehlfunktion",
    "P0380": "Gluehkerzen-Stromkreis A",
    "P0401": "Abgasrueckfuehrung - Durchfluss zu gering",
    "P0402": "Abgasrueckfuehrung - Durchfluss zu hoch",
    "P0420": "Katalysator-Wirkungsgrad unter Schwelle (Bank 1)",
    "P0430": "Katalysator-Wirkungsgrad unter Schwelle (Bank 2)",
    "P0440": "Tankentlueftung (EVAP) - Fehlfunktion",
    "P0455": "Tankentlueftung (EVAP) - grosses Leck",
    "P0500": "Geschwindigkeitssensor A - Fehlfunktion",
    "P0503": "Geschwindigkeitssensor - unregelmaessig",
    "P0562": "Bordspannung zu niedrig",
    "P0563": "Bordspannung zu hoch",
    "P0571": "Bremslichtschalter A - Fehlfunktion",
    "P0606": "Steuergeraet (ECM/PCM) - Prozessorfehler",
    "P062F": "Steuergeraet - internes Speicherfehler (EEPROM)",
    "P0700": "Getriebesteuerung - Fehlfunktion",
    "P0715": "Turbinendrehzahlsensor - Fehlfunktion",
    # --- Chrysler / Dodge haeufige Codes ---
    "P0017": "Kurbelwelle/Nockenwelle B1S2 - Korrelation",
    "P0020": "Nockenwellenversteller B2 - elektrisch",
    "P0021": "Nockenwellenposition B2 - Verstellung zu weit vor",
    "P0339": "Kurbelwellensensor - Signal aussetzend",
    "P0522": "Oeldrucksensor - Signal zu niedrig",
    "P0846": "Getriebe-Druckschalter/-sensor - Bereich/Leistung",
    "P2004": "Ansaugklappe (Short Runner) B1 - klemmt offen",
    "P2016": "Ansaugklappen-Positionssensor B1 - Signal niedrig",
    "P1004": "Ansaug-Kruemmer-Umschaltung (Chrysler) - Leistung",
    "U0001": "CAN-C High-Speed-Bus - Fehlfunktion",
    "U0100": "Kommunikation zum PCM/ECM verloren",
    "U0101": "Kommunikation zum TCM (Getriebe) verloren",
    "U0121": "Kommunikation zum ABS/ESP verloren",
    "U0140": "Kommunikation zum BCM/TIPM verloren",
    "U0141": "Kommunikation zum Power-Modul (TIPM) verloren",
    "U0155": "Kommunikation zum Kombiinstrument (CCN) verloren",
    "U0184": "Kommunikation zum Radio verloren",
    "P0480": "Kuehlerluefter-Relais 1 - Steuerkreis (bei Dodge oft im TIPM)",
    "P0481": "Kuehlerluefter-Relais 2 - Steuerkreis. ACHTUNG Dodge: Luefter- UND "
             "Kraftstoffpumpen-/ASD-Relais sitzen im TIPM - Code kann Vorbote "
             "eines sterbenden TIPM sein (dann No-Start ohne eigenen Code!).",
    # --- Diesel / Common-Rail (Nitro 2.8 CRD u.ae.) ---
    "P0088": "Kraftstoff-Raildruck zu hoch",
    "P0093": "Kraftstoffsystem - grosses Leck erkannt",
    "P0193": "Raildrucksensor - Signal hoch",
    "P0201d": "Injektor Zylinder 1 - Stromkreis (Diesel)",
    "P0380d": "Gluehkerzen-Stromkreis A (Kaltstart)",
    "P0402d": "Abgasrueckfuehrung - Durchfluss zu hoch",
    "P2002": "Dieselpartikelfilter (DPF) - Wirkung unter Schwelle",
    "P2463": "DPF - Rrussansammlung zu hoch",
    "P0087": "Kraftstoff-Raildruck zu niedrig (Pumpe/Regler/Leck)",
    "P16xx": "Herstellerspezifisch (Antrieb)",
}

_CATEGORY = {"P": "Antrieb", "C": "Chassis", "B": "Karosserie", "U": "Netzwerk"}


def dtc_text(code):
    """Klartext zu einem DTC (mit evtl. '-XX'-Suffix)."""
    base = code.split("-")[0]
    if base in DTC_DB:
        return DTC_DB[base]
    cat = _CATEGORY.get(base[0], "?")
    return f"unbekannt ({cat}, nicht in Offline-DB)"


# ---------------------------------------------------------------------------
# Capture parsen: "7E0#02 10 03", "7E0 02 10 03", "0x7E0 021003" ...
# ---------------------------------------------------------------------------
def parse_capture(text):
    frames = []
    for line in text.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        idpart, _, rest = line.partition("#")
        if not rest:  # kein '#': erstes Token = ID
            toks = line.replace(",", " ").split()
            if len(toks) < 2:
                continue
            idpart, rest = toks[0], " ".join(toks[1:])
        try:
            arb = int(idpart.strip(), 16)
        except ValueError:
            continue
        hexs = "".join(ch for ch in rest if ch in "0123456789abcdefABCDEF")
        data = bytes(int(hexs[i:i+2], 16) for i in range(0, len(hexs)-len(hexs) % 2, 2))
        if data:
            frames.append((arb, data))
    return frames


def _isotp_reassemble(frames):
    """Pro arb_id ISO-TP-Nachrichten rekonstruieren."""
    msgs = []
    pending = {}   # arb_id -> {buf, total}
    for arb, d in frames:
        if not d:
            continue
        pci = d[0] & 0xF0
        if pci == 0x00:                      # Single Frame
            ln = d[0] & 0x0F
            msgs.append((arb, bytes(d[1:1+ln]), "SF"))
        elif pci == 0x10:                    # First Frame
            total = ((d[0] & 0x0F) << 8) | d[1]
            pending[arb] = {"buf": bytearray(d[2:8]), "total": total}
        elif pci == 0x20:                    # Consecutive Frame
            if arb in pending:
                pending[arb]["buf"] += d[1:8]
                if len(pending[arb]["buf"]) >= pending[arb]["total"]:
                    msgs.append((arb, bytes(pending[arb]["buf"][:pending[arb]["total"]]), "MF"))
                    del pending[arb]
        elif pci == 0x30:                    # Flow Control
            msgs.append((arb, bytes(d), "FC"))
    return msgs


def _semantic(payload):
    """OBD/UDS-Bedeutung eines zusammengesetzten Payloads."""
    if not payload:
        return "(leer)"
    svc = payload[0]
    # OBD-II Requests (Modes 01-0A) und Responses (0x41-0x4A)
    if svc in (0x01, 0x02) and len(payload) >= 2:
        pid = payload[1]
        return f"OBD Mode {svc:02X} PID {pid:02X} ({OBD_PIDS.get(pid,'?')}) [Anfrage]"
    if svc in (0x41, 0x42) and len(payload) >= 2:
        pid = payload[1]
        return f"OBD Mode {svc-0x40:02X} Antwort PID {pid:02X} ({OBD_PIDS.get(pid,'?')})"
    if svc == 0x03:
        return "OBD Mode 03 - Fehlercodes lesen [Anfrage]"
    if svc == 0x43:
        codes = []
        h = payload[1:]
        for i in range(0, len(h)-1, 2):
            if h[i] or h[i+1]:
                codes.append(_obd_dtc(h[i], h[i+1]))
        return f"OBD Fehlercodes: {', '.join(codes) if codes else '(keine)'}"
    # UDS
    if svc == 0x7F and len(payload) >= 3:
        return f"UDS Negative Response auf {UDS_SERVICES.get(payload[1],hex(payload[1]))} (NRC 0x{payload[2]:02X})"
    if svc in UDS_SERVICES:
        return f"UDS {UDS_SERVICES[svc]} [Anfrage]"
    if (svc-0x40) in UDS_SERVICES:
        base = svc-0x40
        if base == 0x19:  # DTC-Antwort
            dtcs = []
            body = payload[3:]
            for i in range(0, len(body)-3, 4):
                if any(body[i:i+3]):
                    dtcs.append(decode_dtc3(body[i], body[i+1], body[i+2]))
            return f"UDS {UDS_SERVICES[base]} Antwort - DTCs: {', '.join(dtcs) if dtcs else '(keine)'}"
        return f"UDS {UDS_SERVICES[base]} [positive Antwort]"
    return f"unbekannt (erstes Byte 0x{svc:02X})"


def _obd_dtc(b1, b2):
    first = "PCBU"[(b1 & 0xC0) >> 6]
    hexd = "0123456789ABCDEF"
    return (first + str((b1 & 0x30) >> 4) + hexd[b1 & 0x0F]
            + hexd[(b2 & 0xF0) >> 4] + hexd[b2 & 0x0F])


def decode_capture(text):
    frames = parse_capture(text)
    msgs = _isotp_reassemble(frames)
    out = []
    for arb, payload, kind in msgs:
        item = {"id": f"0x{arb:03X}", "kind": kind,
                "hex": " ".join(f"{b:02X}" for b in payload),
                "meaning": _semantic(payload)}
        # DTC-Klartext nur bei echten DTC-Listen anreichern
        if "DTCs:" in item["meaning"] or "Fehlercodes:" in item["meaning"]:
            item["dtc_details"] = [{"code": c.strip(), "text": dtc_text(c.strip())}
                                   for c in item["meaning"].split(":")[-1].split(",")
                                   if c.strip() and c.strip() != "(keine)"]
        out.append(item)
    return {"ok": True, "frames": len(frames), "messages": out}
