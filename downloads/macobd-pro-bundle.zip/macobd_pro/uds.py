#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MacOBD-Pro - UDS (ISO 14229) ueber ISO-TP (ISO 15765-2)
=======================================================
Der Standard hinter echter Voll-Diagnose - weit mehr als ELM327:
  - Fehlerspeicher aller Steuergeraete lesen/loeschen (0x19 / 0x14)
  - Messwerte per Identifier (0x22 ReadDataByIdentifier)
  - Stellgliedtests / Aktuatoren (0x2F InputOutputControlByIdentifier)
  - Service-Routinen: Reset, DPF, Anlernen ... (0x31 RoutineControl)
  - ECU-Reset (0x11), Sitzung (0x10), Security-Access (0x27)

Transport-abstrakt: bindet an JEDEN CAN-Kanal - an den ThinkDiag2-USB
(sobald dessen Framing dekodiert ist), an SocketCAN, an ein serielles
CAN-Interface, oder an den Loopback-Mock zum Testen.
"""

import time
import struct

# ---- Negative-Response-Codes (Auszug) ----
NRC = {
    0x10: "generalReject", 0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported", 0x13: "incorrectMessageLength",
    0x22: "conditionsNotCorrect", 0x31: "requestOutOfRange",
    0x33: "securityAccessDenied", 0x35: "invalidKey",
    0x78: "responsePending", 0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}


class UDSError(Exception):
    pass


class Transport:
    """Basisklasse: Frames senden/empfangen. In Unterklasse implementieren."""
    def send_frame(self, arb_id, data):
        raise NotImplementedError

    def recv_frame(self, timeout=1.0):
        """-> (arb_id, bytes) oder None bei Timeout."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# ISO-TP (ISO 15765-2) Segmentierung
# ---------------------------------------------------------------------------
def _pad(data, pad=0x00):
    return bytes(data) + bytes([pad]) * (8 - len(data))


def isotp_send(tp, tx_id, rx_id, payload, pad=0x00, timeout=1.0):
    payload = bytes(payload)
    n = len(payload)
    if n <= 7:  # Single Frame
        tp.send_frame(tx_id, _pad(bytes([n]) + payload, pad))
        return
    # First Frame
    ff = bytes([0x10 | ((n >> 8) & 0x0F), n & 0xFF]) + payload[:6]
    tp.send_frame(tx_id, _pad(ff, pad))
    # Auf Flow Control warten
    fc = _wait_fc(tp, rx_id, timeout)
    bs = fc[1] if len(fc) > 1 else 0
    stmin = fc[2] if len(fc) > 2 else 0
    st = _stmin_seconds(stmin)
    # Consecutive Frames
    idx, seq, sent = 6, 1, 0
    while idx < n:
        cf = bytes([0x20 | (seq & 0x0F)]) + payload[idx:idx + 7]
        tp.send_frame(tx_id, _pad(cf, pad))
        idx += 7
        seq = (seq + 1) & 0x0F
        sent += 1
        if bs and sent % bs == 0 and idx < n:
            fc = _wait_fc(tp, rx_id, timeout)
            st = _stmin_seconds(fc[2] if len(fc) > 2 else 0)
        if st:
            time.sleep(st)


def _wait_fc(tp, rx_id, timeout):
    end = time.time() + timeout
    while time.time() < end:
        r = tp.recv_frame(timeout=0.2)
        if r and r[0] == rx_id and (r[1][0] & 0xF0) == 0x30:
            return r[1]
    raise UDSError("Keine Flow-Control-Antwort vom Steuergeraet.")


def _stmin_seconds(stmin):
    if stmin <= 0x7F:
        return stmin / 1000.0
    if 0xF1 <= stmin <= 0xF9:
        return (stmin - 0xF0) / 1e6
    return 0.0


def isotp_recv(tp, rx_id, tx_id, timeout=1.0, pad=0x00):
    """Empfaengt eine ISO-TP-Nachricht (SF/FF+CF) und liefert das Payload."""
    end = time.time() + timeout
    frame = None
    while time.time() < end:
        r = tp.recv_frame(timeout=0.2)
        if r and r[0] == rx_id:
            frame = r[1]
            break
    if frame is None:
        raise UDSError("Timeout: keine Antwort vom Steuergeraet.")
    pci = frame[0] & 0xF0
    if pci == 0x00:  # Single Frame
        ln = frame[0] & 0x0F
        return bytes(frame[1:1 + ln])
    if pci == 0x10:  # First Frame
        total = ((frame[0] & 0x0F) << 8) | frame[1]
        data = bytearray(frame[2:8])
        # Flow Control senden (Clear To Send, BS=0, STmin=0)
        tp.send_frame(tx_id, _pad(bytes([0x30, 0x00, 0x00]), pad))
        seq_expected = 1
        while len(data) < total and time.time() < end:
            r = tp.recv_frame(timeout=0.3)
            if not r or r[0] != rx_id:
                continue
            cf = r[1]
            if (cf[0] & 0xF0) != 0x20:
                continue
            data += cf[1:8]
            seq_expected = (seq_expected + 1) & 0x0F
        return bytes(data[:total])
    raise UDSError(f"Unerwarteter PCI: {frame[0]:02X}")


# ---------------------------------------------------------------------------
# UDS-Client
# ---------------------------------------------------------------------------
class UDSClient:
    def __init__(self, transport, tx_id=0x7E0, rx_id=0x7E8, pad=0x00):
        self.tp = transport
        self.tx_id = tx_id
        self.rx_id = rx_id
        self.pad = pad

    def request(self, service_bytes, timeout=1.0):
        isotp_send(self.tp, self.tx_id, self.rx_id, service_bytes,
                   self.pad, timeout)
        resp = isotp_recv(self.tp, self.rx_id, self.tx_id, timeout, self.pad)
        if not resp:
            raise UDSError("Leere Antwort.")
        if resp[0] == 0x7F:
            svc = resp[1] if len(resp) > 1 else 0
            code = resp[2] if len(resp) > 2 else 0
            # responsePending -> weiter warten
            if code == 0x78:
                resp = isotp_recv(self.tp, self.rx_id, self.tx_id,
                                  timeout * 3, self.pad)
                if resp and resp[0] != 0x7F:
                    return resp
            raise UDSError(f"Negative Response auf Service 0x{svc:02X}: "
                           f"0x{code:02X} ({NRC.get(code,'?')})")
        return resp

    # ---- konkrete Dienste ----
    def session(self, sub=0x03):                       # ExtendedDiagnostic
        return self.request(bytes([0x10, sub]))

    def tester_present(self):
        return self.request(bytes([0x3E, 0x00]))

    def ecu_reset(self, sub=0x01):                     # hardReset
        return self.request(bytes([0x11, sub]))

    def read_dtcs(self, status_mask=0xFF):
        r = self.request(bytes([0x19, 0x02, status_mask]), timeout=2.0)
        return parse_uds_dtcs(r)

    def clear_dtcs(self, group=0xFFFFFF):
        return self.request(bytes([0x14, (group >> 16) & 0xFF,
                                   (group >> 8) & 0xFF, group & 0xFF]),
                            timeout=2.0)

    def read_data_by_id(self, did):
        r = self.request(bytes([0x22, (did >> 8) & 0xFF, did & 0xFF]))
        return r[3:] if len(r) >= 3 else b""

    def io_control(self, did, control, params=b""):
        # 0x2F: Stellgliedtest. control z.B. 0x03=shortTermAdjust,0x00=return
        return self.request(bytes([0x2F, (did >> 8) & 0xFF, did & 0xFF,
                                   control]) + bytes(params), timeout=2.0)

    def write_data_by_id(self, did, data):
        # 0x2E: Wert schreiben/codieren (oft Security Access noetig)
        return self.request(bytes([0x2E, (did >> 8) & 0xFF, did & 0xFF])
                            + bytes(data), timeout=2.0)

    def read_memory_by_address(self, addr, size, addr_bytes=4, size_bytes=2):
        # 0x23: Speicher lesen (ungefaehrlich). ALFID = (size<<4)|addr
        alfid = ((size_bytes & 0x0F) << 4) | (addr_bytes & 0x0F)
        a = addr.to_bytes(addr_bytes, "big")
        s = size.to_bytes(size_bytes, "big")
        r = self.request(bytes([0x23, alfid]) + a + s, timeout=2.0)
        return r[1:] if len(r) > 1 else b""

    # --- Programmier-Services (nur mit Security-Key + gueltigem Image!) ---
    def programming_session(self):
        return self.request(bytes([0x10, 0x02]))

    def request_download(self, addr, size, addr_bytes=4, size_bytes=4, dfi=0x00):
        alfid = ((size_bytes & 0x0F) << 4) | (addr_bytes & 0x0F)
        return self.request(bytes([0x34, dfi, alfid])
                            + addr.to_bytes(addr_bytes, "big")
                            + size.to_bytes(size_bytes, "big"), timeout=3.0)

    def transfer_data(self, block_seq, data):
        return self.request(bytes([0x36, block_seq & 0xFF]) + bytes(data),
                            timeout=3.0)

    def request_transfer_exit(self):
        return self.request(bytes([0x37]), timeout=3.0)

    def routine(self, control, routine_id, params=b""):
        # 0x31: control 0x01=start,0x02=stop,0x03=requestResults
        return self.request(bytes([0x31, control, (routine_id >> 8) & 0xFF,
                                   routine_id & 0xFF]) + bytes(params),
                            timeout=3.0)

    def security_seed(self, level=0x01):
        return self.request(bytes([0x27, level]))

    def security_key(self, level, key):
        return self.request(bytes([0x27, level + 1]) + bytes(key))


# ---------------------------------------------------------------------------
# DTC-Dekodierung (3-Byte UDS-Format + Statusbyte)
# ---------------------------------------------------------------------------
def decode_dtc3(b1, b2, b3):
    first = "PCBU"[(b1 & 0xC0) >> 6]
    hexd = "0123456789ABCDEF"
    code = (first + str((b1 & 0x30) >> 4) + hexd[b1 & 0x0F]
            + hexd[(b2 & 0xF0) >> 4] + hexd[b2 & 0x0F])
    return f"{code}-{b3:02X}" if b3 else code


def parse_uds_dtcs(resp):
    """Antwort auf 0x19 0x02 -> Liste {code,status}."""
    out = []
    if len(resp) < 3 or resp[0] != 0x59:
        return out
    body = resp[3:]  # nach 59 02 <availabilityMask>
    for i in range(0, len(body) - 3, 4):
        b1, b2, b3, status = body[i], body[i+1], body[i+2], body[i+3]
        if b1 == b2 == b3 == 0:
            continue
        out.append({"code": decode_dtc3(b1, b2, b3),
                    "status": f"0x{status:02X}",
                    "confirmed": bool(status & 0x08),
                    "pending": bool(status & 0x04)})
    return out
