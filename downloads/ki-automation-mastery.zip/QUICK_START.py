#!/usr/bin/env python3
"""
KI-Automation MASTERY — Quick Start Script
==========================================
Dieses Script zeigt, wie man ai_client.py für typische E-Commerce-Aufgaben nutzt.
Starte hier, um dein erstes KI-gestütztes Automatisierungsprojekt zu bauen.

Voraussetzungen:
  pip install aiohttp anthropic openai
  .env Datei mit ANTHROPIC_API_KEY oder OPENROUTER_API_KEY

Ausführen:
  python3 QUICK_START.py
"""

import asyncio
import os
import sys

# Stelle sicher, dass die Module gefunden werden
sys.path.insert(0, os.path.dirname(__file__))

from modules.ai_client import AIClient


async def demo_product_description():
    """Beispiel 1: KI generiert eine Produktbeschreibung."""
    print("\n=== Beispiel 1: Produktbeschreibung generieren ===")

    ai = AIClient()

    product_name = "Smart LED Schreibtischlampe mit USB-C Ladeport"

    prompt = f"""Schreibe eine SEO-optimierte Produktbeschreibung für dieses Produkt:

Produkt: {product_name}

Anforderungen:
- 150-200 Wörter
- 3-5 Bullet Points mit den wichtigsten Features
- Natürliche Keyword-Integration
- Kaufanreiz am Ende
- Sprache: Deutsch
- Ton: Professionell aber zugänglich"""

    try:
        description = await ai.generate(prompt=prompt, max_tokens=500)
        print(f"Generierte Beschreibung:\n{description}")
    except Exception as e:
        print(f"Fehler: {e}")
        print("Stelle sicher, dass ANTHROPIC_API_KEY oder OPENROUTER_API_KEY in .env gesetzt ist.")

    return description


async def demo_social_post():
    """Beispiel 2: KI erstellt einen Social-Media-Post."""
    print("\n=== Beispiel 2: Social-Media-Post erstellen ===")

    ai = AIClient()

    prompt = """Erstelle einen Instagram-Post für ein Smart Home Produkt.

Format:
- Headline (1 Zeile, Aufmerksamkeit erregen)
- 3-4 Zeilen Beschreibungstext
- 5-8 relevante Hashtags
- Call-to-Action

Produkt: Smart LED Schreibtischlampe
Stil: Modern, inspirierend, nicht zu werblich
Sprache: Deutsch"""

    try:
        post = await ai.generate(prompt=prompt, max_tokens=300)
        print(f"Generierter Post:\n{post}")
    except Exception as e:
        print(f"Fehler: {e}")


async def demo_email_subject():
    """Beispiel 3: KI optimiert E-Mail-Betreffzeilen."""
    print("\n=== Beispiel 3: E-Mail-Betreffzeilen optimieren ===")

    ai = AIClient()

    prompt = """Generiere 5 verschiedene E-Mail-Betreffzeilen für eine Willkommens-E-Mail an Neukunden.

Shop: Smart Home & Gadgets Online-Shop
Ziel: Hohe Öffnungsrate, Vertrauen aufbauen
Stil: Freundlich, professionell
Sprache: Deutsch

Variiere zwischen:
- Neugier weckend
- Vorteil betonend
- Persönlich/direkt
- Dringlichkeit
- Frage-Format"""

    try:
        subjects = await ai.generate(prompt=prompt, max_tokens=300)
        print(f"Betreffzeilen:\n{subjects}")
    except Exception as e:
        print(f"Fehler: {e}")


async def demo_trend_analysis():
    """Beispiel 4: KI analysiert Produkttrends."""
    print("\n=== Beispiel 4: Trend-Analyse ===")

    ai = AIClient()

    prompt = """Analysiere aktuelle Trends im Smart Home Bereich für E-Commerce 2025/2026.

Beantworte:
1. Top 3 Produktkategorien mit dem größten Wachstumspotenzial
2. Welche Altersgruppen kaufen am häufigsten Smart Home Produkte?
3. Welche Preissegmente sind am stärksten nachgefragt?
4. 3 konkrete Produktideen, die du jetzt sofort listen würdest

Halte die Antwort kompakt und handlungsorientiert."""

    try:
        analysis = await ai.generate(prompt=prompt, max_tokens=600)
        print(f"Trend-Analyse:\n{analysis}")
    except Exception as e:
        print(f"Fehler: {e}")


async def main():
    """Hauptfunktion — führt alle Demos aus."""
    print("=" * 60)
    print("KI-Automation MASTERY — Quick Start Demos")
    print("=" * 60)

    # Prüfe ob .env vorhanden
    env_file = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_file):
        from dotenv import load_dotenv
        load_dotenv(env_file)
        print("\n.env Datei geladen.")
    else:
        print("\nHINWEIS: Keine .env Datei gefunden.")
        print("Erstelle eine .env Datei mit deinen API-Keys:")
        print("  ANTHROPIC_API_KEY=sk-ant-xxx")
        print("  oder")
        print("  OPENROUTER_API_KEY=sk-or-xxx")
        print()

    # Demo 1: Produktbeschreibung
    await demo_product_description()

    # Kurze Pause zwischen API-Calls
    await asyncio.sleep(1)

    # Demo 2: Social Post
    await demo_social_post()

    await asyncio.sleep(1)

    # Demo 3: E-Mail Betreffzeilen
    await demo_email_subject()

    await asyncio.sleep(1)

    # Demo 4: Trend-Analyse
    await demo_trend_analysis()

    print("\n" + "=" * 60)
    print("Quick Start abgeschlossen!")
    print("\nNächste Schritte:")
    print("1. Lies MASTERY_GUIDE.md für den vollständigen Leitfaden")
    print("2. Konfiguriere deine .env mit echten API-Keys")
    print("3. Starte mit Beispiel 1 und passe den Prompt auf dein Produkt an")
    print("4. Baue deinen ersten automatischen Produkt-Import-Flow")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
