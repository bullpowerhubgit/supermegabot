# Social Media AUTOPILOT — KI bespielt alle 7 Kanäle automatisch

Vollautomatisches Social Media System für Instagram, Facebook, TikTok, Pinterest, Twitter/X, Reddit, LinkedIn.

## Was ist drin?

### organic_traffic_manager.py
- 7 Plattformen in einem System
- KI-generierte Inhalte (Produkte, Tips, Trends, Stories)
- PostGuard: Jeder Post wird vor Veröffentlichung geprüft (URL-Check, Spam, Duplicate, Nische)
- Rate-Limiting: Kein Account-Banning mehr
- Shop-Live-Check: Keine Posts wenn dein Shop offline ist

### brutal_ads_engine.py  
- 12 Werbe-Slots (morning_drop, mid_day, evening_push, etc.)
- Pre-flight HTTP-200-Check aller Links
- Multi-Kanal Integration
- Läuft alle 2 Stunden automatisch

### post_guard.py
- URL-Verfügbarkeitsprüfung
- Spam-Erkennung
- Duplikat-Filter
- Nischen-Relevanzprüfung
- KI-Qualitätsbewertung (1-10)

## Verwendung
```python
from organic_traffic_manager import OrganicTrafficManager
manager = OrganicTrafficManager()
await manager.post_manual("Instagram", "product")
```

## Tägliche Limits (sicher konfiguriert)
- Instagram: 2 Posts/Tag
- Facebook: 2 Posts/Tag  
- TikTok: 2 Posts/Tag
- Pinterest: 3 Posts/Tag
- Twitter/X: 3 Posts/Tag
- Reddit: 1 Post/Tag
- LinkedIn: 1 Post/Tag
